import * as XLSX from 'xlsx';
import type { Customer } from './types';

type CustomerInput = Omit<Customer, 'id' | 'createdAt' | 'updatedAt'>;

// Normalize header for matching: lowercase, strip quotes/dots/spaces/dashes
function normHeader(h: string): string {
  return String(h || '')
    .trim()
    .toLowerCase()
    .replace(/["'`׳״.\-_\s]/g, '');
}

const HEADER_MAP: Record<string, keyof CustomerInput> = {};
function addAliases(field: keyof CustomerInput, aliases: string[]) {
  aliases.forEach(a => { HEADER_MAP[normHeader(a)] = field; });
}

addAliases('fullName', ['שם', 'שם מלא', 'name', 'fullname', 'full_name', 'full name']);
addAliases('nickname', ['כינוי', 'nickname', 'כינוי/שם נוסף']);
addAliases('idNumber', ['ת.ז', 'ת"ז', 'תז', 'תעודת זהות', 'ת. ז.', 'id', 'idnumber', 'id_number', 'id number']);
addAliases('phone', ['טלפון', 'phone', 'נייד', 'טלפון 1', 'phone1', 'mobile', 'cellphone']);
addAliases('phone2', ['טלפון 2', 'phone2', 'טלפון נוסף', 'נייד 2']);
addAliases('email', ['אימייל', 'email', 'מייל', 'דוא"ל', 'דואל']);
addAliases('city', ['עיר', 'city', 'יישוב', 'ישוב']);
addAliases('street', ['רחוב', 'street']);
addAliases('houseNumber', ['מספר בית', 'מס בית', 'housenumber', 'house_number', 'house number', 'בית']);
addAliases('address', ['כתובת', 'address']);
addAliases('notes', ['הערות', 'notes', 'הערה']);
addAliases('bankNumber', ['בנק', 'מספר בנק', 'קוד בנק', 'bank', 'banknumber', 'bank_number', 'bank number']);
addAliases('branchNumber', ['סניף', 'מספר סניף', 'קוד סניף', 'branch', 'branchnumber', 'branch_number', 'branch number']);
addAliases('accountNumber', ['חשבון', 'מספר חשבון', 'מס חשבון', 'account', 'accountnumber', 'account_number', 'account number', 'חשבון בנק']);
addAliases('accountHolderName', ['שם בעל חשבון', 'בעל החשבון', 'בעל חשבון', 'accountholdername', 'account_holder', 'account holder']);
addAliases('authorizationRef', ['אסמכתה', 'אסמכתא', 'מספר אסמכתה', 'authorization_ref', 'authorizationref', 'reference']);
addAliases('authorizationDate', ['תאריך הרשאה', 'authorization_date', 'authorizationdate']);
addAliases('monthlyAmount', ['סכום', 'סכום חודשי', 'amount', 'monthlyamount', 'monthly_amount', 'monthly amount']);
addAliases('amperes', ['אמפרים', 'אמפר', 'amperes', 'amps', 'ampere']);
addAliases('paymentMethod', ['אמצעי תשלום', 'אופן תשלום', 'payment_method', 'paymentmethod', 'payment method', 'תשלום']);
addAliases('bankAmount', ['סכום בנק', 'bank_amount', 'bankamount']);
addAliases('cashAmount', ['סכום מזומן', 'cash_amount', 'cashamount']);
addAliases('status', ['סטטוס', 'status', 'מצב']);

const FIRST_NAME_KEYS = new Set(['שם פרטי', 'firstname', 'first name', 'first_name'].map(normHeader));
const LAST_NAME_KEYS = new Set(['שם משפחה', 'lastname', 'last name', 'last_name'].map(normHeader));

/**
 * Parse CSV or Excel file (Uint8Array / ArrayBuffer / string) into customer rows.
 * Auto-detects format and supports a wide range of Hebrew/English headers.
 */
export function parseCustomersFromFile(data: ArrayBuffer | Uint8Array | string, fileName?: string): CustomerInput[] {
  let workbook: XLSX.WorkBook;
  if (typeof data === 'string') {
    workbook = XLSX.read(data, { type: 'string', codepage: 65001 });
  } else {
    workbook = XLSX.read(data, { type: 'array', codepage: 65001 });
  }
  const sheetName = workbook.SheetNames[0];
  if (!sheetName) return [];
  const sheet = workbook.Sheets[sheetName];
  const rows: unknown[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: false, defval: '' });
  return parseRows(rows);
}

/** Back-compat: parse a CSV text string. */
export function parseCSVCustomers(text: string): CustomerInput[] {
  return parseCustomersFromFile(text);
}

function parseRows(rows: unknown[][]): CustomerInput[] {
  if (!rows.length) return [];

  // Find first non-empty row as header
  let headerIdx = 0;
  while (headerIdx < rows.length && rows[headerIdx].every(c => String(c || '').trim() === '')) headerIdx++;
  if (headerIdx >= rows.length) return [];

  const headerRow = rows[headerIdx].map(c => String(c || ''));
  const fieldIndexes: Partial<Record<keyof CustomerInput, number>> = {};
  let firstNameIdx = -1;
  let lastNameIdx = -1;

  headerRow.forEach((h, i) => {
    const n = normHeader(h);
    if (FIRST_NAME_KEYS.has(n)) { firstNameIdx = i; return; }
    if (LAST_NAME_KEYS.has(n)) { lastNameIdx = i; return; }
    const field = HEADER_MAP[n];
    if (field && fieldIndexes[field] === undefined) fieldIndexes[field] = i;
  });

  const results: CustomerInput[] = [];

  for (let i = headerIdx + 1; i < rows.length; i++) {
    const cols = rows[i].map(c => String(c ?? '').trim());
    if (cols.every(v => v === '')) continue;

    const getVal = (field: keyof CustomerInput): string => {
      const idx = fieldIndexes[field];
      return idx !== undefined && idx < cols.length ? cols[idx] : '';
    };

    let fullName = getVal('fullName');
    if (firstNameIdx >= 0 || lastNameIdx >= 0) {
      const first = firstNameIdx >= 0 && firstNameIdx < cols.length ? cols[firstNameIdx] : '';
      const last = lastNameIdx >= 0 && lastNameIdx < cols.length ? cols[lastNameIdx] : '';
      const combined = `${first} ${last}`.trim();
      if (combined) fullName = combined;
    }
    if (!fullName) continue;

    const num = (s: string) => parseFloat(String(s).replace(/[₪,\s]/g, '')) || 0;
    const int = (s: string) => parseInt(String(s).replace(/[,\s]/g, ''), 10) || 0;

    const paymentMethodRaw = getVal('paymentMethod');
    let paymentMethod: 'bank' | 'cash' | 'mixed' = 'bank';
    if (/מזומן|cash/i.test(paymentMethodRaw)) paymentMethod = 'cash';
    else if (/משולב|mixed/i.test(paymentMethodRaw)) paymentMethod = 'mixed';

    const statusRaw = getVal('status');
    let status: 'active' | 'paused' | 'cancelled' = 'active';
    if (/מושהה|paused/i.test(statusRaw)) status = 'paused';
    else if (/מבוטל|cancelled|canceled/i.test(statusRaw)) status = 'cancelled';

    results.push({
      fullName,
      nickname: getVal('nickname'),
      idNumber: getVal('idNumber'),
      phone: getVal('phone'),
      phone2: getVal('phone2'),
      email: getVal('email'),
      city: getVal('city'),
      street: getVal('street'),
      houseNumber: getVal('houseNumber'),
      address: getVal('address'),
      notes: getVal('notes'),
      bankNumber: getVal('bankNumber'),
      branchNumber: getVal('branchNumber'),
      accountNumber: getVal('accountNumber'),
      accountHolderName: getVal('accountHolderName') || fullName,
      authorizationRef: getVal('authorizationRef'),
      authorizationDate: getVal('authorizationDate'),
      paymentMethod,
      bankAmount: num(getVal('bankAmount')),
      cashAmount: num(getVal('cashAmount')),
      amperes: int(getVal('amperes')),
      monthlyAmount: num(getVal('monthlyAmount')),
      billingCycle: 'monthly',
      startDate: new Date().toISOString().split('T')[0],
      endDate: '',
      chargeFrequencyMonths: 1,
      status,
      groupId: null,
      phaseId: null,
      tags: [],
      balance: 0,
    });
  }

  return results;
}

/** Generate a CSV template string with all supported fields and descriptions */
export function generateCSVTemplate(): string {
  const headers = [
    'שם פרטי', 'שם משפחה', 'כינוי', 'תעודת זהות', 'טלפון', 'טלפון 2',
    'אימייל', 'עיר', 'רחוב', 'מספר בית', 'כתובת', 'הערות',
    'מספר בנק', 'מספר סניף', 'מספר חשבון', 'שם בעל חשבון',
    'מספר אסמכתה', 'תאריך הרשאה',
    'אמצעי תשלום', 'סכום בנק', 'סכום מזומן', 'אמפרים', 'סכום חודשי', 'סטטוס',
  ];
  const example = [
    'ישראל', 'ישראלי', 'איזי', '123456789', '050-1234567', '',
    'email@example.com', 'תל אביב', 'הרצל', '10', '', '',
    '12', '620', '123456', '',
    '', '2024-01-15',
    'בנק', '', '', '25', '', 'פעיל',
  ];
  return headers.join(',') + '\n' + example.join(',');
}
