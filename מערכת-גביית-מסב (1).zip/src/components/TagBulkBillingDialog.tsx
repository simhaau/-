import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  FileSpreadsheet,
  Plus,
  Save,
  Trash2,
  Edit2,
  Search,
  Filter,
  ArrowUpDown,
  Download,
  CheckCircle2,
  RotateCcw,
  Sparkles,
  Zap,
  Coins,
  SlidersHorizontal,
  X,
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { toast } from 'sonner';
import {
  getRecurringTags,
  addRecurringTag,
  updateRecurringTag,
  deleteRecurringTag,
  getTagColorClasses,
  ensureCustomerRecurringCharges,
  TAG_COLOR_OPTIONS,
} from '@/lib/recurringTags';
import { updateCustomer, addActivity } from '@/lib/db';
import type { Customer, Group, Settings, RecurringTag, RecurringCharge, RecurringTagTypeMode } from '@/lib/types';

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  customers: Customer[];
  groups: Group[];
  settings: Settings | null;
  onUpdated?: () => void;
}

interface RowState {
  customerId: number;
  customerName: string;
  nickname: string;
  phone: string;
  groupName: string;
  originalChargeId?: string;
  type: 'amperes' | 'money';
  value: number; // amperes or amount
  originalType: 'amperes' | 'money';
  originalValue: number;
  isModified: boolean;
  otherChargesTotal: number; // monthly sum of other recurring charges for this customer
}

export default function TagBulkBillingDialog({
  open,
  onOpenChange,
  customers,
  groups,
  settings,
  onUpdated,
}: Props) {
  const [tags, setTags] = useState<RecurringTag[]>([]);
  const [activeTagId, setActiveTagId] = useState<string>('');
  const [rows, setRows] = useState<Record<number, RowState>>({});
  const [search, setSearch] = useState('');
  const [groupFilter, setGroupFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'has_charge' | 'no_charge'>('all');
  const [isSaving, setIsSaving] = useState(false);

  // Tag modal
  const [tagModalOpen, setTagModalOpen] = useState(false);
  const [editingTag, setEditingTag] = useState<RecurringTag | null>(null);
  const [tagName, setTagName] = useState('');
  const [tagTypeMode, setTagTypeMode] = useState<RecurringTagTypeMode>('flexible');
  const [tagColor, setTagColor] = useState('blue');
  const [tagDescription, setTagDescription] = useState('');

  // Bulk Apply state
  const [bulkApplyOpen, setBulkApplyOpen] = useState(false);
  const [bulkApplyType, setBulkApplyType] = useState<'amperes' | 'money'>('amperes');
  const [bulkApplyValue, setBulkApplyValue] = useState<number>(0);

  const pricePerAmpere = settings?.pricePerAmpere || 0;

  // Load tags
  const loadTags = () => {
    const list = getRecurringTags();
    setTags(list);
    if (list.length > 0 && (!activeTagId || !list.some(t => t.id === activeTagId))) {
      setActiveTagId(list[0].id);
    }
  };

  useEffect(() => {
    if (open) {
      loadTags();
    }
  }, [open]);

  const activeTag = useMemo(() => {
    return tags.find(t => t.id === activeTagId) || tags[0];
  }, [tags, activeTagId]);

  // Build spreadsheet rows for current active tag
  useEffect(() => {
    if (!activeTag || !open) return;

    const groupMap = new Map(groups.map(g => [g.id!, g.name]));
    const newRows: Record<number, RowState> = {};

    customers.forEach(c => {
      if (!c.id) return;
      const allCharges = ensureCustomerRecurringCharges(c);
      
      // Match active tag:
      // Either tagId matches, or if tag is tag_base and charge has 'בסיס'
      const matchedCharge = allCharges.find(
        ch => ch.tagId === activeTag.id || (activeTag.id === 'tag_base' && (ch.tagId === 'tag_base' || ch.label === 'חיוב בסיס' || ch.label === 'בסיס'))
      );

      // Sum of other recurring charges
      const otherCharges = allCharges.filter(ch => ch.id !== matchedCharge?.id);
      const otherChargesTotal = otherCharges.reduce((sum, ch) => {
        if (ch.type === 'amperes') return sum + (ch.amperes || 0) * pricePerAmpere;
        return sum + (ch.amount || 0);
      }, 0);

      const defaultType: 'amperes' | 'money' =
        activeTag.typeMode === 'amperes'
          ? 'amperes'
          : activeTag.typeMode === 'money'
          ? 'money'
          : matchedCharge?.type || 'amperes';

      const initialValue = matchedCharge
        ? matchedCharge.type === 'amperes'
          ? matchedCharge.amperes || 0
          : matchedCharge.amount || 0
        : 0;

      newRows[c.id] = {
        customerId: c.id,
        customerName: c.fullName,
        nickname: c.nickname || '',
        phone: c.phone || '',
        groupName: c.groupId ? groupMap.get(c.groupId) || 'ללא קבוצה' : 'ללא קבוצה',
        originalChargeId: matchedCharge?.id,
        type: defaultType,
        value: initialValue,
        originalType: defaultType,
        originalValue: initialValue,
        isModified: false,
        otherChargesTotal,
      };
    });

    setRows(newRows);
  }, [activeTag?.id, customers, groups, pricePerAmpere, open]);

  // Compute modified count
  const modifiedCount = useMemo(() => {
    return Object.values(rows).filter(r => r.isModified).length;
  }, [rows]);

  // Tag customer stats
  const tagStats = useMemo(() => {
    let totalCustomersWithCharge = 0;
    let totalAmperes = 0;
    let totalMonthlyAmount = 0;

    Object.values(rows).forEach(r => {
      if (r.value > 0) {
        totalCustomersWithCharge++;
        if (r.type === 'amperes') {
          totalAmperes += r.value;
          totalMonthlyAmount += r.value * pricePerAmpere;
        } else {
          totalMonthlyAmount += r.value;
        }
      }
    });

    return {
      totalCustomersWithCharge,
      totalAmperes,
      totalMonthlyAmount,
      totalCustomers: customers.length,
    };
  }, [rows, pricePerAmpere, customers.length]);

  // Tag counts map for pills
  const tagCountsMap = useMemo(() => {
    const counts: Record<string, number> = {};
    tags.forEach(t => {
      let count = 0;
      customers.forEach(c => {
        const charges = ensureCustomerRecurringCharges(c);
        const has = charges.some(
          ch => ch.tagId === t.id || (t.id === 'tag_base' && (ch.tagId === 'tag_base' || ch.label === 'חיוב בסיס' || ch.label === 'בסיס'))
        );
        if (has) count++;
      });
      counts[t.id] = count;
    });
    return counts;
  }, [tags, customers]);

  // Handlers for cell editing
  const handleValueChange = (customerId: number, newVal: number) => {
    setRows(prev => {
      const row = prev[customerId];
      if (!row) return prev;
      const isModified = newVal !== row.originalValue || row.type !== row.originalType;
      return {
        ...prev,
        [customerId]: {
          ...row,
          value: newVal,
          isModified,
        },
      };
    });
  };

  const handleTypeToggle = (customerId: number) => {
    if (activeTag?.typeMode !== 'flexible') return;
    setRows(prev => {
      const row = prev[customerId];
      if (!row) return prev;
      const newType: 'amperes' | 'money' = row.type === 'amperes' ? 'money' : 'amperes';
      const isModified = row.value !== row.originalValue || newType !== row.originalType;
      return {
        ...prev,
        [customerId]: {
          ...row,
          type: newType,
          isModified,
        },
      };
    });
  };

  const handleClearRow = (customerId: number) => {
    handleValueChange(customerId, 0);
  };

  // Keyboard navigation for spreadsheet inputs
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, currentIndex: number, filteredList: RowState[]) => {
    if (e.key === 'Enter' || e.key === 'ArrowDown') {
      e.preventDefault();
      const nextIndex = currentIndex + 1;
      if (nextIndex < filteredList.length) {
        const nextId = filteredList[nextIndex].customerId;
        const el = document.getElementById(`tag-cell-${nextId}`) as HTMLInputElement | null;
        el?.focus();
        el?.select();
      }
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      const prevIndex = currentIndex - 1;
      if (prevIndex >= 0) {
        const prevId = filteredList[prevIndex].customerId;
        const el = document.getElementById(`tag-cell-${prevId}`) as HTMLInputElement | null;
        el?.focus();
        el?.select();
      }
    }
  };

  // Save all modified rows
  const handleSaveAll = async () => {
    if (!activeTag) return;
    setIsSaving(true);

    try {
      const modifiedRows = Object.values(rows).filter(r => r.isModified);
      if (modifiedRows.length === 0) {
        toast.info('לא בוצעו שינויים לשמירה');
        setIsSaving(false);
        return;
      }

      const now = new Date().toISOString();

      for (const row of modifiedRows) {
        const customer = customers.find(c => c.id === row.customerId);
        if (!customer) continue;

        let allCharges = [...ensureCustomerRecurringCharges(customer)];

        if (row.value > 0) {
          // If customer already has this charge, update it
          const existingIdx = allCharges.findIndex(
            ch => ch.id === row.originalChargeId || ch.tagId === activeTag.id || (activeTag.id === 'tag_base' && (ch.tagId === 'tag_base' || ch.label === 'חיוב בסיס' || ch.label === 'בסיס'))
          );

          const chargeData: RecurringCharge = {
            id: row.originalChargeId || `rc_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
            label: activeTag.name,
            tagId: activeTag.id,
            type: row.type,
            amount: row.type === 'money' ? row.value : 0,
            amperes: row.type === 'amperes' ? row.value : 0,
            createdAt: now,
            updatedAt: now,
          };

          if (existingIdx !== -1) {
            allCharges[existingIdx] = chargeData;
          } else {
            allCharges.push(chargeData);
          }
        } else {
          // Value is 0: remove charge
          allCharges = allCharges.filter(
            ch => ch.id !== row.originalChargeId && ch.tagId !== activeTag.id && !(activeTag.id === 'tag_base' && (ch.label === 'חיוב בסיס' || ch.label === 'בסיס'))
          );
        }

        const newAmperes = allCharges.filter(r => r.type === 'amperes').reduce((s, r) => s + (r.amperes || 0), 0);
        const newMonthly = allCharges.reduce((s, r) => {
          if (r.type === 'amperes') return s + (r.amperes || 0) * pricePerAmpere;
          return s + (r.amount || 0);
        }, 0);

        customer.recurringCharges = allCharges;
        customer.amperes = newAmperes;
        customer.monthlyAmount = newMonthly;

        await updateCustomer({
          ...customer,
          recurringCharges: allCharges,
          amperes: newAmperes,
          monthlyAmount: newMonthly,
          updatedAt: now,
        });
      }

      await addActivity({
        type: 'extra_charge',
        description: `עודכנו חיובי תגית "${activeTag.name}" עבור ${modifiedRows.length} לקוחות`,
        reversible: false,
        createdAt: now,
      });

      // Update original states
      setRows(prev => {
        const next = { ...prev };
        modifiedRows.forEach(r => {
          if (next[r.customerId]) {
            next[r.customerId] = {
              ...next[r.customerId],
              originalValue: r.value,
              originalType: r.type,
              isModified: false,
            };
          }
        });
        return next;
      });

      toast.success(`נשמרו בהצלחה ${modifiedRows.length} לקוחות בתגית "${activeTag.name}"`);
      onUpdated?.();
    } catch (err) {
      console.error('Failed to save bulk recurring charges:', err);
      toast.error('שגיאה בשמירת השינויים');
    } finally {
      setIsSaving(false);
    }
  };

  // Reset changes
  const handleResetAll = () => {
    setRows(prev => {
      const next = { ...prev };
      Object.keys(next).forEach(idStr => {
        const id = Number(idStr);
        next[id] = {
          ...next[id],
          value: next[id].originalValue,
          type: next[id].originalType,
          isModified: false,
        };
      });
      return next;
    });
    toast.info('השינויים שלא נשמרו אופסו');
  };

  // Bulk apply value to filtered customers
  const handleApplyBulkValue = () => {
    if (bulkApplyValue < 0) {
      toast.error('הזן ערך תקין');
      return;
    }
    const filtered = getFilteredRows();
    if (filtered.length === 0) {
      toast.error('אין לקוחות במסנן הנוכחי');
      return;
    }

    setRows(prev => {
      const next = { ...prev };
      filtered.forEach(r => {
        const row = next[r.customerId];
        if (row) {
          const type = activeTag?.typeMode === 'flexible' ? bulkApplyType : row.type;
          next[r.customerId] = {
            ...row,
            type,
            value: bulkApplyValue,
            isModified: bulkApplyValue !== row.originalValue || type !== row.originalType,
          };
        }
      });
      return next;
    });

    setBulkApplyOpen(false);
    toast.success(`הוחל ערך ${bulkApplyValue} על ${filtered.length} לקוחות`);
  };

  // Tag creation / editing
  const handleOpenNewTag = () => {
    setEditingTag(null);
    setTagName('');
    setTagTypeMode('flexible');
    setTagColor('blue');
    setTagDescription('');
    setTagModalOpen(true);
  };

  const handleOpenEditTag = () => {
    if (!activeTag) return;
    setEditingTag(activeTag);
    setTagName(activeTag.name);
    setTagTypeMode(activeTag.typeMode);
    setTagColor(activeTag.color || 'blue');
    setTagDescription(activeTag.description || '');
    setTagModalOpen(true);
  };

  const handleSaveTagModal = () => {
    if (!tagName.trim()) {
      toast.error('הזן שם לתגית');
      return;
    }
    if (editingTag) {
      const updated: RecurringTag = {
        ...editingTag,
        name: tagName.trim(),
        typeMode: tagTypeMode,
        color: tagColor,
        description: tagDescription.trim() || undefined,
      };
      updateRecurringTag(updated);
      toast.success(`תגית "${updated.name}" עודכנה`);
    } else {
      const created = addRecurringTag({
        name: tagName.trim(),
        typeMode: tagTypeMode,
        color: tagColor,
        description: tagDescription.trim() || undefined,
      });
      setActiveTagId(created.id);
      toast.success(`תגית "${created.name}" נוצרה`);
    }
    loadTags();
    setTagModalOpen(false);
  };

  const handleDeleteTag = () => {
    if (!editingTag) return;
    deleteRecurringTag(editingTag.id);
    toast.success(`תגית "${editingTag.name}" נמחקה`);
    loadTags();
    setTagModalOpen(false);
  };

  // Export to Excel
  const handleExportExcel = () => {
    if (!activeTag) return;
    const filtered = getFilteredRows();

    const data = filtered.map((r, i) => {
      const tagMonthly = r.type === 'amperes' ? r.value * pricePerAmpere : r.value;
      const totalCustomerMonthly = tagMonthly + r.otherChargesTotal;
      return {
        '#': i + 1,
        'שם לקוח': r.customerName,
        'כינוי': r.nickname,
        'טלפון': r.phone,
        'קבוצה': r.groupName,
        'סוג חיוב': r.type === 'amperes' ? 'אמפרים' : 'סכום קבוע (₪)',
        'ערך בתגית': r.value,
        'חיוב חודשי מהתגית (₪)': tagMonthly,
        'חיובים נוספים (₪)': r.otherChargesTotal,
        'סה"כ חודשי כולל (₪)': totalCustomerMonthly,
      };
    });

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, activeTag.name.substring(0, 30));
    XLSX.writeFile(wb, `חיובים_קבועים_${activeTag.name}.xlsx`);
    toast.success('קובץ הנתונים יוצא בהצלחה');
  };

  // Filtered rows for display
  const getFilteredRows = (): RowState[] => {
    return Object.values(rows).filter(r => {
      // Search filter
      if (search.trim()) {
        const q = search.trim().toLowerCase();
        const matches =
          r.customerName.toLowerCase().includes(q) ||
          r.nickname.toLowerCase().includes(q) ||
          r.phone.includes(q);
        if (!matches) return false;
      }

      // Group filter
      if (groupFilter !== 'all') {
        const customer = customers.find(c => c.id === r.customerId);
        if (customer && String(customer.groupId) !== groupFilter) return false;
      }

      // Status filter
      if (statusFilter === 'has_charge' && r.value <= 0) return false;
      if (statusFilter === 'no_charge' && r.value > 0) return false;

      return true;
    });
  };

  const filteredRows = useMemo(() => getFilteredRows(), [rows, search, groupFilter, statusFilter, customers]);

  const activeTagColor = getTagColorClasses(activeTag?.color);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl w-full h-[92vh] flex flex-col p-0 overflow-hidden bg-background">
        {/* Header */}
        <div className="px-6 py-4 border-b border-border/60 bg-card/80 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <DialogTitle className="text-lg font-bold flex items-center gap-2">
                עריכת חיובים קבועים לפי תגיות
                <Badge variant="outline" className="text-xs font-normal">
                  טבלה מהירה
                </Badge>
              </DialogTitle>
              <DialogDescription className="text-xs text-muted-foreground">
                צפייה ועריכה מרוכזת ומהירה של החיובים החודשיים לכל הלקוחות לפי תגית
              </DialogDescription>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" className="gap-1.5 text-xs" onClick={handleExportExcel}>
              <Download className="w-3.5 h-3.5" />
              ייצוא נתונים
            </Button>
            <Button size="sm" variant="outline" className="gap-1.5 text-xs" onClick={handleOpenEditTag}>
              <Edit2 className="w-3.5 h-3.5" />
              עריכת תגית
            </Button>
            <Button size="sm" className="gap-1.5 text-xs" onClick={handleOpenNewTag}>
              <Plus className="w-3.5 h-3.5" />
              תגית חדשה
            </Button>
          </div>
        </div>

        {/* Tag Navigation Bar (Pills) */}
        <div className="px-6 py-2.5 bg-muted/40 border-b border-border/40 flex items-center gap-2 overflow-x-auto shrink-0 scrollbar-none">
          <span className="text-xs font-semibold text-muted-foreground shrink-0 ml-1">תגיות:</span>
          {tags.map(t => {
            const isSelected = t.id === activeTag?.id;
            const color = getTagColorClasses(t.color);
            const count = tagCountsMap[t.id] || 0;
            return (
              <button
                key={t.id}
                onClick={() => {
                  if (modifiedCount > 0) {
                    if (confirm('ישנם שינויים שלא נשמרו. האם להמשיך לתגית אחרת?')) {
                      setActiveTagId(t.id);
                    }
                  } else {
                    setActiveTagId(t.id);
                  }
                }}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap border cursor-pointer ${
                  isSelected
                    ? `${color.bg} ${color.text} ${color.border} ring-2 ring-primary/40 shadow-sm font-semibold`
                    : 'bg-card text-muted-foreground hover:text-foreground hover:bg-muted/70 border-border/60'
                }`}
              >
                <span className={`w-2 h-2 rounded-full ${color.dot}`} />
                <span>{t.name}</span>
                <span className="bg-background/80 px-1.5 py-0.2 rounded-full text-[10px] font-mono border border-border/50">
                  {count}
                </span>
                <span className="text-[10px] opacity-70">
                  {t.typeMode === 'amperes' ? '(A)' : t.typeMode === 'money' ? '(₪)' : '(גמיש)'}
                </span>
              </button>
            );
          })}
        </div>

        {/* Tag KPI Stats & Controls */}
        <div className="px-6 py-3 border-b border-border/40 bg-card/40 flex flex-wrap items-center justify-between gap-4 shrink-0">
          {/* 4 Mini-KPI stats */}
          <div className="flex items-center gap-6 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground">תגית פעילה:</span>
              <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-bold border ${activeTagColor.bg} ${activeTagColor.text} ${activeTagColor.border}`}>
                {activeTag?.name}
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-muted-foreground">לקוחות מחויבים:</span>
              <span className="font-bold text-foreground font-mono">
                {tagStats.totalCustomersWithCharge} / {tagStats.totalCustomers}
              </span>
            </div>
            {activeTag?.typeMode !== 'money' && tagStats.totalAmperes > 0 && (
              <div className="flex items-center gap-1.5">
                <span className="text-muted-foreground">סה"כ אמפרים:</span>
                <span className="font-bold text-amber-600 dark:text-amber-400 font-mono">
                  {tagStats.totalAmperes}A
                </span>
              </div>
            )}
            <div className="flex items-center gap-1.5">
              <span className="text-muted-foreground">הכנסה חודשית מתגית:</span>
              <span className="font-bold text-emerald-600 dark:text-emerald-400 font-mono text-sm">
                ₪{tagStats.totalMonthlyAmount.toLocaleString()}
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-muted-foreground">
              <span>תעריף אמפר:</span>
              <span className="font-medium text-foreground">₪{pricePerAmpere}</span>
            </div>
          </div>

          {/* Quick Filters */}
          <div className="flex items-center gap-2">
            <div className="relative w-48">
              <Search className="w-3.5 h-3.5 absolute right-2.5 top-2.5 text-muted-foreground" />
              <Input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="חיפוש לקוח / טלפון..."
                className="h-8 text-xs pr-8"
              />
            </div>

            <Select value={groupFilter} onValueChange={setGroupFilter}>
              <SelectTrigger className="h-8 text-xs w-36">
                <SelectValue placeholder="קבוצה" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">כל הקבוצות</SelectItem>
                {groups.map(g => (
                  <SelectItem key={g.id} value={String(g.id)}>
                    {g.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={statusFilter} onValueChange={v => setStatusFilter(v as 'all' | 'has_charge' | 'no_charge')}>
              <SelectTrigger className="h-8 text-xs w-36">
                <SelectValue placeholder="סטטוס" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">כל הלקוחות</SelectItem>
                <SelectItem value="has_charge">רק מחויבים (&gt;0)</SelectItem>
                <SelectItem value="no_charge">ללא חיוב (0)</SelectItem>
              </SelectContent>
            </Select>

            <Button
              size="sm"
              variant="secondary"
              className="h-8 text-xs gap-1.5"
              onClick={() => {
                setBulkApplyType(activeTag?.typeMode === 'money' ? 'money' : 'amperes');
                setBulkApplyOpen(true);
              }}
            >
              <Sparkles className="w-3 h-3 text-primary" />
              החלה גורפת
            </Button>
          </div>
        </div>

        {/* Excel Spreadsheet Table */}
        <div className="flex-1 overflow-auto">
          <table className="w-full text-right border-collapse text-xs">
            <thead className="sticky top-0 bg-muted/80 backdrop-blur z-10 border-b border-border text-muted-foreground font-semibold">
              <tr>
                <th className="py-2.5 px-4 w-12 text-center">#</th>
                <th className="py-2.5 px-4">שם לקוח</th>
                <th className="py-2.5 px-3">קבוצה</th>
                <th className="py-2.5 px-3 w-40">סוג חיוב בתגית</th>
                <th className="py-2.5 px-3 w-44">ערך בתגית (עריכה ישירה)</th>
                <th className="py-2.5 px-3 w-36">חיוב חודשי מתגית</th>
                <th className="py-2.5 px-3 w-36">סה"כ חודשי כולל ללקוח</th>
                <th className="py-2.5 px-3 w-16 text-center">איפוס</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/40">
              {filteredRows.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-muted-foreground">
                    לא נמצאו לקוחות התואמים לסינון
                  </td>
                </tr>
              ) : (
                filteredRows.map((row, idx) => {
                  const tagMonthly = row.type === 'amperes' ? row.value * pricePerAmpere : row.value;
                  const totalCustomerMonthly = tagMonthly + row.otherChargesTotal;
                  const isRowModified = row.isModified;

                  return (
                    <tr
                      key={row.customerId}
                      className={`hover:bg-muted/40 transition-colors ${
                        isRowModified ? 'bg-primary/5 font-medium' : ''
                      }`}
                    >
                      <td className="py-2 px-4 text-center font-mono text-[11px] text-muted-foreground">
                        {idx + 1}
                      </td>

                      <td className="py-2 px-4">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-foreground">{row.customerName}</span>
                          {row.nickname && (
                            <span className="text-[11px] text-muted-foreground">({row.nickname})</span>
                          )}
                          {isRowModified && (
                            <span className="w-1.5 h-1.5 rounded-full bg-primary" title="שינוי לא שמור" />
                          )}
                        </div>
                        {row.phone && <p className="text-[10px] text-muted-foreground font-mono">{row.phone}</p>}
                      </td>

                      <td className="py-2 px-3">
                        <Badge variant="outline" className="text-[10px] font-normal py-0">
                          {row.groupName}
                        </Badge>
                      </td>

                      {/* Type Toggle or Fixed Badge */}
                      <td className="py-2 px-3">
                        {activeTag?.typeMode === 'flexible' ? (
                          <div className="inline-flex rounded-md border border-border p-0.5 bg-background shadow-xs">
                            <button
                              type="button"
                              onClick={() => {
                                if (row.type !== 'amperes') handleTypeToggle(row.customerId);
                              }}
                              className={`px-2 py-0.5 text-[11px] rounded transition-all cursor-pointer ${
                                row.type === 'amperes'
                                  ? 'bg-amber-500/15 text-amber-700 dark:text-amber-400 font-bold'
                                  : 'text-muted-foreground hover:text-foreground'
                              }`}
                            >
                              אמפרים (A)
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                if (row.type !== 'money') handleTypeToggle(row.customerId);
                              }}
                              className={`px-2 py-0.5 text-[11px] rounded transition-all cursor-pointer ${
                                row.type === 'money'
                                  ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 font-bold'
                                  : 'text-muted-foreground hover:text-foreground'
                              }`}
                            >
                              סכום (₪)
                            </button>
                          </div>
                        ) : (
                          <Badge variant="secondary" className="text-[11px] font-normal">
                            {row.type === 'amperes' ? 'אמפרים (A)' : 'סכום קבוע (₪)'}
                          </Badge>
                        )}
                      </td>

                      {/* Spreadsheet Cell: Live editable input */}
                      <td className="py-2 px-3">
                        <div className="relative">
                          <Input
                            id={`tag-cell-${row.customerId}`}
                            type="number"
                            min="0"
                            step="any"
                            value={row.value === 0 ? '' : row.value}
                            onChange={e => handleValueChange(row.customerId, Number(e.target.value) || 0)}
                            onKeyDown={e => handleKeyDown(e, idx, filteredRows)}
                            onFocus={e => e.target.select()}
                            placeholder="0"
                            className={`h-8 font-mono text-sm pl-7 text-left font-semibold transition-all ${
                              isRowModified
                                ? 'border-primary ring-1 ring-primary/40 bg-background'
                                : 'border-border/70 focus:border-primary'
                            }`}
                            dir="ltr"
                          />
                          <span className="absolute left-2.5 top-2 text-[11px] font-semibold text-muted-foreground pointer-events-none">
                            {row.type === 'amperes' ? 'A' : '₪'}
                          </span>
                        </div>
                      </td>

                      {/* Calculated tag monthly amount */}
                      <td className="py-2 px-3">
                        <span className="font-mono font-bold text-foreground">
                          ₪{tagMonthly.toLocaleString()}
                        </span>
                        {row.type === 'amperes' && row.value > 0 && (
                          <p className="text-[10px] text-muted-foreground">
                            {row.value}A × ₪{pricePerAmpere}
                          </p>
                        )}
                      </td>

                      {/* Customer Total Monthly */}
                      <td className="py-2 px-3">
                        <span className="font-mono font-bold text-primary">
                          ₪{totalCustomerMonthly.toLocaleString()}
                        </span>
                        {row.otherChargesTotal > 0 && (
                          <p className="text-[10px] text-muted-foreground">
                            (+₪{row.otherChargesTotal.toLocaleString()} נוספים)
                          </p>
                        )}
                      </td>

                      {/* Clear / Delete */}
                      <td className="py-2 px-3 text-center">
                        {row.value > 0 && (
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive"
                            title="אפס חיוב בתגית זו"
                            onClick={() => handleClearRow(row.customerId)}
                          >
                            <X className="w-3.5 h-3.5" />
                          </Button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Sticky Footer Bar with Save / Status */}
        <div className="px-6 py-3 border-t border-border/60 bg-card flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            {modifiedCount > 0 ? (
              <div className="flex items-center gap-2 text-xs text-primary font-semibold">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-primary"></span>
                </span>
                יש {modifiedCount} שינויים שלא נשמרו
              </div>
            ) : (
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <CheckCircle2 className="w-3.5 h-3.5 text-success" />
                כל השינויים נשמרו ומסונכרנים
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            {modifiedCount > 0 && (
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5 text-xs"
                onClick={handleResetAll}
                disabled={isSaving}
              >
                <RotateCcw className="w-3.5 h-3.5" />
                איפוס שינויים
              </Button>
            )}

            <Button
              variant="outline"
              size="sm"
              className="text-xs"
              onClick={() => onOpenChange(false)}
            >
              סגור
            </Button>

            <Button
              size="sm"
              className="gap-1.5 text-xs font-semibold"
              onClick={handleSaveAll}
              disabled={isSaving || modifiedCount === 0}
            >
              <Save className="w-3.5 h-3.5" />
              {isSaving ? 'שומר...' : `שמור שינויים (${modifiedCount})`}
            </Button>
          </div>
        </div>

        {/* Create / Edit Tag Modal */}
        <Dialog open={tagModalOpen} onOpenChange={setTagModalOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingTag ? `עריכת תגית: ${editingTag.name}` : 'יצירת תגית חיוב חדשה'}
              </DialogTitle>
              <DialogDescription>
                הגדר את מאפייני התגית לחיובים קבועים במערכת.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-2">
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold">שם התגית</Label>
                <Input
                  value={tagName}
                  onChange={e => setTagName(e.target.value)}
                  placeholder="למשל: מחסן, שמירה, מזגן, שכירות..."
                  autoFocus
                />
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-semibold">סוג החיוב בתגית</Label>
                <Select
                  value={tagTypeMode}
                  onValueChange={v => setTagTypeMode(v as RecurringTagTypeMode)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="flexible">
                      גמיש - לפעמים סכום ולפעמים אמפרים (בחירה פר לקוח)
                    </SelectItem>
                    <SelectItem value="amperes">אמפרים בלבד (A)</SelectItem>
                    <SelectItem value="money">סכום קבוע בלבד (₪)</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-[11px] text-muted-foreground">
                  {tagTypeMode === 'flexible' && 'תגית גמישה מאפשרת לקבוע עבור חלק מהלקוחות אמפרים ועבור אחרים סכום כספי.'}
                  {tagTypeMode === 'amperes' && 'כל לקוח בתגית זו יחויב לפי אמפרים × תעריף לאמפר.'}
                  {tagTypeMode === 'money' && 'כל לקוח בתגית זו יחויב בסכום כספי קבוע.'}
                </p>
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-semibold">צבע תגית</Label>
                <div className="flex flex-wrap gap-2 pt-1">
                  {TAG_COLOR_OPTIONS.map(opt => (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => setTagColor(opt.value)}
                      className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs border transition-all cursor-pointer ${
                        tagColor === opt.value
                          ? 'ring-2 ring-primary border-primary font-bold shadow-xs'
                          : 'border-border/60 hover:border-border'
                      } ${opt.bg} ${opt.text}`}
                    >
                      <span className={`w-2 h-2 rounded-full ${opt.dot}`} />
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-semibold">תיאור (אופציונלי)</Label>
                <Input
                  value={tagDescription}
                  onChange={e => setTagDescription(e.target.value)}
                  placeholder="הערה או פירוט על השימוש בתגית זו"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t mt-2">
              {editingTag ? (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="text-destructive hover:bg-destructive/10 text-xs"
                  onClick={handleDeleteTag}
                >
                  <Trash2 className="w-3.5 h-3.5 ml-1" />
                  מחק תגית
                </Button>
              ) : <div />}

              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => setTagModalOpen(false)}>
                  ביטול
                </Button>
                <Button size="sm" onClick={handleSaveTagModal}>
                  {editingTag ? 'שמור שינויים' : 'צור תגית'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Bulk Apply Sub-Dialog */}
        <Dialog open={bulkApplyOpen} onOpenChange={setBulkApplyOpen}>
          <DialogContent className="max-w-sm">
            <DialogHeader>
              <DialogTitle>החלת ערך גורפת</DialogTitle>
              <DialogDescription>
                החלת ערך אחיד על כל {filteredRows.length} הלקוחות שמופיעים כרגע בסינון בתגית "{activeTag?.name}".
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-3.5 py-2">
              {activeTag?.typeMode === 'flexible' && (
                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold">סוג חיוב להחלה</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      type="button"
                      variant={bulkApplyType === 'amperes' ? 'default' : 'outline'}
                      size="sm"
                      className="text-xs"
                      onClick={() => setBulkApplyType('amperes')}
                    >
                      אמפרים (A)
                    </Button>
                    <Button
                      type="button"
                      variant={bulkApplyType === 'money' ? 'default' : 'outline'}
                      size="sm"
                      className="text-xs"
                      onClick={() => setBulkApplyType('money')}
                    >
                      סכום (₪)
                    </Button>
                  </div>
                </div>
              )}

              <div className="space-y-1.5">
                <Label className="text-xs font-semibold">
                  {bulkApplyType === 'amperes' ? 'כמות אמפרים (A)' : 'סכום חודשי קבוע (₪)'}
                </Label>
                <Input
                  type="number"
                  min="0"
                  step="any"
                  value={bulkApplyValue || ''}
                  onChange={e => setBulkApplyValue(Number(e.target.value) || 0)}
                  dir="ltr"
                  placeholder="0"
                  className="font-mono text-base"
                  autoFocus
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t">
              <Button variant="outline" size="sm" onClick={() => setBulkApplyOpen(false)}>
                ביטול
              </Button>
              <Button size="sm" onClick={handleApplyBulkValue}>
                החל על {filteredRows.length} לקוחות
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </DialogContent>
    </Dialog>
  );
}
