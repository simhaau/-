import { useState, useEffect, useMemo } from 'react';
import { Search, Trash2, History, Banknote, CreditCard, PlusCircle, Calendar, XCircle, MoreHorizontal, Undo2, Redo2, UserPlus, Settings, Bell, Users, Zap, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { getAllActivities, deleteActivity, getAllBatches, deleteBatch, getAllDebts, updateDebt, deleteDebt, deleteCustomer, addDebt, addCustomer, addActivity, updateActivity, updateCustomer, getSettings, saveSettings, getAllGroups, updateGroup, getAllPhases, updatePhase } from '@/lib/db';
import type { ActivityLog } from '@/lib/types';
import { toast } from 'sonner';

const typeConfig: Record<string, { label: string; icon: typeof Banknote; color: string }> = {
  payment: { label: 'תשלום', icon: Banknote, color: 'text-success' },
  batch: { label: 'אצווה', icon: CreditCard, color: 'text-primary' },
  batch_collected: { label: 'אצווה נגבתה', icon: CreditCard, color: 'text-success' },
  batch_cancelled: { label: 'אצווה בוטלה', icon: XCircle, color: 'text-destructive' },
  extra_charge: { label: 'חיוב נוסף', icon: PlusCircle, color: 'text-warning' },
  bulk_charge: { label: 'חיוב גורף', icon: Zap, color: 'text-warning' },
  advance: { label: 'מראש', icon: Calendar, color: 'text-primary' },
  debt_created: { label: 'חוב נוצר', icon: PlusCircle, color: 'text-muted-foreground' },
  debt_deleted: { label: 'חוב נמחק', icon: XCircle, color: 'text-destructive' },
  cash_override: { label: 'מזומן', icon: Banknote, color: 'text-success' },
  customer_created: { label: 'לקוח חדש', icon: UserPlus, color: 'text-success' },
  customer_updated: { label: 'לקוח עודכן', icon: Users, color: 'text-primary' },
  customer_deleted: { label: 'לקוח נמחק', icon: XCircle, color: 'text-destructive' },
  settings_updated: { label: 'הגדרות', icon: Settings, color: 'text-muted-foreground' },
  phase_created: { label: 'פזה חדשה', icon: Zap, color: 'text-warning' },
  group_created: { label: 'קבוצה חדשה', icon: Users, color: 'text-primary' },
  reminder: { label: 'תזכורת', icon: Bell, color: 'text-primary' },
  other: { label: 'אחר', icon: MoreHorizontal, color: 'text-muted-foreground' },
};

export default function ActivityLogView() {
  const [activities, setActivities] = useState<ActivityLog[]>([]);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [deleteTarget, setDeleteTarget] = useState<ActivityLog | null>(null);
  const [reverseTarget, setReverseTarget] = useState<ActivityLog | null>(null);
  const [redoTarget, setRedoTarget] = useState<ActivityLog | null>(null);
  const [detailsTarget, setDetailsTarget] = useState<ActivityLog | null>(null);

  const loadData = () => {
    getAllActivities().then(a => setActivities(a.sort((x, y) => y.createdAt.localeCompare(x.createdAt))));
  };

  useEffect(() => { loadData(); }, []);

  const filtered = useMemo(() => {
    let result = activities;
    if (search) {
      const q = search.toLowerCase();
      result = result.filter(a => a.description.toLowerCase().includes(q) || a.customerName?.toLowerCase().includes(q));
    }
    if (typeFilter !== 'all') result = result.filter(a => a.type === typeFilter);
    return result;
  }, [activities, search, typeFilter]);

  const handleDelete = async () => {
    if (!deleteTarget?.id) return;
    await deleteActivity(deleteTarget.id);
    toast.success('הפעולה נמחקה מההיסטוריה');
    setDeleteTarget(null);
    loadData();
  };

  const handleReverse = async () => {
    if (!reverseTarget) return;

    try {
      const type = reverseTarget.type;
      const reverseData = reverseTarget.reverseData ? JSON.parse(reverseTarget.reverseData) : null;

      if (type === 'batch' || type === 'batch_collected') {
        if (reverseData?.batchId) {
          const batches = await getAllBatches();
          const batch = batches.find(b => b.id === reverseData.batchId);
          if (batch) {
            const allDebts = await getAllDebts();
            const batchTag = `באצווה #${batch.id}`;
            for (const t of batch.transactions.filter(tx => tx.status === 'included')) {
              const customerDebts = allDebts.filter(d => {
                if (d.customerId !== t.customerId) return false;
                if (d.status === 'pending_collection') return true;
                if (batch.status === 'collected' && d.notes?.includes(batchTag)) return true;
                return false;
              });
              for (const d of customerDebts) {
                const wasCollected = batch.status === 'collected' && d.notes?.includes(batchTag);
                await updateDebt({
                  ...d,
                  status: 'unpaid',
                  paidAmount: wasCollected ? 0 : d.paidAmount,
                  paidDate: wasCollected ? '' : d.paidDate,
                  notes: (d.notes || '')
                    .replace(` | נגבה ${batchTag}`, '')
                    .replace(`נגבה ${batchTag}`, '')
                    .replace(` | ממתין לגביה ${batchTag}`, '')
                    .replace(`ממתין לגביה ${batchTag}`, ''),
                });
              }
            }
            await deleteBatch(batch.id!);
          }
        }
        toast.success('האצווה בוטלה — חובות שוחזרו');
      } else if (type === 'extra_charge' || type === 'debt_created' || type === 'bulk_charge') {
        // delete created debts
        if (Array.isArray(reverseData?.debtIds)) {
          for (const id of reverseData.debtIds) {
            try { await deleteDebt(id); } catch (e) { console.error(e); }
          }
        } else if (reverseData?.debtId) {
          await deleteDebt(reverseData.debtId);
        } else if (reverseTarget.customerId && reverseTarget.amount) {
          const allDebts = await getAllDebts();
          const matchingDebt = allDebts.find(d =>
            d.customerId === reverseTarget.customerId &&
            d.amount === reverseTarget.amount &&
            (d.status === 'unpaid' || d.status === 'pending_collection')
          );
          if (matchingDebt) await deleteDebt(matchingDebt.id!);
        }
        toast.success('החיוב בוטל');
      } else if (type === 'payment' || type === 'other') {
        // mark paid/unpaid undo: restore prev fields
        if (reverseData?.debtId && reverseData?.prev) {
          const allDebts = await getAllDebts();
          const d = allDebts.find(x => x.id === reverseData.debtId);
          if (d) {
            await updateDebt({ ...d, ...reverseData.prev });
          }
        } else if (Array.isArray(reverseData?.debtIds) && reverseData?.restored) {
          // split debt undo
          for (const id of reverseData.debtIds) {
            try { await deleteDebt(id); } catch (e) { console.error(e); }
          }
          const r = reverseData.restored;
          delete r.id;
          await addDebt(r);
        }
        toast.success('הפעולה בוטלה');
      } else if (type === 'debt_deleted') {
        if (reverseData?.restoreDebt) {
          const r = { ...reverseData.restoreDebt };
          delete r.id;
          await addDebt(r);
          toast.success('החיוב שוחזר');
        }
      } else if (type === 'customer_created') {
        if (reverseData?.customerId) await deleteCustomer(reverseData.customerId);
        toast.success('הלקוח נמחק');
      } else if (type === 'customer_deleted') {
        if (reverseData?.restoreCustomer) {
          const r = { ...reverseData.restoreCustomer };
          delete r.id;
          await addCustomer(r);
          toast.success('הלקוח שוחזר');
        }
      } else {
        toast.error('לא ניתן לבטל פעולה מסוג זה');
        setReverseTarget(null);
        return;
      }

      await addActivity({
        type: 'other',
        description: `ביטול פעולה: ${reverseTarget.description}`,
        customerId: reverseTarget.customerId,
        customerName: reverseTarget.customerName,
        amount: reverseTarget.amount,
        createdAt: new Date().toISOString(),
      });

      // Mark original as reversed (keeps it in history so user can Redo)
      await updateActivity({ ...reverseTarget, reversedAt: new Date().toISOString() });
    } catch (e) {
      console.error('Reverse error:', e);
      toast.error('שגיאה בביטול הפעולה');
    }

    setReverseTarget(null);
    loadData();
  };

  // Redo: re-apply the effect of a previously reversed activity
  const handleRedo = async () => {
    if (!redoTarget) return;
    try {
      const type = redoTarget.type;
      const reverseData = redoTarget.reverseData ? JSON.parse(redoTarget.reverseData) : null;

      if (type === 'debt_deleted') {
        // originally deleted a debt; redo = delete it again if it exists
        if (reverseData?.restoreDebt) {
          const all = await getAllDebts();
          const d = all.find(x => x.customerId === reverseData.restoreDebt.customerId && x.month === reverseData.restoreDebt.month && x.amount === reverseData.restoreDebt.amount);
          if (d) await deleteDebt(d.id!);
        }
      } else if (type === 'customer_deleted') {
        if (reverseData?.restoreCustomer) {
          const all = await (await import('@/lib/db')).getAllCustomers();
          const c = all.find(x => x.fullName === reverseData.restoreCustomer.fullName && x.idNumber === reverseData.restoreCustomer.idNumber);
          if (c) await deleteCustomer(c.id!);
        }
      } else if (type === 'payment' || type === 'other') {
        // debtId + prev were stored; redo means re-apply the change (mark paid etc.)
        // We can't fully re-derive; simplest: swap prev with current
        if (reverseData?.debtId && reverseData?.prev) {
          const all = await getAllDebts();
          const d = all.find(x => x.id === reverseData.debtId);
          if (d) {
            const newPrev = { paidAmount: d.paidAmount, status: d.status, paidDate: d.paidDate, notes: d.notes };
            // Assume original action set it to a paid-like state; we swap
            await updateDebt({ ...d, ...reverseData.prev });
            // update stored prev so next undo works
            await updateActivity({ ...redoTarget, reverseData: JSON.stringify({ ...reverseData, prev: newPrev }), reversedAt: undefined });
            await addActivity({
              type: 'other',
              description: `החזרת פעולה: ${redoTarget.description}`,
              customerId: redoTarget.customerId,
              customerName: redoTarget.customerName,
              createdAt: new Date().toISOString(),
            });
            toast.success('הפעולה הוחזרה');
            setRedoTarget(null);
            loadData();
            return;
          }
        }
      } else {
        toast.error('החזרה אינה נתמכת עבור פעולה זו — בצע אותה מחדש ידנית');
        setRedoTarget(null);
        return;
      }

      // clear reversedAt to show as active again
      await updateActivity({ ...redoTarget, reversedAt: undefined });
      await addActivity({
        type: 'other',
        description: `החזרת פעולה: ${redoTarget.description}`,
        customerId: redoTarget.customerId,
        customerName: redoTarget.customerName,
        createdAt: new Date().toISOString(),
      });
      toast.success('הפעולה הוחזרה');
    } catch (e) {
      console.error('Redo error:', e);
      toast.error('שגיאה בהחזרת הפעולה');
    }
    setRedoTarget(null);
    loadData();
  };

  const canReverse = (a: ActivityLog) => {
    if (a.reversedAt) return false;
    if (a.reversible) return true;
    return ['batch', 'batch_collected', 'extra_charge', 'debt_created', 'bulk_charge', 'customer_created'].includes(a.type);
  };

  const canRedo = (a: ActivityLog) => !!a.reversedAt;

  const parseDiff = (a: ActivityLog): Array<{ field: string; before: string; after: string }> => {
    if (!a.diff) return [];
    try {
      const d = JSON.parse(a.diff);
      return Array.isArray(d) ? d : [];
    } catch { return []; }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[250px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="חיפוש פעולה..." value={search} onChange={e => setSearch(e.target.value)} className="pr-10" />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">כל הפעולות</SelectItem>
            <SelectItem value="payment">תשלום</SelectItem>
            <SelectItem value="batch">אצווה</SelectItem>
            <SelectItem value="batch_collected">אצווה נגבתה</SelectItem>
            <SelectItem value="batch_cancelled">אצווה בוטלה</SelectItem>
            <SelectItem value="extra_charge">חיוב נוסף</SelectItem>
            <SelectItem value="bulk_charge">חיוב גורף</SelectItem>
            <SelectItem value="advance">מראש</SelectItem>
            <SelectItem value="cash_override">מזומן</SelectItem>
            <SelectItem value="debt_created">חוב נוצר</SelectItem>
            <SelectItem value="debt_deleted">מחיקות</SelectItem>
            <SelectItem value="customer_created">לקוח חדש</SelectItem>
            <SelectItem value="customer_updated">לקוח עודכן</SelectItem>
            <SelectItem value="customer_deleted">לקוח נמחק</SelectItem>
            <SelectItem value="settings_updated">הגדרות</SelectItem>
            <SelectItem value="reminder">תזכורת</SelectItem>
          </SelectContent>
        </Select>
        <Badge variant="outline" className="text-sm">{filtered.length} פעולות</Badge>
      </div>

      {filtered.length === 0 ? (
        <Card className="glass-card">
          <CardContent className="py-12 text-center text-muted-foreground">
            <History className="h-12 w-12 mx-auto mb-4 opacity-40" />
            <p>אין פעולות להצגה</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {filtered.map(a => {
            const config = typeConfig[a.type] || typeConfig.other;
            const Icon = config.icon;
            const reversible = canReverse(a);
            const isReversed = !!a.reversedAt;
            const hasDiff = !!a.diff && parseDiff(a).length > 0;
            return (
              <Card key={a.id} className={`glass-card group ${isReversed ? 'opacity-60' : ''}`}>
                <CardContent className="py-3 px-4">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <div className={`shrink-0 ${config.color}`}>
                        <Icon className="h-5 w-5" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className={`text-sm font-medium truncate ${isReversed ? 'line-through' : ''}`}>{a.description}</p>
                        <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                          <Badge variant="outline" className="text-[10px] px-1.5 py-0">{config.label}</Badge>
                          {isReversed && <Badge variant="outline" className="text-[10px] px-1.5 py-0 text-warning border-warning/40">בוטל</Badge>}
                          <span className="text-xs text-muted-foreground">
                            {new Date(a.createdAt).toLocaleDateString('he-IL')} {new Date(a.createdAt).toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' })}
                          </span>
                          {a.amount != null && a.amount > 0 && (
                            <span className="text-xs font-semibold text-primary">₪{a.amount.toLocaleString()}</span>
                          )}
                          {a.customerName && (
                            <span className="text-xs text-muted-foreground">• {a.customerName}</span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      {hasDiff && (
                        <Button size="sm" variant="ghost" className="h-7 px-2 opacity-0 group-hover:opacity-100 transition-opacity gap-1"
                          onClick={() => setDetailsTarget(a)} title="הצג מה השתנה">
                          <Info className="h-3.5 w-3.5" />
                          <span className="text-xs">פרטים</span>
                        </Button>
                      )}
                      {reversible && (
                        <Button size="sm" variant="ghost"
                          className="h-7 px-2 text-warning hover:text-warning opacity-0 group-hover:opacity-100 transition-opacity gap-1"
                          onClick={() => setReverseTarget(a)} title="בטל פעולה">
                          <Undo2 className="h-3.5 w-3.5" />
                          <span className="text-xs">בטל</span>
                        </Button>
                      )}
                      {isReversed && (
                        <Button size="sm" variant="ghost"
                          className="h-7 px-2 text-primary hover:text-primary opacity-0 group-hover:opacity-100 transition-opacity gap-1"
                          onClick={() => setRedoTarget(a)} title="החזר פעולה">
                          <Redo2 className="h-3.5 w-3.5" />
                          <span className="text-xs">החזר</span>
                        </Button>
                      )}
                      <Button size="sm" variant="ghost"
                        className="h-7 w-7 p-0 shrink-0 text-destructive hover:text-destructive"
                        onClick={() => setDeleteTarget(a)} title="מחק מההיסטוריה">
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Delete (remove from history only) */}
      <AlertDialog open={!!deleteTarget} onOpenChange={() => setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>מחיקת פעולה מההיסטוריה</AlertDialogTitle>
            <AlertDialogDescription>
              הרישום ימחק מההיסטוריה בלבד. הפעולה עצמה <strong>לא תבוטל</strong>.
              <br /><br />
              {deleteTarget?.description}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>ביטול</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">מחק מההיסטוריה</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Reverse (undo the action) */}
      <AlertDialog open={!!reverseTarget} onOpenChange={() => setReverseTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>ביטול פעולה</AlertDialogTitle>
            <AlertDialogDescription>
              <strong className="text-destructive">שים לב: פעולה זו תבטל את הפעולה ותחזיר את המצב לפני ביצועה.</strong>
              <br /><br />
              {reverseTarget?.description}
              {reverseTarget?.amount && reverseTarget.amount > 0 && (
                <><br />סכום: ₪{reverseTarget.amount.toLocaleString()}</>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>ביטול</AlertDialogCancel>
          <AlertDialogAction onClick={handleReverse} className="bg-warning text-warning-foreground hover:bg-warning/90">
              <Undo2 className="h-4 w-4 ml-1" />
              בטל פעולה
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Redo (bring back a reversed action) */}
      <AlertDialog open={!!redoTarget} onOpenChange={() => setRedoTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>החזרת פעולה</AlertDialogTitle>
            <AlertDialogDescription>
              הפעולה תבוצע שוב:
              <br /><br />
              {redoTarget?.description}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>ביטול</AlertDialogCancel>
            <AlertDialogAction onClick={handleRedo} className="bg-primary text-primary-foreground hover:bg-primary/90">
              <Redo2 className="h-4 w-4 ml-1" />
              החזר פעולה
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Diff / details */}
      <Dialog open={!!detailsTarget} onOpenChange={() => setDetailsTarget(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>מה השתנה?</DialogTitle></DialogHeader>
          <div className="space-y-2 text-sm">
            <p className="text-muted-foreground">{detailsTarget?.description}</p>
            <div className="rounded-lg border border-border overflow-hidden">
              <div className="grid grid-cols-3 bg-muted/50 px-3 py-2 text-xs font-semibold">
                <span>שדה</span><span>לפני</span><span>אחרי</span>
              </div>
              {detailsTarget && parseDiff(detailsTarget).map((d, i) => (
                <div key={i} className="grid grid-cols-3 px-3 py-2 border-t border-border/50 text-xs">
                  <span className="font-medium">{d.field}</span>
                  <span className="text-destructive truncate" dir="auto">{d.before || '—'}</span>
                  <span className="text-success truncate" dir="auto">{d.after || '—'}</span>
                </div>
              ))}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
