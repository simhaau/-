import { RecurringTag, Customer, RecurringCharge } from './types';

const STORAGE_KEY = 'masav_recurring_tags_v2';
const LEGACY_STORAGE_KEY = 'masav_recurring_tags';

export const DEFAULT_RECURRING_TAGS: RecurringTag[] = [];

// Predefined IDs from initial build that must be cleared out completely
const LEGACY_PREDEFINED_IDS = new Set([
  'tag_base',
  'tag_elec',
  'tag_ac',
  'tag_maint',
  'tag_cleaning',
  'tag_security',
]);

export function getRecurringTags(): RecurringTag[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed.filter(t => !LEGACY_PREDEFINED_IDS.has(t.id));
      }
    }

    // Check legacy storage key and filter out legacy predefined tags
    const legacyRaw = localStorage.getItem(LEGACY_STORAGE_KEY);
    if (legacyRaw) {
      const parsed = JSON.parse(legacyRaw);
      if (Array.isArray(parsed)) {
        const userCreatedOnly = parsed.filter(t => !LEGACY_PREDEFINED_IDS.has(t.id));
        localStorage.setItem(STORAGE_KEY, JSON.stringify(userCreatedOnly));
        return userCreatedOnly;
      }
    }

    localStorage.setItem(STORAGE_KEY, JSON.stringify([]));
    return [];
  } catch (e) {
    console.error('Failed to get recurring tags:', e);
    return [];
  }
}

export function saveRecurringTags(tags: RecurringTag[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tags));
  } catch (e) {
    console.error('Failed to save recurring tags:', e);
  }
}

export function addRecurringTag(
  data: Omit<RecurringTag, 'id' | 'createdAt'>
): RecurringTag {
  const tags = getRecurringTags();
  const newTag: RecurringTag = {
    ...data,
    id: `tag_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    createdAt: new Date().toISOString(),
  };
  tags.push(newTag);
  saveRecurringTags(tags);
  return newTag;
}

export function updateRecurringTag(tag: RecurringTag): void {
  const tags = getRecurringTags();
  const idx = tags.findIndex((t) => t.id === tag.id);
  if (idx !== -1) {
    tags[idx] = tag;
    saveRecurringTags(tags);
  }
}

export function deleteRecurringTag(id: string): void {
  const tags = getRecurringTags();
  const filtered = tags.filter((t) => t.id !== id);
  saveRecurringTags(filtered);
}

export const TAG_COLOR_OPTIONS = [
  { value: 'blue', label: 'כחול', bg: 'bg-blue-500/15', text: 'text-blue-700 dark:text-blue-400', border: 'border-blue-500/30', dot: 'bg-blue-500' },
  { value: 'amber', label: 'ענבר / כתום', bg: 'bg-amber-500/15', text: 'text-amber-700 dark:text-amber-400', border: 'border-amber-500/30', dot: 'bg-amber-500' },
  { value: 'cyan', label: 'טורקיז / תכלת', bg: 'bg-cyan-500/15', text: 'text-cyan-700 dark:text-cyan-400', border: 'border-cyan-500/30', dot: 'bg-cyan-500' },
  { value: 'emerald', label: 'ירוק ברקת', bg: 'bg-emerald-500/15', text: 'text-emerald-700 dark:text-emerald-400', border: 'border-emerald-500/30', dot: 'bg-emerald-500' },
  { value: 'purple', label: 'סגול', bg: 'bg-purple-500/15', text: 'text-purple-700 dark:text-purple-400', border: 'border-purple-500/30', dot: 'bg-purple-500' },
  { value: 'rose', label: 'ורוד / אדום', bg: 'bg-rose-500/15', text: 'text-rose-700 dark:text-rose-400', border: 'border-rose-500/30', dot: 'bg-rose-500' },
  { value: 'indigo', label: 'אינדיגו', bg: 'bg-indigo-500/15', text: 'text-indigo-700 dark:text-indigo-400', border: 'border-indigo-500/30', dot: 'bg-indigo-500' },
  { value: 'slate', label: 'אפור', bg: 'bg-slate-500/15', text: 'text-slate-700 dark:text-slate-400', border: 'border-slate-500/30', dot: 'bg-slate-500' },
];

export function getTagColorClasses(color?: string) {
  const match = TAG_COLOR_OPTIONS.find((c) => c.value === color);
  return match || TAG_COLOR_OPTIONS[0];
}

export function ensureCustomerRecurringCharges(customer: Customer): RecurringCharge[] {
  if (customer.recurringCharges && customer.recurringCharges.length > 0) {
    return customer.recurringCharges;
  }
  const list: RecurringCharge[] = [];
  if (customer.amperes && customer.amperes > 0) {
    list.push({
      id: `rc_base_${customer.id || Date.now()}`,
      label: 'חיוב בסיס',
      type: 'amperes',
      amperes: customer.amperes,
      amount: 0,
      createdAt: customer.createdAt || new Date().toISOString(),
    });
  } else if (customer.monthlyAmount && customer.monthlyAmount > 0) {
    list.push({
      id: `rc_base_${customer.id || Date.now()}`,
      label: 'חיוב בסיס',
      type: 'money',
      amperes: 0,
      amount: customer.monthlyAmount,
      createdAt: customer.createdAt || new Date().toISOString(),
    });
  }
  return list;
}
