import { Customer, BillingBatch, BillingTransaction, DebtRecord, RecurringCharge } from './types';

export function normalizeCustomerRecurringCharges(c: Customer): RecurringCharge[] {
  if (c.recurringCharges && c.recurringCharges.length > 0) {
    return c.recurringCharges;
  }
  const fallback: RecurringCharge[] = [];
  if (c.amperes && c.amperes > 0) {
    fallback.push({
      id: `rc_base_${c.id || 'new'}`,
      label: 'חיוב בסיס',
      type: 'amperes',
      amperes: c.amperes,
      amount: 0,
      createdAt: c.createdAt || new Date().toISOString(),
    });
  } else if (c.monthlyAmount && c.monthlyAmount > 0) {
    fallback.push({
      id: `rc_base_${c.id || 'new'}`,
      label: 'חיוב בסיס',
      type: 'money',
      amperes: 0,
      amount: c.monthlyAmount,
      createdAt: c.createdAt || new Date().toISOString(),
    });
  }
  return fallback;
}

export function getCustomerRecurringCharges(c: Customer): RecurringCharge[] {
  return normalizeCustomerRecurringCharges(c);
}

export function getCustomerTotalAmperes(c: Customer): number {
  const charges = normalizeCustomerRecurringCharges(c);
  if (charges.length > 0) {
    return charges.filter(rc => rc.type === 'amperes').reduce((sum, rc) => sum + (rc.amperes || 0), 0);
  }
  return c.amperes || 0;
}

export function getRecurringChargesAmount(c: Customer, pricePerAmpere: number): number {
  const charges = normalizeCustomerRecurringCharges(c);
  return charges.reduce((sum, rc) => {
    if (rc.type === 'amperes') return sum + (rc.amperes || 0) * pricePerAmpere;
    return sum + (rc.amount || 0);
  }, 0);
}

export function getCustomerBaseMonthlyAmount(c: Customer, pricePerAmpere: number): number {
  if (c.recurringCharges && c.recurringCharges.length > 0) {
    return getRecurringChargesAmount(c, pricePerAmpere);
  }
  if (c.amperes && c.amperes > 0 && pricePerAmpere > 0) {
    return c.amperes * pricePerAmpere;
  }
  return c.monthlyAmount || 0;
}

export function getCustomerMonthlyAmount(c: Customer, pricePerAmpere: number): number {
  if (c.recurringCharges && c.recurringCharges.length > 0) {
    return getRecurringChargesAmount(c, pricePerAmpere);
  }
  return getCustomerBaseMonthlyAmount(c, pricePerAmpere);
}

export function getCustomersDueForBilling(customers: Customer[], targetDate?: Date): Customer[] {
  const now = targetDate || new Date();
  return customers.filter(c => {
    if (c.status !== 'active') return false;
    const charges = normalizeCustomerRecurringCharges(c);
    const hasRecurring = charges.length > 0;
    if ((!c.amperes || c.amperes <= 0) && (!c.monthlyAmount || c.monthlyAmount <= 0) && !hasRecurring) return false;
    const start = new Date(c.startDate);
    if (start > now) return false;
    if (c.endDate) {
      const end = new Date(c.endDate);
      if (end < now) return false;
    }
    return true;
  });
}

export function createBillingBatch(
  customers: Customer[],
  valueDate: string,
  pricePerAmpere: number,
  extraDebts?: DebtRecord[],
  months?: number
): BillingBatch {
  const monthCount = months || 1;

  const transactions: BillingTransaction[] = customers.map(c => {
    const errors: string[] = [];
    if (!c.bankNumber) errors.push('חסר מספר בנק');
    if (!c.branchNumber) errors.push('חסר מספר סניף');
    if (!c.accountNumber) errors.push('חסר מספר חשבון');
    
    const monthlyAmt = getCustomerMonthlyAmount(c, pricePerAmpere);
    if (monthlyAmt <= 0) errors.push('סכום לא תקין');

    const baseAmount = (c.paymentMethod === 'mixed' ? (c.bankAmount || monthlyAmt) : monthlyAmt);
    
    // Add any extra debts (unpaid) for this customer
    const customerExtras = (extraDebts || []).filter(d => 
      d.customerId === c.id! && 
      d.status !== 'paid' && 
      d.status !== 'advance' &&
      d.status !== 'suspended'
    );
    const extraAmount = customerExtras.reduce((s, d) => s + (d.amount - d.paidAmount), 0);
    const totalAmount = (baseAmount * monthCount) + extraAmount;

    return {
      customerId: c.id!,
      customerName: c.fullName,
      amount: totalAmount,
      bankNumber: c.bankNumber,
      branchNumber: c.branchNumber,
      accountNumber: c.accountNumber,
      idNumber: c.idNumber,
      status: errors.length > 0 ? 'error' as const : 'included' as const,
      errorMessage: errors.length > 0 
        ? errors.join(', ') 
        : (extraAmount > 0 ? `כולל ₪${extraAmount.toLocaleString()} חיובים נוספים` : '') + 
          (monthCount > 1 ? `${monthCount > 1 && extraAmount > 0 ? ' • ' : ''}${monthCount} חודשים` : ''),
    };
  });

  const included = transactions.filter(t => t.status === 'included');

  return {
    date: new Date().toISOString().split('T')[0],
    valueDate,
    totalAmount: included.reduce((s, t) => s + t.amount, 0),
    transactionCount: included.length,
    status: 'pending',
    transactions,
    createdAt: new Date().toISOString(),
  };
}

export function calculateExpectedMonthlyIncome(customers: Customer[], pricePerAmpere: number): number {
  return customers
    .filter(c => c.status === 'active')
    .reduce((sum, c) => sum + getCustomerMonthlyAmount(c, pricePerAmpere), 0);
}
