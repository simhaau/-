import { useState, useEffect, useMemo } from 'react';
import { History, Plus, Search, Calendar, User, Trash2, Edit, Filter, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { getAllCustomers, getAllDebts, addDebt, updateDebt, deleteDebt, addActivity } from '@/lib/db';
import type { Customer, DebtRecord } from '@/lib/types';
import { toast } from 'sonner';

const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  paid: { label: 'שולם', color: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' },
  unpaid: { label: 'לא שולם', color: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400' },
  partial: { label: 'שולם חלקית', color: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400' },
  pending_collection: { label: 'ממתין לגבייה', color: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400' },
  suspended: { label: 'מושהה', color: 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400' },
  advance: { label: 'מקדמה', color: 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400' },
};

const MONTHS_HE = ['ינואר', 'פברואר', 'מרץ', 'אפריל', 'מאי', 'יוני', 'יולי', 'אוגוסט', 'ספטמבר', 'אוקטובר', 'נובמבר', 'דצמבר'];

function formatMonth(m: string) {
  const [y, mo] = m.split('-');
  const idx = parseInt(mo, 10) - 1;
  return `${MONTHS_HE[idx] || mo} ${y}`;
}

export default function HistoryView() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [debts, setDebts] = useState<DebtRecord[]>([]);
  const [search, setSearch] = useState('');
  const [monthFilter, setMonthFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [customerFilter, setCustomerFilter] = useState('all');

  // Add history dialog
  const [addDialog, setAddDialog] = useState(false);
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [selectedYear, setSelectedYear] = useState(String(new Date().getFullYear()));
  const [selectedMonth, setSelectedMonth] = useState(String(new Date().getMonth() + 1).padStart(2, '0'));
  const [historyAmount, setHistoryAmount] = useState(0);
  const [historyPaidAmount, setHistoryPaidAmount] = useState(0);
  const [historyStatus, setHistoryStatus] = useState<string>('paid');
  const [historyPaymentMethod, setHistoryPaymentMethod] = useState<string>('bank');
  const [historyNotes, setHistoryNotes] = useState('');
  const [historyPaidDate, setHistoryPaidDate] = useState('');

  // Edit dialog
  const [editDialog, setEditDialog] = useState<DebtRecord | null>(null);
  const [editAmount, setEditAmount] = useState(0);
  const [editPaidAmount, setEditPaidAmount] = useState(0);
  const [editStatus, setEditStatus] = useState('');
  const [editNotes, setEditNotes] = useState('');
  const [editPaidDate, setEditPaidDate] = useState('');

  const [deleteTarget, setDeleteTarget] = useState<DebtRecord | null>(null);

  const loadData = () => {
    Promise.all([getAllCustomers(), getAllDebts()]).then(([c, d]) => {
      setCustomers(c);
      setDebts(d);
    });
  };

  useEffect(() => { loadData(); }, []);

  const availableMonths = useMemo(() => {
    const set = new Set(debts.map(d => d.month));
    return Array.from(set).sort((a, b) => b.localeCompare(a));
  }, [debts]);

  const years = useMemo(() => {
    const set = new Set<string>();
    for (let y = 2020; y <= new Date().getFullYear() + 2; y++) set.add(String(y));
    return Array.from(set);
  }, []);

  const filtered = useMemo(() => {
    let result = [...debts];
    if (monthFilter !== 'all') result = result.filter(d => d.month === monthFilter);
    if (statusFilter !== 'all') result = result.filter(d => d.status === statusFilter);
    if (customerFilter !== 'all') result = result.filter(d => String(d.customerId) === customerFilter);
    if (search) {
      const s = search.toLowerCase();
      result = result.filter(d => d.customerName.toLowerCase().includes(s) || d.notes?.toLowerCase().includes(s));
    }
    return result.sort((a, b) => b.month.localeCompare(a.month) || b.createdAt.localeCompare(a.createdAt));
  }, [debts, monthFilter, statusFilter, customerFilter, search]);

  const totalAmount = filtered.reduce((s, d) => s + d.amount, 0);
  const totalPaid = filtered.reduce((s, d) => s + d.paidAmount, 0);

  const openAddHistory = () => {
    setSelectedCustomerId('');
    setHistoryAmount(0);
    setHistoryPaidAmount(0);
    setHistoryStatus('paid');
    setHistoryPaymentMethod('bank');
    setHistoryNotes('');
    setHistoryPaidDate(new Date().toISOString().split('T')[0]);
    setAddDialog(true);
  };

  const handleAddHistory = async () => {
    if (!selectedCustomerId) { toast.error('יש לבחור לקוח'); return; }
    if (historyAmount <= 0) { toast.error('סכום חייב להיות גדול מ-0'); return; }
    const customer = customers.find(c => String(c.id) === selectedCustomerId);
    if (!customer) return;
    const month = `${selectedYear}-${selectedMonth}`;
    const paidAmount = historyStatus === 'paid' ? historyAmount : historyPaidAmount;

    await addDebt({
      customerId: customer.id!,
      customerName: customer.fullName,
      month,
      amount: historyAmount,
      paidAmount,
      status: historyStatus as DebtRecord['status'],
      paidDate: historyPaidDate,
      paymentMethod: historyPaymentMethod as 'bank' | 'cash' | 'mixed',
      notes: historyNotes || `היסטוריה - ${formatMonth(month)}`,
      createdAt: new Date().toISOString(),
    });

    await addActivity({
      type: 'other',
      description: `נוספה היסטוריית גבייה עבור ${customer.fullName} - ${formatMonth(month)} - ₪${historyAmount.toLocaleString()}`,
      customerId: customer.id!,
      customerName: customer.fullName,
      amount: historyAmount,
      createdAt: new Date().toISOString(),
    });

    toast.success(`היסטוריה נוספה בהצלחה עבור ${customer.fullName}`);
    setAddDialog(false);
    loadData();
  };

  const openEdit = (debt: DebtRecord) => {
    setEditDialog(debt);
    setEditAmount(debt.amount);
    setEditPaidAmount(debt.paidAmount);
    setEditStatus(debt.status);
    setEditNotes(debt.notes);
    setEditPaidDate(debt.paidDate);
  };

  const handleEdit = async () => {
    if (!editDialog) return;
    await updateDebt({
      ...editDialog,
      amount: editAmount,
      paidAmount: editStatus === 'paid' ? editAmount : editPaidAmount,
      status: editStatus as DebtRecord['status'],
      notes: editNotes,
      paidDate: editPaidDate,
    });
    toast.success('הרשומה עודכנה');
    setEditDialog(null);
    loadData();
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    await deleteDebt(deleteTarget.id!);
    await addActivity({
      type: 'debt_deleted',
      description: `נמחקה רשומת היסטוריה עבור ${deleteTarget.customerName} - ${formatMonth(deleteTarget.month)}`,
      customerId: deleteTarget.customerId,
      customerName: deleteTarget.customerName,
      amount: deleteTarget.amount,
      createdAt: new Date().toISOString(),
    });
    toast.success('הרשומה נמחקה');
    setDeleteTarget(null);
    loadData();
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <History className="h-6 w-6 text-primary" />
          היסטוריית חיובים
        </h2>
        <Button onClick={openAddHistory}><Plus className="h-4 w-4 ml-1" />הוסף היסטוריה</Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold">₪{totalAmount.toLocaleString()}</div>
            <div className="text-xs text-muted-foreground">סה״כ חיובים</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">₪{totalPaid.toLocaleString()}</div>
            <div className="text-xs text-muted-foreground">סה״כ שולם</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-red-600">₪{(totalAmount - totalPaid).toLocaleString()}</div>
            <div className="text-xs text-muted-foreground">יתרת חוב</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="חיפוש..." value={search} onChange={e => setSearch(e.target.value)} className="pr-9" />
        </div>
        <Select value={monthFilter} onValueChange={setMonthFilter}>
          <SelectTrigger className="w-[160px]"><Calendar className="h-3.5 w-3.5 ml-1" /><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">כל החודשים</SelectItem>
            {availableMonths.map(m => <SelectItem key={m} value={m}>{formatMonth(m)}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[140px]"><Filter className="h-3.5 w-3.5 ml-1" /><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">כל הסטטוסים</SelectItem>
            {Object.entries(STATUS_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={customerFilter} onValueChange={setCustomerFilter}>
          <SelectTrigger className="w-[160px]"><User className="h-3.5 w-3.5 ml-1" /><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">כל הלקוחות</SelectItem>
            {customers.map(c => <SelectItem key={c.id} value={String(c.id)}>{c.fullName}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="text-sm text-muted-foreground">{filtered.length} רשומות</div>

      {/* Table */}
      <div className="rounded-lg border border-border overflow-hidden bg-card">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>חודש</TableHead>
              <TableHead>לקוח</TableHead>
              <TableHead>סכום</TableHead>
              <TableHead>שולם</TableHead>
              <TableHead>יתרה</TableHead>
              <TableHead>סטטוס</TableHead>
              <TableHead>אמצעי תשלום</TableHead>
              <TableHead>תאריך תשלום</TableHead>
              <TableHead>הערות</TableHead>
              <TableHead className="w-20">פעולות</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.slice(0, 200).map(d => {
              const st = STATUS_LABELS[d.status] || { label: d.status, color: '' };
              const balance = d.amount - d.paidAmount;
              return (
                <TableRow key={d.id} className="hover:bg-muted/30">
                  <TableCell className="font-medium">{formatMonth(d.month)}</TableCell>
                  <TableCell>{d.customerName}</TableCell>
                  <TableCell className="font-mono">₪{d.amount.toLocaleString()}</TableCell>
                  <TableCell className="font-mono text-green-600">₪{d.paidAmount.toLocaleString()}</TableCell>
                  <TableCell className={`font-mono ${balance > 0 ? 'text-red-600' : 'text-green-600'}`}>
                    ₪{balance.toLocaleString()}
                  </TableCell>
                  <TableCell>
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${st.color}`}>{st.label}</span>
                  </TableCell>
                  <TableCell className="text-sm">
                    {d.paymentMethod === 'bank' ? 'בנק' : d.paymentMethod === 'cash' ? 'מזומן' : d.paymentMethod === 'mixed' ? 'משולב' : '-'}
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">{d.paidDate || '-'}</TableCell>
                  <TableCell className="text-sm text-muted-foreground max-w-[150px] truncate">{d.notes || '-'}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => openEdit(d)}><Edit className="h-3 w-3" /></Button>
                      <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" onClick={() => setDeleteTarget(d)}><Trash2 className="h-3 w-3" /></Button>
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
            {filtered.length === 0 && (
              <TableRow>
                <TableCell colSpan={10} className="text-center py-12 text-muted-foreground">
                  אין רשומות היסטוריה. הוסף היסטוריה חדשה כדי להתחיל.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {/* Add History Dialog */}
      <Dialog open={addDialog} onOpenChange={setAddDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>הוספת היסטוריית גבייה</DialogTitle>
            <DialogDescription>הוסף רשומת גבייה היסטורית ללקוח</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>לקוח</Label>
              <Select value={selectedCustomerId} onValueChange={setSelectedCustomerId}>
                <SelectTrigger><SelectValue placeholder="בחר לקוח" /></SelectTrigger>
                <SelectContent>
                  {customers.map(c => <SelectItem key={c.id} value={String(c.id)}>{c.fullName} {c.idNumber ? `(${c.idNumber})` : ''}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>שנה</Label>
                <Select value={selectedYear} onValueChange={setSelectedYear}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {years.map(y => <SelectItem key={y} value={y}>{y}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>חודש</Label>
                <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {MONTHS_HE.map((m, i) => <SelectItem key={i} value={String(i + 1).padStart(2, '0')}>{m}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label>סכום חיוב (₪)</Label>
              <Input type="number" value={historyAmount || ''} onChange={e => setHistoryAmount(Number(e.target.value))} />
            </div>
            <div>
              <Label>סטטוס</Label>
              <Select value={historyStatus} onValueChange={setHistoryStatus}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="paid">שולם</SelectItem>
                  <SelectItem value="unpaid">לא שולם</SelectItem>
                  <SelectItem value="partial">שולם חלקית</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {historyStatus === 'partial' && (
              <div>
                <Label>סכום ששולם (₪)</Label>
                <Input type="number" value={historyPaidAmount || ''} onChange={e => setHistoryPaidAmount(Number(e.target.value))} />
              </div>
            )}
            <div>
              <Label>אמצעי תשלום</Label>
              <Select value={historyPaymentMethod} onValueChange={setHistoryPaymentMethod}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="bank">בנק</SelectItem>
                  <SelectItem value="cash">מזומן</SelectItem>
                  <SelectItem value="mixed">משולב</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>תאריך תשלום</Label>
              <Input type="date" value={historyPaidDate} onChange={e => setHistoryPaidDate(e.target.value)} />
            </div>
            <div>
              <Label>הערות</Label>
              <Textarea value={historyNotes} onChange={e => setHistoryNotes(e.target.value)} placeholder="הערות (אופציונלי)" />
            </div>
            <Button onClick={handleAddHistory} className="w-full">הוסף היסטוריה</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={!!editDialog} onOpenChange={() => setEditDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>עריכת רשומה - {editDialog?.customerName}</DialogTitle>
            <DialogDescription>{editDialog ? formatMonth(editDialog.month) : ''}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>סכום (₪)</Label>
              <Input type="number" value={editAmount || ''} onChange={e => setEditAmount(Number(e.target.value))} />
            </div>
            <div>
              <Label>סטטוס</Label>
              <Select value={editStatus} onValueChange={setEditStatus}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(STATUS_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            {editStatus !== 'paid' && (
              <div>
                <Label>סכום ששולם (₪)</Label>
                <Input type="number" value={editPaidAmount || ''} onChange={e => setEditPaidAmount(Number(e.target.value))} />
              </div>
            )}
            <div>
              <Label>תאריך תשלום</Label>
              <Input type="date" value={editPaidDate} onChange={e => setEditPaidDate(e.target.value)} />
            </div>
            <div>
              <Label>הערות</Label>
              <Textarea value={editNotes} onChange={e => setEditNotes(e.target.value)} />
            </div>
            <Button onClick={handleEdit} className="w-full">עדכן</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={() => setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>מחיקת רשומה</AlertDialogTitle>
            <AlertDialogDescription>
              האם למחוק את הרשומה של {deleteTarget?.customerName} עבור {deleteTarget ? formatMonth(deleteTarget.month) : ''}?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>ביטול</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">מחק</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
