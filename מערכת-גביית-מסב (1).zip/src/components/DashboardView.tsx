import { useState, useEffect, useMemo } from 'react';
import { Users, TrendingUp, CreditCard, Calendar, Zap, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { getAllCustomers, getAllBatches, getAllGroups, getSettings } from '@/lib/db';
import { calculateExpectedMonthlyIncome, getCustomersDueForBilling, getCustomerMonthlyAmount } from '@/lib/billing';
import DashboardCharts from './DashboardCharts';
import type { Customer, BillingBatch, Group, Settings } from '@/lib/types';

interface DashboardViewProps {
  onNavigate: (tab: string) => void;
}

export default function DashboardView({ onNavigate }: DashboardViewProps) {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [batches, setBatches] = useState<BillingBatch[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null);

  useEffect(() => {
    Promise.all([getAllCustomers(), getAllBatches(), getAllGroups(), getSettings()])
      .then(([c, b, g, s]) => { setCustomers(c); setBatches(b); setGroups(g); setSettings(s); });
  }, []);

  const pricePerAmpere = settings?.pricePerAmpere || 0;
  const activeCustomers = useMemo(() => customers.filter(c => c.status === 'active'), [customers]);
  const expectedIncome = useMemo(() => calculateExpectedMonthlyIncome(customers, pricePerAmpere), [customers, pricePerAmpere]);
  const dueCustomers = useMemo(() => getCustomersDueForBilling(customers), [customers]);
  const lastBatch = useMemo(() => batches.sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0], [batches]);
  const pausedCount = useMemo(() => customers.filter(c => c.status === 'paused').length, [customers]);

  const stats = [
    { label: 'סה"כ לקוחות', value: customers.length, icon: Users, color: 'text-primary', bg: 'bg-primary/10', tab: 'customers' },
    { label: 'לקוחות פעילים', value: activeCustomers.length, icon: Zap, color: 'text-success', bg: 'bg-success/10', tab: 'customers' },
    { label: 'הכנסה חודשית צפויה', value: `₪${expectedIncome.toLocaleString()}`, icon: TrendingUp, color: 'text-success', bg: 'bg-success/10', tab: 'reports' },
    { label: 'מושהים', value: pausedCount, icon: Calendar, color: 'text-warning', bg: 'bg-warning/10', tab: 'customers' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <button
            key={i}
            onClick={() => onNavigate(stat.tab)}
            className="text-right glass-card stat-glow hover:shadow-md hover:-translate-y-0.5 hover:border-primary/40 transition-all cursor-pointer group"
          >
            <div className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className="text-2xl font-bold mt-1 group-hover:text-primary transition-colors">{stat.value}</p>
                </div>
                <div className={`h-11 w-11 rounded-xl ${stat.bg} flex items-center justify-center`}>
                  <stat.icon className={`h-5 w-5 ${stat.color}`} />
                </div>
              </div>
            </div>
          </button>
        ))}
      </div>

      {/* Charts */}
      <DashboardCharts customers={customers} groups={groups} batches={batches} pricePerAmpere={pricePerAmpere} />

      {/* Quick Actions + Due Customers */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-lg">פעולות מהירות</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button className="w-full justify-start gap-3" onClick={() => onNavigate('customers')}>
              <Users className="h-4 w-4" />
              הוסף לקוח חדש
            </Button>
            <Button variant="secondary" className="w-full justify-start gap-3" onClick={() => onNavigate('billing')}>
              <CreditCard className="h-4 w-4" />
              צור אצוות גבייה
            </Button>
            <Button variant="secondary" className="w-full justify-start gap-3" onClick={() => onNavigate('groups')}>
              <Calendar className="h-4 w-4" />
              נהל קבוצות
            </Button>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-warning" />
              לקוחות לגבייה ({dueCustomers.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {dueCustomers.length === 0 ? (
              <p className="text-muted-foreground text-sm">אין לקוחות לגבייה כרגע</p>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {dueCustomers.slice(0, 10).map(c => {
                  const amt = getCustomerMonthlyAmount(c, pricePerAmpere);
                  return (
                    <div key={c.id} className="flex items-center justify-between py-2 border-b border-border/50 last:border-0">
                      <div>
                        <p className="text-sm font-medium">{c.nickname || c.fullName}</p>
                        <p className="text-xs text-muted-foreground">{c.amperes} אמפר</p>
                      </div>
                      <Badge variant="outline" className="text-success border-success/30">
                        ₪{amt.toLocaleString()}
                      </Badge>
                    </div>
                  );
                })}
                {dueCustomers.length > 10 && (
                  <p className="text-xs text-muted-foreground text-center pt-2">
                    ועוד {dueCustomers.length - 10} לקוחות...
                  </p>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {lastBatch && (
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-lg">אצוות גבייה אחרונה</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-6 text-sm">
              <div>
                <span className="text-muted-foreground">תאריך: </span>
                <span>{new Date(lastBatch.createdAt).toLocaleDateString('he-IL')}</span>
              </div>
              <div>
                <span className="text-muted-foreground">פעולות: </span>
                <span>{lastBatch.transactionCount}</span>
              </div>
              <div>
                <span className="text-muted-foreground">סכום: </span>
                <span className="text-success font-medium">₪{lastBatch.totalAmount.toLocaleString()}</span>
              </div>
              <Badge variant={lastBatch.status === 'exported' ? 'default' : 'secondary'}>
                {lastBatch.status === 'pending' ? 'ממתין' : lastBatch.status === 'generated' ? 'נוצר' : 'יוצא'}
              </Badge>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
