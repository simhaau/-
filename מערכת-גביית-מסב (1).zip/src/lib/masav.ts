import { BillingBatch, Settings } from './types';
import { toAgorot, agorotToMasavField } from './agorot';
import { validateBankAccount, validateIsraeliId, validateValueDate } from './bankValidation';

/**
 * MASAV File Generator — Bank-Grade Implementation
 * Strict 128-char records, integer arithmetic, full validation.
 * Hebrew characters are encoded per the MASAV char map and reversed
 * for the payee-name field (per the official spec).
 */

// ── MASAV Hebrew → ASCII value map (per Masav spec) ──
const ASCII_HEBREW: Record<string, number> = {
  'א': 38, 'ב': 65, 'ג': 66, 'ד': 67, 'ה': 68, 'ו': 69, 'ז': 70,
  'ח': 71, 'ט': 72, 'י': 73, 'ך': 74, 'כ': 75, 'ל': 76, 'ם': 77,
  'מ': 78, 'ן': 79, 'נ': 80, 'ס': 81, 'ע': 82, 'ף': 83, 'פ': 84,
  'ץ': 85, 'צ': 86, 'ק': 87, 'ר': 88, 'ש': 89, 'ת': 90,
};

function encodeChar(ch: string): number {
  if (ASCII_HEBREW[ch] !== undefined) return ASCII_HEBREW[ch];
  const c = ch.charCodeAt(0);
  // Strip any other non-printable / non-ASCII → space
  if (c < 0x20 || c > 0x7E) return 32;
  return c;
}

/** Text field ("X" type): pad-left with spaces, optional reverse (for Hebrew names). */
function textField(str: string, len: number, reverse = false): string {
  const raw = (str ?? '').trim().substring(0, len);
  const arr: number[] = [];
  for (const ch of raw) arr.push(encodeChar(ch));
  while (arr.length < len) arr.unshift(32);
  if (reverse) arr.reverse();
  return String.fromCharCode(...arr);
}

/** Numeric field ("N" type): digits only, pad-left with zeros. */
function numField(value: string | number, len: number): string {
  const clean = String(value ?? '').replace(/\D/g, '');
  const truncated = clean.length > len ? clean.substring(clean.length - len) : clean;
  return '0'.repeat(len - truncated.length) + truncated;
}

/** Blank filler of N spaces. */
function blank(len: number): string {
  return ' '.repeat(len);
}

function assertRecordLength(record: string, label: string): void {
  if (record.length !== 128) {
    throw new Error(`MASAV ${label}: expected 128 chars, got ${record.length}. Content: "${record}"`);
  }
  for (let i = 0; i < record.length; i++) {
    const code = record.charCodeAt(i);
    if (code > 0x7F) {
      throw new Error(`MASAV ${label}: non-ASCII byte at position ${i + 1} (code ${code})`);
    }
  }
}

function formatDate(dateStr: string): string {
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) throw new Error(`Invalid date: ${dateStr}`);
  const yy = String(d.getFullYear()).slice(-2);
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yy}${mm}${dd}`;
}

// ── Validation ──

export interface ValidationError {
  customerId: number;
  customerName: string;
  field: string;
  message: string;
  severity: 'critical' | 'warning';
}

export interface SimulationResult {
  passed: boolean;
  errors: ValidationError[];
  criticalCount: number;
  warningCount: number;
  totalAmountAgorot: number;
  recordCount: number;
  reconciliationValid: boolean;
}

export function simulateMasavBatch(batch: BillingBatch, settings: Settings): SimulationResult {
  const errors: ValidationError[] = [];
  const validTx = batch.transactions.filter(t => t.status === 'included');

  // ── System-level checks ──
  if (!settings.masavSenderCode || !/^\d{1,8}$/.test(String(settings.masavSenderCode).replace(/\D/g, ''))) {
    errors.push({ customerId: 0, customerName: 'מערכת', field: 'masavSenderCode', message: 'קוד מוסד/נושא מסב חסר או לא תקין (1-8 ספרות)', severity: 'critical' });
  }
  if (!settings.institutionCode || !/^\d{1,5}$/.test(String(settings.institutionCode).replace(/\D/g, ''))) {
    errors.push({ customerId: 0, customerName: 'מערכת', field: 'institutionCode', message: 'קוד מוסד שולח חסר או לא תקין (1-5 ספרות)', severity: 'critical' });
  }
  const orgTrim = (settings.organizationName ?? '').trim();
  if (!orgTrim) {
    errors.push({ customerId: 0, customerName: 'מערכת', field: 'organizationName', message: 'שם ארגון חסר', severity: 'critical' });
  } else if (orgTrim.length > 30) {
    errors.push({ customerId: 0, customerName: 'מערכת', field: 'organizationName', message: 'שם ארגון חורג מ-30 תווים ויקוצץ בקובץ מסב', severity: 'warning' });
  }

  // Value date checks
  const dateErrors = validateValueDate(batch.valueDate);
  for (const e of dateErrors) {
    errors.push({ customerId: 0, customerName: 'מערכת', field: e.field, message: e.message, severity: e.severity });
  }

  // ── Per-transaction checks ──
  const seenKeys = new Set<string>();
  let totalAgorot = 0;

  for (const tx of validTx) {
    // Bank account validation
    const bankResult = validateBankAccount(tx.bankNumber, tx.branchNumber, tx.accountNumber);
    for (const e of bankResult.errors) {
      errors.push({ customerId: tx.customerId, customerName: tx.customerName, field: e.field, message: e.message, severity: e.severity });
    }

    // Amount validation (integer)
    const agorot = toAgorot(tx.amount);
    if (agorot <= 0) {
      errors.push({ customerId: tx.customerId, customerName: tx.customerName, field: 'amount', message: 'סכום חייב להיות גדול מ-0', severity: 'critical' });
    }
    if (agorot > 9999999999999) { // 13 digit combined agorot limit
      errors.push({ customerId: tx.customerId, customerName: tx.customerName, field: 'amount', message: 'סכום חורג ממגבלת מסב (13 ספרות אגורות)', severity: 'critical' });
    }
    totalAgorot += agorot;

    // ID number validation
    const cleanId = (tx.idNumber || '').replace(/\D/g, '');
    if (!cleanId || cleanId.length === 0 || cleanId.length > 9) {
      errors.push({ customerId: tx.customerId, customerName: tx.customerName, field: 'idNumber', message: 'מספר זהות חסר או לא תקין', severity: 'critical' });
    } else if (!validateIsraeliId(cleanId)) {
      errors.push({ customerId: tx.customerId, customerName: tx.customerName, field: 'idNumber', message: 'ספרת ביקורת של תעודת זהות שגויה', severity: 'warning' });
    }

    // Name presence (Hebrew allowed per MASAV spec)
    const nameTrim = (tx.customerName ?? '').trim();
    if (!nameTrim) {
      errors.push({ customerId: tx.customerId, customerName: tx.customerName, field: 'customerName', message: 'שם לקוח חסר', severity: 'critical' });
    } else if (nameTrim.length > 16) {
      errors.push({ customerId: tx.customerId, customerName: tx.customerName, field: 'customerName', message: 'שם לקוח חורג מ-16 תווים ויקוצץ בקובץ מסב', severity: 'warning' });
    }

    // Duplicate detection
    const key = `${tx.bankNumber}-${tx.branchNumber}-${tx.accountNumber}-${agorot}`;
    if (seenKeys.has(key)) {
      errors.push({ customerId: tx.customerId, customerName: tx.customerName, field: 'duplicate', message: 'כפילות: אותו חשבון וסכום מופיעים פעמיים באצווה', severity: 'warning' });
    }
    seenKeys.add(key);
  }

  // ── Reconciliation ──
  const declaredAgorot = toAgorot(batch.totalAmount);
  const reconciliationValid = totalAgorot === declaredAgorot;
  if (!reconciliationValid) {
    errors.push({
      customerId: 0, customerName: 'מערכת', field: 'reconciliation',
      message: `אי התאמה: סכום רשומות ₪${(totalAgorot / 100).toFixed(2)} ≠ סכום מוצהר ₪${(declaredAgorot / 100).toFixed(2)}`,
      severity: 'critical'
    });
  }

  const criticalCount = errors.filter(e => e.severity === 'critical').length;
  const warningCount = errors.filter(e => e.severity === 'warning').length;

  return {
    passed: criticalCount === 0,
    errors,
    criticalCount,
    warningCount,
    totalAmountAgorot: totalAgorot,
    recordCount: validTx.length,
    reconciliationValid,
  };
}

// Legacy wrapper
export function validateBatchForMasav(batch: BillingBatch, settings: Settings): ValidationError[] {
  return simulateMasavBatch(batch, settings).errors;
}

// ── File Generation ──

export function generateMasavFile(batch: BillingBatch, settings: Settings): string {
  const sim = simulateMasavBatch(batch, settings);
  if (!sim.passed) {
    throw new Error(`קובץ מסב לא נוצר: ${sim.criticalCount} שגיאות קריטיות. יש לתקן את כל השגיאות לפני ייצוא.`);
  }

  const validTx = batch.transactions.filter(t => t.status === 'included');
  const paymentDate = formatDate(batch.valueDate);
  const creationDate = formatDate(batch.date);
  const institutionCode = numField(settings.masavSenderCode, 8);
  const sendingInstitution = numField(settings.institutionCode, 5);
  // Serial number derives from batch id (or timestamp) so every generated file has a
  // unique 3-digit serial — MASAV rejects duplicate serial numbers per sender/day.
  const serialSeed = (batch.id ?? Math.floor(Date.now() / 1000)) % 999 + 1;
  const serialNumber = String(serialSeed).padStart(3, '0');

  const records: string[] = [];

  // ── Header Record (K) — 128 chars ──
  const header =
    'K' +                                    // 1     (1) X
    institutionCode +                        // 2-9   (8) N
    '00' +                                   // 10-11 (2) N
    paymentDate +                            // 12-17 (6) N  YYMMDD
    '0' +                                    // 18    (1) N
    serialNumber +                           // 19-21 (3) N
    '0' +                                    // 22    (1) N
    creationDate +                           // 23-28 (6) N
    sendingInstitution +                     // 29-33 (5) N
    '000000' +                               // 34-39 (6) N
    textField(settings.organizationName, 30, true) + // 40-69 (30) X REVERSED (Hebrew)
    blank(56) +                              // 70-125 (56) X
    'KOT';                                   // 126-128 (3) X
  assertRecordLength(header, 'header');
  records.push(header);

  // ── Movement Records ('1') — 128 chars each ──
  let runningTotalAgorot = 0;

  for (const tx of validTx) {
    const agorot = toAgorot(tx.amount);
    runningTotalAgorot += agorot;

    const line =
      '1' +                                  // 1     (1) X
      institutionCode +                      // 2-9   (8) N
      '00' +                                 // 10-11 (2) N
      '000000' +                             // 12-17 (6) N
      numField(tx.bankNumber, 2) +           // 18-19 (2) N
      numField(tx.branchNumber, 3) +         // 20-22 (3) N
      '0000' +                               // 23-26 (4) N
      numField(tx.accountNumber, 9) +        // 27-35 (9) N
      '0' +                                  // 36    (1) N
      numField(tx.idNumber, 9) +             // 37-45 (9) N
      textField(tx.customerName, 16, true) + // 46-61 (16) X REVERSED (Hebrew)
      agorotToMasavField(agorot, 13) +       // 62-74 (13) N  shekel(11)+agorot(2) combined
      numField(tx.idNumber, 20) +            // 75-94 (20) N  payee number
      '00000000' +                           // 95-102 (8) N  time period YYMM-YYMM (zeros allowed)
      '000' +                                // 103-105 (3) N  קוד מלל
      '504' +                                // 106-108 (3) N  סוג תנועה: 504 = חיוב רגיל (direct debit by authorization)
      '000000000000000000' +                 // 109-126 (18) N
      '  ';                                  // 127-128 (2) X
    assertRecordLength(line, `movement[${tx.customerName}]`);
    records.push(line);
  }

  // ── Totals Record ('5') — 128 chars (per חיובים spec §3.3) ──
  const totals =
    '5' +                                    // 1     (1) X
    institutionCode +                        // 2-9   (8) N
    '00' +                                   // 10-11 (2) N  מטבע
    paymentDate +                            // 12-17 (6) N  תאריך החיוב
    '0' +                                    // 18    (1) N  FILLER
    serialNumber +                           // 19-21 (3) N  מספר סידורי
    '000000000000000' +                      // 22-36 (15) N FILLER zeros
    agorotToMasavField(runningTotalAgorot, 15) + // 37-51 (15) N סכום התנועות shekel(13)+agorot(2)
    '0000000' +                              // 52-58 (7)  N FILLER zeros
    numField(validTx.length, 7) +            // 59-65 (7)  N מספר התנועות
    blank(63);                               // 66-128 (63) X
  assertRecordLength(totals, 'totals');
  records.push(totals);

  // ── End-of-file record — 128 bytes of '9' ──
  const end = '9'.repeat(128);
  assertRecordLength(end, 'end');
  records.push(end);

  // Every record terminated by CRLF (including the last one)
  return records.map(r => r + '\r\n').join('');
}

export function downloadMasavFile(content: string, filename: string) {
  // MASAV files are strict single-byte ASCII — write raw char codes as bytes.
  const bytes = new Uint8Array(content.length);
  for (let i = 0; i < content.length; i++) {
    const code = content.charCodeAt(i);
    bytes[i] = code > 0x7F ? 32 : code;
  }

  const blob = new Blob([bytes], { type: 'application/octet-stream' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
