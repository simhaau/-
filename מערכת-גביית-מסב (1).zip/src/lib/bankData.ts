// Parse and provide bank/branch data from the CSV
import bankCsvUrl from './bankData.csv?raw';

export interface BankInfo {
  code: string;
  name: string;
}

export interface BranchInfo {
  bankCode: string;
  branchCode: string;
  branchName: string;
  address: string;
  city: string;
}

let _banks: BankInfo[] | null = null;
let _branches: BranchInfo[] | null = null;

function parseCSV() {
  if (_banks && _branches) return;

  const lines = bankCsvUrl.split('\n').slice(1); // skip header
  const bankMap = new Map<string, string>();
  const branches: BranchInfo[] = [];

  for (const line of lines) {
    if (!line.trim()) continue;
    // Parse CSV with quoted fields
    const fields: string[] = [];
    let current = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') {
        if (inQuotes && line[i + 1] === '"') {
          current += '"';
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (ch === ',' && !inQuotes) {
        fields.push(current.trim());
        current = '';
      } else {
        current += ch;
      }
    }
    fields.push(current.trim());

    const bankCode = fields[0];
    const bankName = fields[1] || '';
    const branchCode = fields[2] || '';
    const branchName = fields[4] || '';
    const address = fields[5] || '';
    const city = fields[6] || '';
    const closeDate = fields[22] || '';

    if (!bankCode || !branchCode) continue;
    // Skip closed branches
    if (closeDate) continue;

    bankMap.set(bankCode, bankName);
    branches.push({ bankCode, branchCode, branchName, address, city });
  }

  _banks = Array.from(bankMap.entries())
    .map(([code, name]) => ({ code, name }))
    .sort((a, b) => Number(a.code) - Number(b.code));
  _branches = branches;
}

const CUSTOM_BANKS_KEY = 'custom_banks';
const CUSTOM_BRANCHES_KEY = 'custom_branches';

function readCustomBanks(): BankInfo[] {
  try { return JSON.parse(localStorage.getItem(CUSTOM_BANKS_KEY) || '[]'); } catch { return []; }
}
function readCustomBranches(): BranchInfo[] {
  try { return JSON.parse(localStorage.getItem(CUSTOM_BRANCHES_KEY) || '[]'); } catch { return []; }
}

export function getAllBanks(): BankInfo[] {
  parseCSV();
  const merged = new Map<string, string>();
  (_banks || []).forEach(b => merged.set(b.code, b.name));
  readCustomBanks().forEach(b => merged.set(b.code, b.name));
  return Array.from(merged.entries())
    .map(([code, name]) => ({ code, name }))
    .sort((a, b) => Number(a.code) - Number(b.code));
}

export function getBranchesForBank(bankCode: string): BranchInfo[] {
  parseCSV();
  const merged = new Map<string, BranchInfo>();
  (_branches || []).filter(b => b.bankCode === bankCode).forEach(b => merged.set(b.branchCode, b));
  readCustomBranches().filter(b => b.bankCode === bankCode).forEach(b => merged.set(b.branchCode, b));
  return Array.from(merged.values()).sort((a, b) => Number(a.branchCode) - Number(b.branchCode));
}

export function getBankName(bankCode: string): string {
  return getAllBanks().find(b => b.code === bankCode)?.name || '';
}

export function getBranchName(bankCode: string, branchCode: string): string {
  return getBranchesForBank(bankCode).find(b => b.branchCode === branchCode)?.branchName || '';
}
