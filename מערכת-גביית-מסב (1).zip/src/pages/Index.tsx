import { useState, useEffect, useMemo } from 'react';
import { LayoutDashboard, Users, FolderKanban, CreditCard, Settings, Banknote, History, BarChart3, Zap, Bell, Building2, Clock, ArrowUp } from 'lucide-react';
import DashboardView from '@/components/DashboardView';
import CustomersView from '@/components/CustomersView';
import GroupsView from '@/components/GroupsView';
import BillingView from '@/components/BillingView';
import DebtsView from '@/components/DebtsView';
import SettingsView from '@/components/SettingsView';
import ActivityLogView from '@/components/ActivityLogView';
import ReportsView from '@/components/ReportsView';
import BulkChargeView from '@/components/BulkChargeView';
import RemindersView from '@/components/RemindersView';
import BanksView from '@/components/BanksView';
import HistoryView from '@/components/HistoryView';
import CommandPalette from '@/components/CommandPalette';
import ThemeToggle from '@/components/ThemeToggle';
import { getSettings, getAllCustomers, getAllReminders, getAllDebts } from '@/lib/db';
import { getCustomersDueForBilling } from '@/lib/billing';

const TABS = [
  { id: 'dashboard', label: 'לוח בקרה', icon: LayoutDashboard, subtitle: 'סקירה כללית של המערכת' },
  { id: 'customers', label: 'לקוחות', icon: Users, subtitle: 'ניהול פרטי לקוחות' },
  { id: 'groups', label: 'קבוצות', icon: FolderKanban, subtitle: 'קיבוץ לקוחות לפי מאפיינים' },
  { id: 'billing', label: 'גבייה', icon: CreditCard, subtitle: 'יצירת אצוות גבייה וקבצי מסב' },
  { id: 'bulk-charge', label: 'חיוב גורף', icon: Zap, subtitle: 'חיוב מרובה לקוחות בו-זמנית' },
  { id: 'debts', label: 'חובות', icon: Banknote, subtitle: 'ניהול חובות פתוחים ותשלומים' },
  { id: 'banks', label: 'בנקים', icon: Building2, subtitle: 'רשימת בנקים וסניפים' },
  { id: 'history', label: 'היסטוריה', icon: Clock, subtitle: 'היסטוריית חיובים ותשלומים' },
  { id: 'reports', label: 'דוחות', icon: BarChart3, subtitle: 'דוחות ותובנות עסקיות' },
  { id: 'reminders', label: 'תזכורות', icon: Bell, subtitle: 'תזכורות ומשימות' },
  { id: 'activity', label: 'פעולות', icon: History, subtitle: 'יומן פעילות ואודיט' },
  { id: 'settings', label: 'הגדרות', icon: Settings, subtitle: 'הגדרות המערכת והארגון' },
];

const Index = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [stickyNav, setStickyNav] = useState(true);
  const [badges, setBadges] = useState<{ billing: number; reminders: number; debts: number }>({ billing: 0, reminders: 0, debts: 0 });
  const [showScrollTop, setShowScrollTop] = useState(false);

  const refreshBadges = () => {
    Promise.all([getAllCustomers(), getAllReminders(), getAllDebts()]).then(([customers, reminders, debts]) => {
      const today = new Date().toISOString().split('T')[0];
      setBadges({
        billing: getCustomersDueForBilling(customers).length,
        reminders: reminders.filter(r => !r.completed && r.dueDate && r.dueDate <= today).length,
        debts: debts.filter(d => d.status === 'unpaid' || d.status === 'partial').length,
      });
    }).catch(() => { /* ignore */ });
  };

  useEffect(() => {
    getSettings().then(s => setStickyNav(s.stickyNav !== false));
    refreshBadges();
    const interval = setInterval(refreshBadges, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => { refreshBadges(); }, [activeTab]);

  // Keyboard shortcuts: Alt+1..9 for the first 9 tabs
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (!e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
      const num = parseInt(e.key, 10);
      if (isNaN(num) || num < 1 || num > TABS.length) return;
      e.preventDefault();
      setActiveTab(TABS[num - 1].id);
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  // Scroll to top button visibility
  useEffect(() => {
    const onScroll = () => setShowScrollTop(window.scrollY > 400);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Scroll to top when switching tabs
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeTab]);

  const activeTabInfo = useMemo(() => TABS.find(t => t.id === activeTab), [activeTab]);

  const getBadge = (id: string): number => {
    if (id === 'billing') return badges.billing;
    if (id === 'reminders') return badges.reminders;
    if (id === 'debts') return badges.debts;
    return 0;
  };

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      <CommandPalette onNavigate={setActiveTab} />

      <header className="border-b border-border/40 bg-card/60 backdrop-blur-xl sticky top-0 z-50">
        <div className="container flex items-center justify-between h-14 px-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center shadow-sm">
              <CreditCard className="h-4 w-4 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight leading-tight">מערכת גבייה</h1>
              {activeTabInfo && (
                <p className="text-[11px] text-muted-foreground leading-none hidden sm:block">
                  {activeTabInfo.subtitle}
                </p>
              )}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                const event = new KeyboardEvent('keydown', { key: 'k', ctrlKey: true, bubbles: true });
                document.dispatchEvent(event);
              }}
              className="hidden sm:flex items-center gap-2 text-xs text-muted-foreground bg-muted/50 hover:bg-muted px-3 py-1.5 rounded-lg border border-border/40 transition-colors cursor-pointer"
              title="חיפוש כללי"
            >
              <span>חיפוש</span>
              <kbd className="px-1.5 py-0.5 bg-background rounded text-[10px] border border-border/60">⌘K</kbd>
            </button>
            <ThemeToggle />
          </div>
        </div>
      </header>

      <nav className={`border-b border-border/30 bg-card/30 backdrop-blur-sm ${stickyNav ? 'sticky top-14' : ''} z-40`}>
        <div className="container px-4">
          <div className="flex gap-0.5 overflow-x-auto py-1 -mb-px scrollbar-none">
            {TABS.map((tab, idx) => {
              const isActive = activeTab === tab.id;
              const badge = getBadge(tab.id);
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  title={`${tab.subtitle}${idx < 9 ? ` (Alt+${idx + 1})` : ''}`}
                  className={`relative flex items-center gap-2 px-4 py-2.5 text-sm font-medium rounded-lg transition-all whitespace-nowrap ${
                    isActive
                      ? 'bg-primary text-primary-foreground shadow-sm'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                  }`}
                >
                  <tab.icon className="h-4 w-4" />
                  {tab.label}
                  {badge > 0 && (
                    <span
                      className={`inline-flex items-center justify-center min-w-[18px] h-[18px] px-1 rounded-full text-[10px] font-bold ${
                        isActive
                          ? 'bg-primary-foreground text-primary'
                          : tab.id === 'reminders'
                          ? 'bg-warning text-warning-foreground'
                          : tab.id === 'debts'
                          ? 'bg-destructive text-destructive-foreground'
                          : 'bg-primary text-primary-foreground'
                      }`}
                    >
                      {badge > 99 ? '99+' : badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      <main className="container px-4 py-6">
        {activeTab === 'dashboard' && <DashboardView onNavigate={setActiveTab} />}
        {activeTab === 'customers' && <CustomersView />}
        {activeTab === 'groups' && <GroupsView />}
        {activeTab === 'billing' && <BillingView />}
        {activeTab === 'bulk-charge' && <BulkChargeView />}
        {activeTab === 'debts' && <DebtsView />}
        {activeTab === 'banks' && <BanksView />}
        {activeTab === 'history' && <HistoryView />}
        {activeTab === 'reports' && <ReportsView />}
        {activeTab === 'reminders' && <RemindersView />}
        {activeTab === 'activity' && <ActivityLogView />}
        {activeTab === 'settings' && <SettingsView />}
      </main>

      {/* Scroll to top button */}
      <button
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        aria-label="חזרה למעלה"
        className={`fixed bottom-6 left-6 z-50 w-11 h-11 rounded-full bg-primary text-primary-foreground shadow-lg hover:shadow-xl hover:scale-110 transition-all flex items-center justify-center ${
          showScrollTop ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'
        }`}
      >
        <ArrowUp className="h-5 w-5" />
      </button>

      <footer className="border-t border-border/30 bg-card/40 backdrop-blur-sm py-4 mt-8">
        <div className="container px-4 flex flex-col sm:flex-row items-center justify-center gap-2 text-center">
          <p className="text-sm text-muted-foreground">
            אפליקציה זו נבנתה על ידי <strong className="text-foreground">SA מערכות</strong> • להזמנת אפליקציה מותאמת אישית: <span className="font-mono text-foreground" dir="ltr">053-3150511</span>
          </p>
          <a
            href="https://simha.rf.gd"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-primary/10 hover:bg-primary/20 text-primary text-sm font-medium transition-colors border border-primary/20"
          >
            בקרו באתר שלנו ←
          </a>
        </div>
      </footer>
    </div>
  );
};

export default Index;
