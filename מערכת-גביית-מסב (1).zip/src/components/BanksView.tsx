import { useState, useEffect, useMemo } from 'react';
import { Building2, Plus, Edit, ChevronDown, ChevronUp, Search, MapPin, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { getAllBanks, getBranchesForBank, BankInfo, BranchInfo } from '@/lib/bankData';
import { toast } from 'sonner';

// We'll use localStorage to persist custom banks/branches added by user
const CUSTOM_BANKS_KEY = 'custom_banks';
const CUSTOM_BRANCHES_KEY = 'custom_branches';

function getCustomBanks(): BankInfo[] {
  try { return JSON.parse(localStorage.getItem(CUSTOM_BANKS_KEY) || '[]'); } catch { return []; }
}
function saveCustomBanks(banks: BankInfo[]) {
  localStorage.setItem(CUSTOM_BANKS_KEY, JSON.stringify(banks));
}
function getCustomBranches(): BranchInfo[] {
  try { return JSON.parse(localStorage.getItem(CUSTOM_BRANCHES_KEY) || '[]'); } catch { return []; }
}
function saveCustomBranches(branches: BranchInfo[]) {
  localStorage.setItem(CUSTOM_BRANCHES_KEY, JSON.stringify(branches));
}

export default function BanksView() {
  const [search, setSearch] = useState('');
  const [expandedBank, setExpandedBank] = useState<string | null>(null);
  const [branchSearch, setBranchSearch] = useState('');

  // Bank dialog
  const [bankDialog, setBankDialog] = useState(false);
  const [editingBank, setEditingBank] = useState<BankInfo | null>(null);
  const [bankCode, setBankCode] = useState('');
  const [bankName, setBankName] = useState('');

  // Branch dialog
  const [branchDialog, setBranchDialog] = useState(false);
  const [editingBranch, setEditingBranch] = useState<BranchInfo | null>(null);
  const [branchBankCode, setBranchBankCode] = useState('');
  const [branchCode, setBranchCode] = useState('');
  const [branchName, setBranchName] = useState('');
  const [branchAddress, setBranchAddress] = useState('');
  const [branchCity, setBranchCity] = useState('');

  const [customBanks, setCustomBanks] = useState<BankInfo[]>(getCustomBanks());
  const [customBranches, setCustomBranches] = useState<BranchInfo[]>(getCustomBranches());

  const allBanks = useMemo(() => {
    const csvBanks = getAllBanks();
    const merged = new Map<string, string>();
    csvBanks.forEach(b => merged.set(b.code, b.name));
    customBanks.forEach(b => merged.set(b.code, b.name));
    return Array.from(merged.entries())
      .map(([code, name]) => ({ code, name }))
      .sort((a, b) => Number(a.code) - Number(b.code));
  }, [customBanks]);

  const filteredBanks = useMemo(() => {
    if (!search) return allBanks;
    const s = search.toLowerCase();
    return allBanks.filter(b => b.code.includes(s) || b.name.toLowerCase().includes(s));
  }, [allBanks, search]);

  const getBranches = (bankCode: string): BranchInfo[] => {
    const csvBranches = getBranchesForBank(bankCode);
    const custom = customBranches.filter(b => b.bankCode === bankCode);
    const merged = new Map<string, BranchInfo>();
    csvBranches.forEach(b => merged.set(b.branchCode, b));
    custom.forEach(b => merged.set(b.branchCode, b));
    return Array.from(merged.values()).sort((a, b) => Number(a.branchCode) - Number(b.branchCode));
  };

  const openNewBank = () => {
    setEditingBank(null);
    setBankCode('');
    setBankName('');
    setBankDialog(true);
  };

  const openEditBank = (bank: BankInfo) => {
    setEditingBank(bank);
    setBankCode(bank.code);
    setBankName(bank.name);
    setBankDialog(true);
  };

  const saveBank = () => {
    if (!bankCode.trim() || !bankName.trim()) { toast.error('יש למלא קוד ושם בנק'); return; }
    const updated = [...customBanks];
    const idx = updated.findIndex(b => b.code === (editingBank?.code || bankCode));
    if (idx >= 0) {
      updated[idx] = { code: bankCode, name: bankName };
    } else {
      updated.push({ code: bankCode, name: bankName });
    }
    setCustomBanks(updated);
    saveCustomBanks(updated);
    setBankDialog(false);
    toast.success(editingBank ? 'הבנק עודכן' : 'בנק חדש נוסף');
  };

  const openNewBranch = (forBankCode: string) => {
    setEditingBranch(null);
    setBranchBankCode(forBankCode);
    setBranchCode('');
    setBranchName('');
    setBranchAddress('');
    setBranchCity('');
    setBranchDialog(true);
  };

  const openEditBranch = (branch: BranchInfo) => {
    setEditingBranch(branch);
    setBranchBankCode(branch.bankCode);
    setBranchCode(branch.branchCode);
    setBranchName(branch.branchName);
    setBranchAddress(branch.address);
    setBranchCity(branch.city);
    setBranchDialog(true);
  };

  const saveBranch = () => {
    if (!branchCode.trim() || !branchName.trim()) { toast.error('יש למלא קוד ושם סניף'); return; }
    const updated = [...customBranches];
    const idx = updated.findIndex(b => b.bankCode === branchBankCode && b.branchCode === (editingBranch?.branchCode || branchCode));
    const newBranch: BranchInfo = { bankCode: branchBankCode, branchCode, branchName, address: branchAddress, city: branchCity };
    if (idx >= 0) {
      updated[idx] = newBranch;
    } else {
      updated.push(newBranch);
    }
    setCustomBranches(updated);
    saveCustomBranches(updated);
    setBranchDialog(false);
    toast.success(editingBranch ? 'הסניף עודכן' : 'סניף חדש נוסף');
  };

  const toggleBank = (code: string) => {
    setExpandedBank(prev => prev === code ? null : code);
    setBranchSearch('');
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Building2 className="h-6 w-6 text-primary" />
          בנקים וסניפים
        </h2>
        <Button onClick={openNewBank}><Plus className="h-4 w-4 ml-1" />בנק חדש</Button>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="חיפוש לפי קוד או שם בנק..." value={search} onChange={e => setSearch(e.target.value)} className="pr-9" />
      </div>

      <div className="text-sm text-muted-foreground">{filteredBanks.length} בנקים</div>

      <div className="space-y-2">
        {filteredBanks.map(bank => {
          const isExpanded = expandedBank === bank.code;
          const branches = isExpanded ? getBranches(bank.code) : [];
          const filteredBranches = branchSearch
            ? branches.filter(b => b.branchCode.includes(branchSearch) || b.branchName.includes(branchSearch) || b.city.includes(branchSearch))
            : branches;

          return (
            <Card key={bank.code} className="overflow-hidden">
              <div
                className="flex items-center justify-between p-4 cursor-pointer hover:bg-muted/30 transition-colors"
                onClick={() => toggleBank(bank.code)}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center font-bold text-primary">
                    {bank.code}
                  </div>
                  <div>
                    <div className="font-semibold">{bank.name}</div>
                    <div className="text-xs text-muted-foreground">קוד בנק: {bank.code}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button size="icon" variant="ghost" className="h-8 w-8" onClick={e => { e.stopPropagation(); openEditBank(bank); }}>
                    <Edit className="h-3.5 w-3.5" />
                  </Button>
                  {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </div>
              </div>

              {isExpanded && (
                <CardContent className="pt-0 border-t border-border/40">
                  <div className="flex items-center gap-2 mb-3 mt-3">
                    <div className="relative flex-1 max-w-xs">
                      <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                      <Input
                        placeholder="חיפוש סניף..."
                        value={branchSearch}
                        onChange={e => setBranchSearch(e.target.value)}
                        className="pr-9 h-8 text-sm"
                      />
                    </div>
                    <Button size="sm" onClick={() => openNewBranch(bank.code)}>
                      <Plus className="h-3.5 w-3.5 ml-1" />סניף חדש
                    </Button>
                    <Badge variant="secondary">{branches.length} סניפים</Badge>
                  </div>

                  {filteredBranches.length > 0 ? (
                    <div className="rounded-md border border-border overflow-hidden max-h-80 overflow-y-auto">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-muted/30">
                            <TableHead className="w-20">קוד סניף</TableHead>
                            <TableHead>שם סניף</TableHead>
                            <TableHead>כתובת</TableHead>
                            <TableHead>עיר</TableHead>
                            <TableHead className="w-16">פעולות</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredBranches.slice(0, 100).map(br => (
                            <TableRow key={br.branchCode} className="hover:bg-muted/20">
                              <TableCell className="font-mono font-medium">{br.branchCode}</TableCell>
                              <TableCell>{br.branchName}</TableCell>
                              <TableCell className="text-sm text-muted-foreground">{br.address}</TableCell>
                              <TableCell className="text-sm">{br.city}</TableCell>
                              <TableCell>
                                <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => openEditBranch(br)}>
                                  <Edit className="h-3 w-3" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                      {filteredBranches.length > 100 && (
                        <div className="p-2 text-center text-xs text-muted-foreground bg-muted/20">
                          מוצגים 100 מתוך {filteredBranches.length} סניפים. צמצם את החיפוש.
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-center py-6 text-muted-foreground text-sm">
                      {branches.length === 0 ? 'אין סניפים לבנק זה' : 'לא נמצאו תוצאות'}
                    </div>
                  )}
                </CardContent>
              )}
            </Card>
          );
        })}
      </div>

      {/* Bank Dialog */}
      <Dialog open={bankDialog} onOpenChange={setBankDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingBank ? 'עריכת בנק' : 'הוספת בנק חדש'}</DialogTitle>
            <DialogDescription>הזן את פרטי הבנק</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>קוד בנק</Label>
              <Input value={bankCode} onChange={e => setBankCode(e.target.value)} placeholder="לדוגמה: 12" disabled={!!editingBank} />
            </div>
            <div>
              <Label>שם בנק</Label>
              <Input value={bankName} onChange={e => setBankName(e.target.value)} placeholder="לדוגמה: בנק הפועלים" />
            </div>
            <Button onClick={saveBank} className="w-full">{editingBank ? 'עדכן' : 'הוסף'}</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Branch Dialog */}
      <Dialog open={branchDialog} onOpenChange={setBranchDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingBranch ? 'עריכת סניף' : 'הוספת סניף חדש'}</DialogTitle>
            <DialogDescription>הזן את פרטי הסניף</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>קוד סניף</Label>
              <Input value={branchCode} onChange={e => setBranchCode(e.target.value)} placeholder="לדוגמה: 620" disabled={!!editingBranch} />
            </div>
            <div>
              <Label>שם סניף</Label>
              <Input value={branchName} onChange={e => setBranchName(e.target.value)} placeholder="לדוגמה: סניף ראשי" />
            </div>
            <div>
              <Label>כתובת</Label>
              <Input value={branchAddress} onChange={e => setBranchAddress(e.target.value)} placeholder="כתובת הסניף" />
            </div>
            <div>
              <Label>עיר</Label>
              <Input value={branchCity} onChange={e => setBranchCity(e.target.value)} placeholder="עיר" />
            </div>
            <Button onClick={saveBranch} className="w-full">{editingBranch ? 'עדכן' : 'הוסף'}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
