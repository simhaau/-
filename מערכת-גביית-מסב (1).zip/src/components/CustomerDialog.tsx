import { useState, useEffect, useCallback, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Banknote, Building2, Shuffle, Search } from 'lucide-react';
import { addCustomer, updateCustomer, getSettings, getAllCustomers, getAllPhases, addActivity } from '@/lib/db';
import { getAllBanks, getBranchesForBank, getBankName, getBranchName } from '@/lib/bankData';
import type { Customer, Group, Phase, Settings, RecurringCharge } from '@/lib/types';
import { toast } from 'sonner';

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  customer: Customer | null;
  groups: Group[];
  onSaved: () => void;
}

const normalizeBankCode = (value: unknown) => {
  const digits = String(value ?? '').replace(/\D/g, '');
  if (!digits) return '';
  const withoutLeadingZeros = digits.replace(/^0+/, '');
  return withoutLeadingZeros || '0';
};

const normalizeAccountValue = (value: unknown) => String(value ?? '').replace(/\D/g, '').trim();

const safeText = (value: unknown) => String(value ?? '').trim();

export default function CustomerDialog({ open, onOpenChange, customer, groups, onSaved }: Props) {
  const [fullName, setFullName] = useState('');
  const [nickname, setNickname] = useState('');
  const [idNumber, setIdNumber] = useState('');
  const [phone, setPhone] = useState('');
  const [phone2, setPhone2] = useState('');
  const [email, setEmail] = useState('');
  const [city, setCity] = useState('');
  const [street, setStreet] = useState('');
  const [houseNumber, setHouseNumber] = useState('');
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'bank' | 'cash' | 'mixed'>('bank');
  const [bankAmount, setBankAmount] = useState(0);
  const [cashAmount, setCashAmount] = useState(0);
  const [bankNumber, setBankNumber] = useState('');
  const [branchNumber, setBranchNumber] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [accountHolderName, setAccountHolderName] = useState('');
  const [authorizationRef, setAuthorizationRef] = useState('');
  const [authorizationDate, setAuthorizationDate] = useState('');
  const [amperes, setAmperes] = useState(0);
  const [chargeMode, setChargeMode] = useState<'amperes' | 'fixed'>('amperes');
  const [fixedMonthly, setFixedMonthly] = useState(0);
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'custom'>('monthly');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [status, setStatus] = useState<'active' | 'paused' | 'cancelled'>('active');
  const [groupId, setGroupId] = useState<number | null>(null);
  const [phaseId, setPhaseId] = useState<number | null>(null);
  const [phases, setPhases] = useState<Phase[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [allCustomers, setAllCustomers] = useState<Customer[]>([]);

  // Bank search
  const [bankSearch, setBankSearch] = useState('');
  const [branchSearch, setBranchSearch] = useState('');
  const [bankFocused, setBankFocused] = useState(false);
  const [branchFocused, setBranchFocused] = useState(false);
  // City/street autocomplete
  const [cityFocused, setCityFocused] = useState(false);
  const [streetFocused, setStreetFocused] = useState(false);

  const isEdit = !!customer;
  const pricePerAmpere = settings?.pricePerAmpere || 0;
  const computedMonthly = chargeMode === 'fixed' ? fixedMonthly : amperes * pricePerAmpere;

  useEffect(() => {
    Promise.all([getSettings(), getAllCustomers(), getAllPhases()]).then(([s, c, p]) => {
      setSettings(s);
      setAllCustomers(c);
      setPhases(p);
    });
  }, [open]);

  // Autocomplete data
  const existingCities = useMemo(() => {
    const map = new Map<string, number>();
    allCustomers.forEach(c => {
      const v = c.city?.trim();
      if (v) map.set(v, (map.get(v) || 0) + 1);
    });
    return Array.from(map.entries()).sort((a, b) => b[1] - a[1]).map(([name]) => name);
  }, [allCustomers]);

  const existingStreets = useMemo(() => {
    const map = new Map<string, number>();
    allCustomers.forEach(c => {
      const v = c.street?.trim();
      if (v) map.set(v, (map.get(v) || 0) + 1);
    });
    return Array.from(map.entries()).sort((a, b) => b[1] - a[1]).map(([name]) => name);
  }, [allCustomers]);

  const citySuggestions = useMemo(() => {
    if (!city || !cityFocused) return [];
    const q = city.toLowerCase();
    return existingCities.filter(c => c.toLowerCase().includes(q) && c.toLowerCase() !== q).slice(0, 5);
  }, [city, existingCities, cityFocused]);

  const streetSuggestions = useMemo(() => {
    if (!street || !streetFocused) return [];
    const q = street.toLowerCase();
    return existingStreets.filter(s => s.toLowerCase().includes(q) && s.toLowerCase() !== q).slice(0, 5);
  }, [street, existingStreets, streetFocused]);

  // Banks data
  const banks = useMemo(() => getAllBanks(), []);
  const filteredBanks = useMemo(() => {
    const q = (bankFocused ? bankSearch : bankNumber).trim().toLowerCase();
    const base = q
      ? banks.filter(b => b.code.includes(q) || b.name.toLowerCase().includes(q))
      : [...banks];
    if (bankNumber && !base.some(b => b.code === bankNumber)) {
      const current = banks.find(b => b.code === bankNumber);
      if (current) base.unshift(current);
    }
    return base.slice(0, 30);
  }, [banks, bankSearch, bankNumber, bankFocused]);

  const branches = useMemo(() => bankNumber ? getBranchesForBank(bankNumber) : [], [bankNumber]);
  const filteredBranches = useMemo(() => {
    const q = (branchFocused ? branchSearch : branchNumber).trim().toLowerCase();
    const base = q
      ? branches.filter(b => b.branchCode.includes(q) || b.branchName.toLowerCase().includes(q) || (b.city || '').toLowerCase().includes(q))
      : [...branches];
    const sliced = base.slice(0, 60);
    // Ensure the currently selected branch is always present
    if (branchNumber && !sliced.some(b => b.branchCode === branchNumber)) {
      const current = branches.find(b => b.branchCode === branchNumber);
      if (current) sliced.unshift(current);
    }
    return sliced;
  }, [branches, branchSearch, branchNumber, branchFocused]);

  const selectedBankName = bankNumber ? getBankName(bankNumber) : '';
  const selectedBranchName = bankNumber && branchNumber ? getBranchName(bankNumber, branchNumber) : '';

  useEffect(() => {
    if (!open) return;
    if (customer) {
      setFullName(customer.fullName);
      setNickname(customer.nickname || '');
      setIdNumber(customer.idNumber);
      setPhone(customer.phone);
      setPhone2(customer.phone2 || '');
      setEmail(customer.email);
      setCity(customer.city || '');
      setStreet(customer.street || '');
      setHouseNumber(customer.houseNumber || '');
      setNotes(customer.notes);
      setPaymentMethod(customer.paymentMethod || 'bank');
      setBankAmount(customer.bankAmount || 0);
      setCashAmount(customer.cashAmount || 0);
      setBankNumber(normalizeBankCode(customer.bankNumber));
      setBranchNumber(normalizeBankCode(customer.branchNumber));
      setAccountNumber(normalizeAccountValue(customer.accountNumber));
      setAccountHolderName(customer.accountHolderName || '');
      setAuthorizationRef(customer.authorizationRef || '');
      setAuthorizationDate(customer.authorizationDate || '');
      setAmperes(customer.amperes || 0);
      const hasAmperes = (customer.amperes || 0) > 0;
      setChargeMode(hasAmperes ? 'amperes' : (customer.monthlyAmount > 0 ? 'fixed' : 'amperes'));
      setFixedMonthly(customer.monthlyAmount || 0);
      setBillingCycle(customer.billingCycle);
      setStartDate(customer.startDate);
      setEndDate(customer.endDate);
      setStatus(customer.status);
      setGroupId(customer.groupId);
      setPhaseId(customer.phaseId ?? null);
    } else {
      setFullName(''); setNickname(''); setIdNumber(''); setPhone(''); setPhone2(''); setEmail('');
      setCity(''); setStreet(''); setHouseNumber('');
      setNotes(''); setPaymentMethod('bank'); setBankAmount(0); setCashAmount(0);
      setBankNumber(''); setBranchNumber(''); setAccountNumber('');
      setAccountHolderName(''); setAuthorizationRef(''); setAuthorizationDate('');
      setAmperes(0); setChargeMode('amperes'); setFixedMonthly(0); setBillingCycle('monthly');
      setStartDate(new Date().toISOString().split('T')[0]); setEndDate('');
      setStatus('active'); setGroupId(null); setPhaseId(null);
    }
    setBankSearch(''); setBranchSearch(''); setBankFocused(false); setBranchFocused(false);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, customer?.id]);

  useEffect(() => {
    if (paymentMethod === 'mixed' && computedMonthly > 0) {
      const sum = bankAmount + cashAmount;
      if (sum <= 0 || sum !== computedMonthly) {
        const half = Math.floor(computedMonthly / 2);
        setBankAmount(half);
        setCashAmount(computedMonthly - half);
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [paymentMethod, computedMonthly]);

  const handleSave = useCallback(async () => {
    if (!fullName.trim()) { toast.error('שם הלקוח חובה'); return; }

    const monthlyAmount = computedMonthly;
    const address = [street, houseNumber, city].filter(Boolean).join(', ');
    let normalizedBankAmount = bankAmount;
    let normalizedCashAmount = cashAmount;

    if (paymentMethod === 'bank') { normalizedBankAmount = monthlyAmount; normalizedCashAmount = 0; }
    if (paymentMethod === 'cash') { normalizedBankAmount = 0; normalizedCashAmount = monthlyAmount; }
    if (paymentMethod === 'mixed') {
      const bank = Math.max(0, Number(bankAmount) || 0);
      const cash = Math.max(0, Number(cashAmount) || 0);
      const totalSplit = bank + cash;
      if (monthlyAmount <= 0) { normalizedBankAmount = 0; normalizedCashAmount = 0; }
      else if (totalSplit <= 0) { const half = Math.floor(monthlyAmount / 2); normalizedBankAmount = half; normalizedCashAmount = monthlyAmount - half; }
      else { const ratio = bank / totalSplit; normalizedBankAmount = Math.round(monthlyAmount * ratio); normalizedCashAmount = monthlyAmount - normalizedBankAmount; }
    }

    try {
      const now = new Date().toISOString();
      const preservedBankNumber = normalizeBankCode(bankNumber) || (customer ? normalizeBankCode(customer.bankNumber) : '');
      const preservedBranchNumber = normalizeBankCode(branchNumber) || (customer ? normalizeBankCode(customer.branchNumber) : '');
      const preservedAccountNumber = normalizeAccountValue(accountNumber) || (customer ? normalizeAccountValue(customer.accountNumber) : '');
      const preservedAccountHolderName = safeText(accountHolderName) || (customer ? safeText(customer.accountHolderName) : '');
      const preservedAuthorizationRef = safeText(authorizationRef) || (customer ? safeText(customer.authorizationRef) : '');
      const preservedAuthorizationDate = safeText(authorizationDate) || (customer ? safeText(customer.authorizationDate) : '');

      let recurringCharges: RecurringCharge[] = customer?.recurringCharges ? [...customer.recurringCharges] : [];
      const effectiveAmperes = chargeMode === 'fixed' ? 0 : amperes;
      const effectiveFixed = chargeMode === 'fixed' ? fixedMonthly : 0;

      if (recurringCharges.length === 0) {
        if (chargeMode === 'amperes' && effectiveAmperes > 0) {
          recurringCharges = [{
            id: `rc_${Date.now()}`,
            label: 'חיוב בסיס',
            type: 'amperes',
            amperes: effectiveAmperes,
            amount: 0,
            createdAt: now,
          }];
        } else if (chargeMode === 'fixed' && effectiveFixed > 0) {
          recurringCharges = [{
            id: `rc_${Date.now()}`,
            label: 'חיוב בסיס',
            type: 'money',
            amperes: 0,
            amount: effectiveFixed,
            createdAt: now,
          }];
        }
      } else {
        const baseIndex = recurringCharges.findIndex(r => r.tagId === 'tag_base' || r.label === 'חיוב בסיס' || r.label === 'בסיס');
        if (baseIndex !== -1) {
          recurringCharges[baseIndex] = {
            ...recurringCharges[baseIndex],
            type: chargeMode === 'fixed' ? 'money' : 'amperes',
            amperes: effectiveAmperes,
            amount: effectiveFixed,
          };
        } else if (effectiveAmperes > 0 || effectiveFixed > 0) {
          recurringCharges.unshift({
            id: `rc_${Date.now()}`,
            label: 'חיוב בסיס',
            type: chargeMode === 'fixed' ? 'money' : 'amperes',
            amperes: effectiveAmperes,
            amount: effectiveFixed,
            createdAt: now,
          });
        }
      }

      const data = {
        fullName, nickname, idNumber, phone, phone2, email, city, street, houseNumber, address, notes,
        paymentMethod, bankAmount: normalizedBankAmount, cashAmount: normalizedCashAmount,
        bankNumber: preservedBankNumber, branchNumber: preservedBranchNumber, accountNumber: preservedAccountNumber, accountHolderName: preservedAccountHolderName,
        authorizationRef: preservedAuthorizationRef, authorizationDate: preservedAuthorizationDate, amperes: chargeMode === 'fixed' ? 0 : amperes, monthlyAmount,
        billingCycle, startDate, endDate,
        chargeFrequencyMonths: 1, status, groupId, phaseId, tags: [] as string[], balance: 0,
        recurringCharges,
      };
      if (isEdit && customer) {
        // build diff for logging
        const labels: Record<string, string> = {
          fullName: 'שם מלא', nickname: 'כינוי', idNumber: 'ת.ז', phone: 'טלפון', phone2: 'טלפון נוסף',
          email: 'אימייל', city: 'עיר', street: 'רחוב', houseNumber: 'מספר בית', notes: 'הערות',
          paymentMethod: 'אופן תשלום', bankNumber: 'בנק', branchNumber: 'סניף', accountNumber: 'חשבון',
          accountHolderName: 'שם בעל חשבון', authorizationRef: 'אסמכתא', authorizationDate: 'תאריך הרשאה',
          amperes: 'אמפרים', monthlyAmount: 'סכום חודשי', startDate: 'תאריך התחלה', endDate: 'תאריך סיום',
          status: 'סטטוס', groupId: 'קבוצה', phaseId: 'פזה', bankAmount: 'סכום בנק', cashAmount: 'סכום מזומן',
        };
        const diff: Array<{ field: string; before: string; after: string }> = [];
        for (const k of Object.keys(labels)) {
          const before = (customer as unknown as Record<string, unknown>)[k];
          const after = (data as unknown as Record<string, unknown>)[k];
          if (JSON.stringify(before ?? '') !== JSON.stringify(after ?? '')) {
            diff.push({ field: labels[k], before: String(before ?? ''), after: String(after ?? '') });
          }
        }
        const prevCustomer = { ...customer };
        await updateCustomer({ ...customer, ...data, updatedAt: now });
        if (diff.length > 0) {
          await addActivity({
            type: 'customer_updated',
            description: `לקוח עודכן: ${data.nickname || data.fullName} — ${diff.map(d => d.field).join(', ')}`,
            customerId: customer.id,
            customerName: data.fullName,
            reversible: true,
            reverseData: JSON.stringify({ restoreCustomer: prevCustomer }),
            diff: JSON.stringify(diff),
            createdAt: now,
          });
        }
        toast.success('הלקוח עודכן');
      } else {
        const newId = await addCustomer({ ...data, createdAt: now, updatedAt: now });
        await addActivity({
          type: 'customer_created',
          description: `לקוח חדש: ${data.nickname || data.fullName}`,
          customerId: newId,
          customerName: data.fullName,
          reversible: true,
          reverseData: JSON.stringify({ customerId: newId }),
          createdAt: now,
        });
        toast.success('לקוח נוסף');
      }
      onOpenChange(false);
      onSaved();
    } catch (err) {
      console.error('Save failed:', err);
      toast.error('שגיאה בשמירה');
    }
  }, [fullName, nickname, idNumber, phone, phone2, email, city, street, houseNumber, notes, paymentMethod, bankAmount, cashAmount, bankNumber, branchNumber, accountNumber, accountHolderName, authorizationRef, authorizationDate, amperes, chargeMode, fixedMonthly, computedMonthly, billingCycle, startDate, endDate, status, groupId, phaseId, isEdit, customer, onOpenChange, onSaved]);

  const paymentMethodOptions = [
    { value: 'bank', label: 'הוראת קבע', icon: Building2, color: 'text-primary' },
    { value: 'cash', label: 'מזומן', icon: Banknote, color: 'text-success' },
    { value: 'mixed', label: 'משולב', icon: Shuffle, color: 'text-warning' },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto" onPointerDownOutside={e => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle>{isEdit ? 'עריכת לקוח' : 'לקוח חדש'}</DialogTitle>
          <DialogDescription>{isEdit ? 'ערוך פרטי לקוח' : 'הזן פרטי לקוח חדש'}</DialogDescription>
        </DialogHeader>

        <form noValidate onSubmit={(e) => { e.preventDefault(); handleSave(); }} className="space-y-6">
          {/* Personal */}
          <div>
            <h3 className="text-sm font-semibold mb-3 text-primary">פרטים אישיים</h3>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">שם מלא *</Label>
                <Input value={fullName} onChange={e => setFullName(e.target.value)} placeholder="ישראל ישראלי" className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">כינוי</Label>
                <Input value={nickname} onChange={e => setNickname(e.target.value)} placeholder="כינוי" className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">תעודת זהות</Label>
                <Input value={idNumber} onChange={e => setIdNumber(e.target.value)} dir="ltr" placeholder="000000000" className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">טלפון</Label>
                <Input value={phone} onChange={e => setPhone(e.target.value)} type="tel" dir="ltr" placeholder="050-0000000" className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">טלפון נוסף</Label>
                <Input value={phone2} onChange={e => setPhone2(e.target.value)} type="tel" dir="ltr" placeholder="050-0000000" className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">אימייל</Label>
                <Input value={email} onChange={e => setEmail(e.target.value)} type="email" dir="ltr" className="h-9" />
              </div>
            </div>
          </div>

          {/* Address with autocomplete */}
          <div>
            <h3 className="text-sm font-semibold mb-3 text-primary">כתובת</h3>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1.5 relative">
                <Label className="text-xs text-muted-foreground">עיר</Label>
                <Input value={city} onChange={e => setCity(e.target.value)}
                  onFocus={() => setCityFocused(true)} onBlur={() => setTimeout(() => setCityFocused(false), 200)}
                  placeholder="עיר" className="h-9" />
                {citySuggestions.length > 0 && (
                  <div className="absolute top-full left-0 right-0 z-50 bg-popover border border-border rounded-lg shadow-lg mt-1 overflow-hidden">
                    {citySuggestions.map(s => (
                      <button key={s} type="button" className="w-full text-right px-3 py-2 text-sm hover:bg-accent transition-colors"
                        onMouseDown={() => { setCity(s); setCityFocused(false); }}>{s}</button>
                    ))}
                  </div>
                )}
              </div>
              <div className="space-y-1.5 relative">
                <Label className="text-xs text-muted-foreground">רחוב</Label>
                <Input value={street} onChange={e => setStreet(e.target.value)}
                  onFocus={() => setStreetFocused(true)} onBlur={() => setTimeout(() => setStreetFocused(false), 200)}
                  placeholder="רחוב" className="h-9" />
                {streetSuggestions.length > 0 && (
                  <div className="absolute top-full left-0 right-0 z-50 bg-popover border border-border rounded-lg shadow-lg mt-1 overflow-hidden">
                    {streetSuggestions.map(s => (
                      <button key={s} type="button" className="w-full text-right px-3 py-2 text-sm hover:bg-accent transition-colors"
                        onMouseDown={() => { setStreet(s); setStreetFocused(false); }}>{s}</button>
                    ))}
                  </div>
                )}
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">מספר בית</Label>
                <Input value={houseNumber} onChange={e => setHouseNumber(e.target.value)} dir="ltr" placeholder="12" className="h-9" />
              </div>
            </div>
          </div>

          {/* Payment Method */}
          <div>
            <h3 className="text-sm font-semibold mb-3 text-primary">אופן תשלום</h3>
            <div className="grid grid-cols-3 gap-2">
              {paymentMethodOptions.map(opt => (
                <button key={opt.value} type="button"
                  onClick={() => setPaymentMethod(opt.value as 'bank' | 'cash' | 'mixed')}
                  className={`flex items-center gap-2 p-3 rounded-xl border-2 transition-all text-sm font-medium ${
                    paymentMethod === opt.value
                      ? 'border-primary bg-primary/5 text-primary shadow-sm'
                      : 'border-border hover:border-muted-foreground/30 text-muted-foreground'
                  }`}>
                  <opt.icon className={`h-4 w-4 ${paymentMethod === opt.value ? opt.color : ''}`} />
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Bank Details */}
          {(paymentMethod === 'bank' || paymentMethod === 'mixed') && (
            <div>
              <h3 className="text-sm font-semibold mb-3 text-primary">פרטי חשבון בנק</h3>
              <div className="grid grid-cols-3 gap-3">
                {/* Bank input with suggestions - keeps saved value stable during editing */}
                <div className="space-y-1.5 relative">
                  <Label className="text-xs text-muted-foreground">בנק</Label>
                  <div className="relative">
                    <Input
                      value={bankFocused ? bankSearch : bankNumber}
                      onChange={e => {
                        const v = e.target.value;
                        setBankSearch(v);
                        if (/^\d*$/.test(v.trim())) setBankNumber(normalizeBankCode(v));
                      }}
                      onFocus={() => { setBankSearch(bankNumber); setBankFocused(true); }}
                      onBlur={() => setTimeout(() => { setBankFocused(false); setBankSearch(''); }, 180)}
                      dir="ltr"
                      placeholder="מספר או שם בנק"
                      className="h-9 pl-8"
                    />
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                  </div>
                  {bankFocused && (
                    <div className="absolute top-full left-0 right-0 z-50 mt-1 overflow-hidden rounded-lg border border-border bg-popover shadow-lg">
                      <div className="max-h-56 overflow-y-auto">
                        {filteredBanks.length === 0 && (
                          <div className="px-3 py-2 text-xs text-muted-foreground">לא נמצאו בנקים</div>
                        )}
                        {filteredBanks.map(b => (
                          <button
                            key={b.code}
                            type="button"
                            className="w-full px-3 py-2 text-right text-sm transition-colors hover:bg-accent"
                            onMouseDown={e => { e.preventDefault(); setBankNumber(b.code); setBankSearch(''); setBankFocused(false); }}
                          >
                            <span className="font-mono" dir="ltr">{b.code}</span> — {b.name}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                {/* Branch input with suggestions - never clears itself when only other fields are edited */}
                <div className="space-y-1.5 relative">
                  <Label className="text-xs text-muted-foreground">סניף</Label>
                  <div className="relative">
                    <Input
                      value={branchFocused ? branchSearch : branchNumber}
                      onChange={e => {
                        const v = e.target.value;
                        setBranchSearch(v);
                        if (/^\d*$/.test(v.trim())) setBranchNumber(normalizeBankCode(v));
                      }}
                      onFocus={() => { setBranchSearch(branchNumber); setBranchFocused(true); }}
                      onBlur={() => setTimeout(() => { setBranchFocused(false); setBranchSearch(''); }, 180)}
                      disabled={!bankNumber}
                      dir="ltr"
                      placeholder="מספר / שם / עיר"
                      className="h-9 pl-8"
                    />
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                  </div>
                  {branchFocused && bankNumber && (
                    <div className="absolute top-full left-0 right-0 z-50 mt-1 overflow-hidden rounded-lg border border-border bg-popover shadow-lg">
                      <div className="max-h-56 overflow-y-auto">
                        {filteredBranches.length === 0 && (
                          <div className="px-3 py-2 text-xs text-muted-foreground">לא נמצאו סניפים</div>
                        )}
                        {filteredBranches.map(b => (
                          <button
                            key={`${b.bankCode}-${b.branchCode}`}
                            type="button"
                            className="w-full px-3 py-2 text-right text-sm transition-colors hover:bg-accent"
                            onMouseDown={e => { e.preventDefault(); setBranchNumber(b.branchCode); setBranchSearch(''); setBranchFocused(false); }}
                          >
                            <span className="font-mono" dir="ltr">{b.branchCode}</span> — {b.branchName} ({b.city})
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground">מספר חשבון</Label>
                  <Input value={accountNumber} onChange={e => setAccountNumber(e.target.value)} dir="ltr" placeholder="123456789" className="h-9" />
                </div>
              </div>
              {selectedBankName && (
                <p className="text-xs text-muted-foreground mt-2">
                  {selectedBankName}{selectedBranchName ? ` • סניף ${selectedBranchName}` : ''}
                </p>
              )}
              <div className="grid grid-cols-2 gap-3 mt-3">
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground">שם בעל החשבון (אנגלית)</Label>
                  <Input value={accountHolderName} onChange={e => setAccountHolderName(e.target.value)} className="h-9" dir="ltr" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground">אסמכתא הרשאה</Label>
                  <Input value={authorizationRef} onChange={e => setAuthorizationRef(e.target.value)} dir="ltr" className="h-9" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground">תאריך הרשאה</Label>
                  <Input value={authorizationDate} onChange={e => setAuthorizationDate(e.target.value)} type="date" dir="ltr" className="h-9" />
                </div>
              </div>
            </div>
          )}

          {/* Billing Config */}
          <div>
            <h3 className="text-sm font-semibold mb-3 text-primary">הגדרות חיוב</h3>
            <div className="mb-3 grid grid-cols-2 gap-2">
              <button type="button" onClick={() => setChargeMode('amperes')}
                className={`p-2 rounded-lg border-2 text-sm font-medium transition-all ${chargeMode === 'amperes' ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'}`}>
                לפי אמפרים
              </button>
              <button type="button" onClick={() => setChargeMode('fixed')}
                className={`p-2 rounded-lg border-2 text-sm font-medium transition-all ${chargeMode === 'fixed' ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'}`}>
                סכום חודשי קבוע
              </button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {chargeMode === 'amperes' ? (
                <>
                  <div className="space-y-1.5">
                    <Label className="text-xs text-muted-foreground">כמות אמפרים</Label>
                    <Input value={amperes || ''} onChange={e => setAmperes(Number(e.target.value) || 0)} type="number" dir="ltr" className="h-9" placeholder="25" />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs text-muted-foreground">סכום חודשי</Label>
                    <div className="h-9 flex items-center px-3 rounded-lg border border-input bg-muted/50 text-sm font-medium" dir="ltr">
                      {pricePerAmpere > 0 ? `₪${computedMonthly.toLocaleString()} (${amperes} × ₪${pricePerAmpere})` : 'הגדר מחיר לאמפר'}
                    </div>
                  </div>
                </>
              ) : (
                <div className="space-y-1.5 col-span-2">
                  <Label className="text-xs text-muted-foreground">סכום חודשי קבוע (₪)</Label>
                  <Input value={fixedMonthly || ''} onChange={e => setFixedMonthly(Number(e.target.value) || 0)} type="number" dir="ltr" className="h-9" placeholder="500" />
                </div>
              )}

              {paymentMethod === 'mixed' && computedMonthly > 0 && (
                <>
                  <div className="space-y-1.5">
                    <Label className="text-xs text-muted-foreground">סכום בנק (₪)</Label>
                    <Input value={bankAmount || ''} onChange={e => { const v = Number(e.target.value) || 0; setBankAmount(v); setCashAmount(computedMonthly - v); }}
                      type="number" dir="ltr" className="h-9" />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs text-muted-foreground">סכום מזומן (₪)</Label>
                    <Input value={cashAmount || ''} onChange={e => { const v = Number(e.target.value) || 0; setCashAmount(v); setBankAmount(computedMonthly - v); }}
                      type="number" dir="ltr" className="h-9" />
                    {bankAmount + cashAmount !== computedMonthly && computedMonthly > 0 && (
                      <p className="text-xs text-destructive">הסכומים לא תואמים</p>
                    )}
                  </div>
                </>
              )}

              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">תאריך התחלה</Label>
                <Input value={startDate} onChange={e => setStartDate(e.target.value)} type="date" dir="ltr" className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">תאריך סיום</Label>
                <Input value={endDate} onChange={e => setEndDate(e.target.value)} type="date" dir="ltr" className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">סטטוס</Label>
                <Select value={status} onValueChange={v => setStatus(v as 'active' | 'paused' | 'cancelled')}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">פעיל</SelectItem>
                    <SelectItem value="paused">מושהה</SelectItem>
                    <SelectItem value="cancelled">מבוטל</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">קבוצה</Label>
                <Select value={groupId ? String(groupId) : 'none'} onValueChange={v => setGroupId(v === 'none' ? null : Number(v))}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">ללא קבוצה</SelectItem>
                    {groups.map(g => <SelectItem key={g.id} value={String(g.id)}>{g.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">פזה (אופציונלי)</Label>
                <Select value={phaseId ? String(phaseId) : 'none'} onValueChange={v => setPhaseId(v === 'none' ? null : Number(v))}>
                  <SelectTrigger className="h-9"><SelectValue placeholder="ללא פזה" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">ללא פזה</SelectItem>
                    {phases.map(p => <SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground">הערות</Label>
            <Textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} />
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-2 sticky bottom-0 bg-background pb-2">
            <Button type="button" variant="secondary" onClick={() => onOpenChange(false)}>ביטול</Button>
            <Button type="button" onClick={handleSave}>{isEdit ? 'שמור' : 'הוסף לקוח'}</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
