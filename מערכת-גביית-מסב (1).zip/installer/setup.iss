; Inno Setup Script for MasavBilling
; Download Inno Setup from: https://jrsoftware.org/isdl.php
; Open this file in Inno Setup Compiler and click Build

[Setup]
AppName=מערכת גבייה - SA מערכות
AppVersion=1.0.0
AppPublisher=SA מערכות
AppPublisherURL=https://simha.rf.gd
DefaultDirName={autopf}\MasavBilling
DefaultGroupName=מערכת גבייה
OutputDir=..\installer-output
OutputBaseFilename=MasavBilling-Setup
Compression=lzma2/ultra64
SolidCompression=yes
SetupIconFile=..\public\favicon.ico
UninstallDisplayIcon={app}\MasavBilling.exe
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog

[Languages]
Name: "hebrew"; MessagesFile: "compiler:Languages\Hebrew.isl"

[Tasks]
Name: "desktopicon"; Description: "צור קיצור דרך בשולחן העבודה"; GroupDescription: "קיצורי דרך:"; Flags: checked

[Files]
; Copy all files from the packaged Electron output
Source: "..\electron-release\MasavBilling-win32-x64\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\מערכת גבייה"; Filename: "{app}\MasavBilling.exe"
Name: "{autodesktop}\מערכת גבייה"; Filename: "{app}\MasavBilling.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\MasavBilling.exe"; Description: "הפעל את מערכת הגבייה"; Flags: nowait postinstall skipifsilent
