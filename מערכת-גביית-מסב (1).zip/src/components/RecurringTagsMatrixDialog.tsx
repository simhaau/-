import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Plus,
  Trash2,
  Edit2,
  Search,
  Save,
  Check,
  Zap,
  DollarSign,
  Layers,
  FileSpreadsheet,
  X,
  Building2,
  Banknote,
  Shuffle,
  Info,
} from 'lucide-react';
import { toast } from 'sonner';
import { Customer, Group, RecurringCharge, RecurringTag, RecurringTagTypeMode } from '@/lib/types';
import {
  getRecurringTags,
  addRecurringTag,
  updateRecurringTag,
  deleteRecurringTag,
} from '@/lib/recurringTags';
import { normalizeCustomerRecurringCharges, getCustomerMonthlyAmount, getCustomerTotalAmperes } from '@/lib/billing';
import { updateCustomer, addActivity } from '@/lib/db';

interface RecurringTagsMatrixDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  customers: Customer[];
  groups: Group[];
  pricePerAmpere: number;
  onSaved: () => void;
}

interface RowState {
  customerId: number;
  hasCharge: boolean;
  type: 'money' | 'amperes';
  amount: number;
  amperes: number;
  isDirty: boolean;
}

const TAG_COLOR_MAP: Record<string, { bg: string; text: string; border: string }> = {
  blue: { bg: 'bg-blue-500/10', text: 'text-blue-500', border: 'border-blue-500/30' },
  amber: { bg: 'bg-amber-500/10', text: 'text-amber-500', border: 'border-amber-500/30' },
  cyan: { bg: 'bg-cyan-500/10', text: 'text-cyan-500', border: 'border-cyan-500/30' },
  emerald: { bg: 'bg-emerald-500/10', text: 'text-emerald-500', border: 'border-emerald-500/30' },
  purple: { bg: 'bg-purple-500/10', text: 'text-purple-500', border: 'border-purple-500/30' },
  rose: { bg: 'bg-rose-500/10', text: 'text-rose-500', border: 'border-rose-500/30' },
};

export default function RecurringTagsMatrixDialog({
  open,
  onOpenChange,
  customers,
  groups,
  pricePerAmpere,
  onSaved,
}: RecurringTagsMatrixDialogProps) {
  const [tags, setTags] = useState<RecurringTag[]>([]);
  const [selectedTagId, setSelectedTagId] = useState<string>('');
  
  // Tag creation/edit dialog
  const [tagDialogOpen, setTagDialogOpen] = useState(false);
  const [editingTag, setEditingTag] = useState<RecurringTag | null>(null);
  const [tagName, setTagName] = useState('');
  const [tagTypeMode, setTagTypeMode] = useState<RecurringTagTypeMode>('flexible');
  const [tagColor, setTagColor] = useState('blue');
  const [tagDescription, setTagDescription] = useState('');

  // Search & filter
  const [searchQuery, setSearchQuery] = useState('');
  const [groupFilter, setGroupFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('active');
  const [chargeFilter, setChargeFilter] = useState<'all' | 'with_charge' | 'without_charge'>('all');

  // Matrix edits: customerId -> RowState
  const [rowEdits, setRowEdits] = useState<Record<number, RowState>>({});
  const [selectedCustomerIds, setSelectedCustomerIds] = useState<Set<number>>(new Set());
  const [saving, setSaving] = useState(false);

  // Bulk input toolbar
  const [bulkMode, setBulkMode] = useState<'money' | 'amperes'>('money');
  const [bulkValue, setBulkValue] = useState<number | ''>('');

  const inputRefs = useRef<Record<number, HTMLInputElement | null>>({});

  // Reload tags
  const loadTags = () => {
    const list = getRecurringTags();
    setTags(list);
    if (list.length > 0 && (!selectedTagId || !list.some(t => t.id === selectedTagId))) {
      setSelectedTagId(list[0].id);
    }
  };

  useEffect(() => {
    if (open) {
      loadTags();
      setSelectedCustomerIds(new Set());
    }
  }, [open]);

  const selectedTag = useMemo(() => {
    return tags.find(t => t.id === selectedTagId) || tags[0] || null;
  }, [tags, selectedTagId]);

  // Initialize row edits whenever selectedTag changes or open
  useEffect(() => {
    if (!selectedTag || !open) return;
    const initialEdits: Record<number, RowState> = {};
    customers.forEach(c => {
      if (!c.id) return;
      const charges = normalizeCustomerRecurringCharges(c);
      // match charge by tagId or label
      const existing = charges.find(
        r => r.tagId === selectedTag.id || r.label.trim().toLowerCase() === selectedTag.name.trim().toLowerCase()
      );

      if (existing) {
        initialEdits[c.id] = {
          customerId: c.id,
          hasCharge: true,
          type: existing.type,
          amount: existing.amount || 0,
          amperes: existing.amperes || 0,
          isDirty: false,
        };
      } else {
        const defaultType = selectedTag.typeMode === 'amperes' ? 'amperes' : 'money';
        initialEdits[c.id] = {
          customerId: c.id,
          hasCharge: false,
          type: defaultType,
          amount: 0,
          amperes: 0,
          isDirty: false,
        };
      }
    });
    setRowEdits(initialEdits);
    setSelectedCustomerIds(new Set());
  }, [selectedTag, customers, open]);

  // Tag stats
  const tagStats = useMemo(() => {
    if (!selectedTag) return { count: 0, totalAmount: 0 };
    let count = 0;
    let totalAmount = 0;
    Object.values(rowEdits).forEach(r => {
      if (r.hasCharge) {
        count++;
        const amt = r.type === 'amperes' ? r.amperes * pricePerAmpere : r.amount;
        totalAmount += amt;
      }
    });
    return { count, totalAmount };
  }, [rowEdits, selectedTag, pricePerAmpere]);

  const dirtyCount = useMemo(() => {
    return Object.values(rowEdits).filter(r => r.isDirty).length;
  }, [rowEdits]);

  // Filtered customer list
  const filteredCustomers = useMemo(() => {
    return customers.filter(c => {
      if (!c.id) return false;
      if (statusFilter === 'active' && c.status !== 'active') return false;
      if (statusFilter === 'paused' && c.status !== 'paused') return false;
      if (statusFilter === 'cancelled' && c.status !== 'cancelled') return false;

      if (groupFilter !== 'all') {
        if (groupFilter === 'none' && c.groupId !== null) return false;
        if (groupFilter !== 'none' && String(c.groupId) !== groupFilter) return false;
      }

      if (searchQuery.trim()) {
        const q = searchQuery.trim().toLowerCase();
        const matchName = (c.fullName || '').toLowerCase().includes(q);
        const matchNick = (c.nickname || '').toLowerCase().includes(q);
        const matchPhone = (c.phone || '').includes(q);
        const matchId = (c.idNumber || '').includes(q);
        if (!matchName && !matchNick && !matchPhone && !matchId) return false;
      }

      const row = rowEdits[c.id];
      if (chargeFilter === 'with_charge' && (!row || !row.hasCharge)) return false;
      if (chargeFilter === 'without_charge' && row && row.hasCharge) return false;

      return true;
    });
  }, [customers, statusFilter, groupFilter, searchQuery, chargeFilter, rowEdits]);

  // Open tag dialog for create or edit
  const openCreateTag = () => {
    setEditingTag(null);
    setTagName('');
    setTagTypeMode('flexible');
    setTagColor('blue');
    setTagDescription('');
    setTagDialogOpen(true);
  };

  const openEditTag = (t: RecurringTag) => {
    setEditingTag(t);
    setTagName(t.name);
    setTagTypeMode(t.typeMode);
    setTagColor(t.color || 'blue');
    setTagDescription(t.description || '');
    setTagDialogOpen(true);
  };

  const handleSaveTag = () => {
    if (!tagName.trim()) {
      toast.error('הזן שם תגית');
      return;
    }
    if (editingTag) {
      updateRecurringTag({
        ...editingTag,
        name: tagName.trim(),
        typeMode: tagTypeMode,
        color: tagColor,
        description: tagDescription.trim(),
      });
      toast.success('התגית עודכנה');
    } else {
      const created = addRecurringTag({
        name: tagName.trim(),
        typeMode: tagTypeMode,
        color: tagColor,
        description: tagDescription.trim(),
      });
      setSelectedTagId(created.id);
      toast.success('תגית חדשה נוצרה');
    }
    loadTags();
    setTagDialogOpen(false);
  };

  const handleDeleteTag = (t: RecurringTag) => {
    if (tags.length <= 1) {
      toast.error('חובה להשאיר לפחות תגית אחת במערכת');
      return;
    }
    if (confirm(`האם למחוק את התגית "${t.name}"? שים לב: החיובים הקיימים יישארו אצל הלקוחות אך התגית תוסר מהרשימה.`)) {
      deleteRecurringTag(t.id);
      loadTags();
      toast.success('התגית נמחקה');
    }
  };

  // Modify cell value
  const handleUpdateRow = (
    customerId: number,
    updates: Partial<RowState>
  ) => {
    setRowEdits(prev => {
      const current = prev[customerId] || {
        customerId,
        hasCharge: false,
        type: selectedTag?.typeMode === 'amperes' ? 'amperes' : 'money',
        amount: 0,
        amperes: 0,
        isDirty: false,
      };

      const next: RowState = {
        ...current,
        ...updates,
        isDirty: true,
      };

      // Determine hasCharge based on amount/amperes
      if (next.type === 'amperes') {
        next.hasCharge = next.amperes > 0;
      } else {
        next.hasCharge = next.amount > 0;
      }

      return {
        ...prev,
        [customerId]: next,
      };
    });
  };

  const handleClearRow = (customerId: number) => {
    setRowEdits(prev => {
      const current = prev[customerId];
      if (!current) return prev;
      return {
        ...prev,
        [customerId]: {
          ...current,
          hasCharge: false,
          amount: 0,
          amperes: 0,
          isDirty: true,
        },
      };
    });
  };

  // Select all / toggle select
  const toggleSelectAll = () => {
    if (selectedCustomerIds.size === filteredCustomers.length) {
      setSelectedCustomerIds(new Set());
    } else {
      setSelectedCustomerIds(new Set(filteredCustomers.map(c => c.id!).filter(Boolean)));
    }
  };

  const toggleSelectOne = (id: number) => {
    setSelectedCustomerIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  // Bulk Apply to selected
  const handleBulkApply = () => {
    if (selectedCustomerIds.size === 0) {
      toast.error('בחר לקוחות להחלת השינוי');
      return;
    }
    const val = Number(bulkValue) || 0;
    if (val < 0) {
      toast.error('הזן ערך תקין');
      return;
    }

    setRowEdits(prev => {
      const next = { ...prev };
      selectedCustomerIds.forEach(id => {
        const cur = next[id] || {
          customerId: id,
          hasCharge: false,
          type: bulkMode,
          amount: 0,
          amperes: 0,
          isDirty: false,
        };
        next[id] = {
          ...cur,
          type: bulkMode,
          amount: bulkMode === 'money' ? val : 0,
          amperes: bulkMode === 'amperes' ? val : 0,
          hasCharge: val > 0,
          isDirty: true,
        };
      });
      return next;
    });

    toast.success(`הוחל בהצלחה על ${selectedCustomerIds.size} לקוחות`);
  };

  const handleBulkClear = () => {
    if (selectedCustomerIds.size === 0) {
      toast.error('בחר לקוחות להסרת החיוב');
      return;
    }
    setRowEdits(prev => {
      const next = { ...prev };
      selectedCustomerIds.forEach(id => {
        const cur = next[id];
        if (cur) {
          next[id] = {
            ...cur,
            hasCharge: false,
            amount: 0,
            amperes: 0,
            isDirty: true,
          };
        }
      });
      return next;
    });
    toast.success(`החיוב אופס עבור ${selectedCustomerIds.size} לקוחות`);
  };

  // Save all dirty changes
  const handleSaveAllChanges = async () => {
    if (!selectedTag) return;
    setSaving(true);
    try {
      const dirtyRows = Object.values(rowEdits).filter(r => r.isDirty);
      if (dirtyRows.length === 0) {
        toast.info('אין שינויים לשמירה');
        setSaving(false);
        return;
      }

      let updatedCount = 0;
      for (const row of dirtyRows) {
        const cust = customers.find(c => c.id === row.customerId);
        if (!cust) continue;

        // Current list of charges
        const existingCharges = normalizeCustomerRecurringCharges(cust);
        let updatedCharges: RecurringCharge[] = [];

        // Check if charge for this tag already exists
        const chargeIndex = existingCharges.findIndex(
          r => r.tagId === selectedTag.id || r.label.trim().toLowerCase() === selectedTag.name.trim().toLowerCase()
        );

        if (row.hasCharge) {
          const newOrUpdatedCharge: RecurringCharge = {
            id: chargeIndex !== -1 ? existingCharges[chargeIndex].id : `rc_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
            label: selectedTag.name,
            tagId: selectedTag.id,
            type: row.type,
            amount: row.type === 'money' ? row.amount : 0,
            amperes: row.type === 'amperes' ? row.amperes : 0,
            createdAt: chargeIndex !== -1 ? existingCharges[chargeIndex].createdAt : new Date().toISOString(),
          };

          if (chargeIndex !== -1) {
            updatedCharges = [...existingCharges];
            updatedCharges[chargeIndex] = newOrUpdatedCharge;
          } else {
            updatedCharges = [...existingCharges, newOrUpdatedCharge];
          }
        } else {
          // Remove charge for this tag if it existed
          if (chargeIndex !== -1) {
            updatedCharges = existingCharges.filter((_, idx) => idx !== chargeIndex);
          } else {
            updatedCharges = [...existingCharges];
          }
        }

        const totalAmp = getCustomerTotalAmperes({ ...cust, recurringCharges: updatedCharges });
        const totalMonthly = getCustomerMonthlyAmount({ ...cust, recurringCharges: updatedCharges }, pricePerAmpere);

        await updateCustomer({
          ...cust,
          recurringCharges: updatedCharges,
          amperes: totalAmp,
          monthlyAmount: totalMonthly,
          updatedAt: new Date().toISOString(),
        });
        updatedCount++;
      }

      await addActivity({
        type: 'bulk_charge',
        description: `עריכה מהירה בטבלת תגיות [${selectedTag.name}]: עודכנו ${updatedCount} לקוחות`,
        amount: tagStats.totalAmount,
        createdAt: new Date().toISOString(),
      });

      // Reset dirty state
      setRowEdits(prev => {
        const next = { ...prev };
        Object.keys(next).forEach(k => {
          const numId = Number(k);
          if (next[numId]) next[numId] = { ...next[numId], isDirty: false };
        });
        return next;
      });

      toast.success(`נשמרו בהצלחה השינויים עבור ${updatedCount} לקוחות`);
      onSaved();
    } catch (e) {
      console.error('Failed to save tag matrix:', e);
      toast.error('שגיאה בשמירת הנתונים');
    } finally {
      setSaving(false);
    }
  };

  // Keyboard navigation for fast Excel-like entry
  const handleKeyDown = (
    e: React.KeyboardEvent<HTMLInputElement>,
    currentIndex: number,
    customerId: number
  ) => {
    if (e.key === 'Enter' || e.key === 'ArrowDown') {
      e.preventDefault();
      const nextCust = filteredCustomers[currentIndex + 1];
      if (nextCust?.id && inputRefs.current[nextCust.id]) {
        inputRefs.current[nextCust.id]?.focus();
        inputRefs.current[nextCust.id]?.select();
      }
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      const prevCust = filteredCustomers[currentIndex - 1];
      if (prevCust?.id && inputRefs.current[prevCust.id]) {
        inputRefs.current[prevCust.id]?.focus();
        inputRefs.current[prevCust.id]?.select();
      }
    }
  };

  // Export current tag table to CSV
  const handleExportCSV = () => {
    if (!selectedTag) return;
    const rows = [
      ['שם לקוח', 'כינוי', 'ת.ז', 'טלפון', 'קבוצה', 'סוג חיוב', 'כמות / סכום', 'סה"כ ש"ח לתגית זו', 'סה"כ חודשי כולל ללקוח'],
      ...filteredCustomers.map(c => {
        const row = rowEdits[c.id!] || { type: 'money', amount: 0, amperes: 0, hasCharge: false };
        const grp = groups.find(g => g.id === c.groupId)?.name || '-';
        const chargeValue = row.hasCharge ? (row.type === 'amperes' ? `${row.amperes}A` : `${row.amount}₪`) : '0';
        const tagTotal = row.hasCharge ? (row.type === 'amperes' ? row.amperes * pricePerAmpere : row.amount) : 0;
        return [
          `"${c.fullName}"`,
          `"${c.nickname || ''}"`,
          `"${c.idNumber || ''}"`,
          `"${c.phone || ''}"`,
          `"${grp}"`,
          row.type === 'amperes' ? 'אמפרים' : 'סכום',
          chargeValue,
          tagTotal,
          getCustomerMonthlyAmount(c, pricePerAmpere),
        ];
      }),
    ];
    const csvContent = '\uFEFF' + rows.map(e => e.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `recurring_tag_${selectedTag.name}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success('קובץ CSV יוצא בהצלחה');
  };

  const currentTagColorStyle = selectedTag?.color ? (TAG_COLOR_MAP[selectedTag.color] || TAG_COLOR_MAP.blue) : TAG_COLOR_MAP.blue;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[95vw] md:max-w-6xl w-full max-h-[92vh] flex flex-col p-4 md:p-6 overflow-hidden">
        <DialogHeader className="space-y-1 pb-2 border-b border-border/40">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                <Layers className="h-5 w-5" />
              </div>
              <div>
                <DialogTitle className="text-lg md:text-xl font-bold flex items-center gap-2">
                  עריכה מהירה של חיובים קבועים לפי תגיות
                  {dirtyCount > 0 && (
                    <Badge variant="destructive" className="text-xs">
                      {dirtyCount} שינויים לא שמורים
                    </Badge>
                  )}
                </DialogTitle>
                <DialogDescription className="text-xs text-muted-foreground">
                  עריכה מרוכזת דמויית-אקסל: בחר תגית והזן סכום או אמפרים במהירות לכל הלקוחות
                </DialogDescription>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleExportCSV}
                className="gap-1.5 text-xs h-8"
                title="ייצא גיליון נוכחי לקובץ CSV"
              >
                <FileSpreadsheet className="h-3.5 w-3.5" />
                <span>ייצוא CSV</span>
              </Button>
              <Button
                size="sm"
                onClick={handleSaveAllChanges}
                disabled={saving || dirtyCount === 0}
                className={`gap-1.5 text-xs h-8 ${dirtyCount > 0 ? 'bg-primary animate-pulse' : ''}`}
              >
                <Save className="h-3.5 w-3.5" />
                <span>שמור שינויים {dirtyCount > 0 ? `(${dirtyCount})` : ''}</span>
              </Button>
            </div>
          </div>

          {/* Tags bar */}
          <div className="flex items-center gap-2 overflow-x-auto pt-2 pb-1 scrollbar-none">
            {tags.map(t => {
              const isSelected = t.id === selectedTagId;
              const colorInfo = TAG_COLOR_MAP[t.color || 'blue'] || TAG_COLOR_MAP.blue;
              return (
                <div
                  key={t.id}
                  onClick={() => setSelectedTagId(t.id)}
                  className={`group relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium cursor-pointer transition-all shrink-0 ${
                    isSelected
                      ? `${colorInfo.bg} ${colorInfo.text} ${colorInfo.border} ring-2 ring-primary/40 shadow-sm font-semibold`
                      : 'bg-muted/40 hover:bg-muted/80 border-border/50 text-foreground'
                  }`}
                >
                  <span>{t.name}</span>
                  <Badge variant="outline" className="text-[10px] px-1 py-0 h-4 border-current">
                    {t.typeMode === 'amperes' ? 'אמפרים' : t.typeMode === 'money' ? '₪ סכום' : 'גמיש ₪/A'}
                  </Badge>
                  {isSelected && (
                    <div className="flex items-center gap-0.5 mr-1">
                      <button
                        type="button"
                        onClick={(e) => { e.stopPropagation(); openEditTag(t); }}
                        className="p-0.5 hover:text-primary transition-colors"
                        title="ערוך תגית"
                      >
                        <Edit2 className="h-3 w-3" />
                      </button>
                      <button
                        type="button"
                        onClick={(e) => { e.stopPropagation(); handleDeleteTag(t); }}
                        className="p-0.5 hover:text-destructive transition-colors"
                        title="מחק תגית"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </div>
                  )}
                </div>
              );
            })}

            <Button
              size="sm"
              variant="outline"
              onClick={openCreateTag}
              className="gap-1 text-xs h-7 shrink-0 border-dashed"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>תגית חדשה</span>
            </Button>
          </div>
        </DialogHeader>

        {/* Selected tag summary & quick bulk actions */}
        <div className="py-2.5 px-3 bg-muted/30 rounded-lg border border-border/40 mt-2 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-4 text-xs">
            <div className="flex items-center gap-1.5">
              <span className="text-muted-foreground">תגית פעילה:</span>
              <span className={`font-semibold ${currentTagColorStyle.text}`}>
                {selectedTag?.name}
              </span>
              <span className="text-muted-foreground">
                ({selectedTag?.typeMode === 'amperes' ? 'חיוב אמפרים' : selectedTag?.typeMode === 'money' ? 'חיוב סכום קבוע' : 'גמיש: סכום או אמפרים'})
              </span>
            </div>
            <div className="h-3.5 w-px bg-border/60" />
            <div>
              <span className="text-muted-foreground">לקוחות מחויבים: </span>
              <span className="font-bold text-foreground">{tagStats.count}</span>
            </div>
            <div className="h-3.5 w-px bg-border/60" />
            <div>
              <span className="text-muted-foreground">סה"כ נגבה בתגית זו: </span>
              <span className="font-bold text-success">₪{tagStats.totalAmount.toLocaleString()}</span>
            </div>
            <div className="h-3.5 w-px bg-border/60" />
            <div>
              <span className="text-muted-foreground">תעריף אמפר: </span>
              <span className="font-mono font-medium">₪{pricePerAmpere}</span>
            </div>
          </div>

          {/* Bulk tools */}
          <div className="flex items-center gap-2 text-xs flex-wrap">
            <span className="text-muted-foreground">
              פעולה מהירה ל-{selectedCustomerIds.size} מסומנים:
            </span>
            {selectedTag?.typeMode === 'flexible' && (
              <Select value={bulkMode} onValueChange={(v) => setBulkMode(v as 'money' | 'amperes')}>
                <SelectTrigger className="h-7 w-20 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="money">סכום ₪</SelectItem>
                  <SelectItem value="amperes">אמפר A</SelectItem>
                </SelectContent>
              </Select>
            )}
            <Input
              type="number"
              value={bulkValue}
              onChange={(e) => setBulkValue(e.target.value === '' ? '' : Number(e.target.value))}
              placeholder={selectedTag?.typeMode === 'amperes' || bulkMode === 'amperes' ? 'אמפרים' : 'סכום ₪'}
              className="h-7 w-24 text-xs font-mono"
              dir="ltr"
            />
            <Button
              size="sm"
              variant="secondary"
              onClick={handleBulkApply}
              disabled={selectedCustomerIds.size === 0 || bulkValue === ''}
              className="h-7 text-xs px-2.5"
            >
              החל
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={handleBulkClear}
              disabled={selectedCustomerIds.size === 0}
              className="h-7 text-xs px-2 text-destructive hover:bg-destructive/10"
              title="נקה חיוב זה עבור כל המסומנים"
            >
              נקה
            </Button>
          </div>
        </div>

        {/* Filter bar */}
        <div className="flex items-center justify-between gap-3 py-2 flex-wrap">
          <div className="flex items-center gap-2 flex-1 min-w-[200px] max-w-sm">
            <div className="relative w-full">
              <Search className="absolute right-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="חפש לקוח, כינוי, טלפון..."
                className="h-8 pr-8 text-xs"
              />
              {searchQuery && (
                <button onClick={() => setSearchQuery('')} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  <X className="h-3 w-3" />
                </button>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap text-xs">
            <Select value={groupFilter} onValueChange={setGroupFilter}>
              <SelectTrigger className="h-8 w-32 text-xs"><SelectValue placeholder="כל הקבוצות" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">כל הקבוצות</SelectItem>
                <SelectItem value="none">ללא קבוצה</SelectItem>
                {groups.map(g => (
                  <SelectItem key={g.id} value={String(g.id)}>{g.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="h-8 w-28 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="active">פעילים בלבד</SelectItem>
                <SelectItem value="all">כל הסטטוסים</SelectItem>
                <SelectItem value="paused">מושהים</SelectItem>
                <SelectItem value="cancelled">מבוטלים</SelectItem>
              </SelectContent>
            </Select>

            <Select value={chargeFilter} onValueChange={(v) => setChargeFilter(v as 'all' | 'with_charge' | 'without_charge')}>
              <SelectTrigger className="h-8 w-32 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">הכל (מחויבים וללא)</SelectItem>
                <SelectItem value="with_charge">רק עם חיוב בתגית</SelectItem>
                <SelectItem value="without_charge">ללא חיוב בתגית</SelectItem>
              </SelectContent>
            </Select>

            <span className="text-muted-foreground mr-1">
              מוצגים: {filteredCustomers.length} לקוחות
            </span>
          </div>
        </div>

        {/* Excel-like Table */}
        <div className="flex-1 overflow-auto rounded-lg border border-border/50 bg-background shadow-inner">
          <Table className="relative">
            <TableHeader className="sticky top-0 bg-muted/80 backdrop-blur z-20 border-b border-border">
              <TableRow className="h-9 hover:bg-transparent">
                <TableHead className="w-10 text-center">
                  <Checkbox
                    checked={filteredCustomers.length > 0 && selectedCustomerIds.size === filteredCustomers.length}
                    onCheckedChange={toggleSelectAll}
                  />
                </TableHead>
                <TableHead className="w-12 text-center text-xs">#</TableHead>
                <TableHead className="min-w-[160px] text-xs">שם לקוח</TableHead>
                <TableHead className="w-28 text-xs">קבוצה</TableHead>
                <TableHead className="w-24 text-xs">אופן תשלום</TableHead>
                {selectedTag?.typeMode === 'flexible' && (
                  <TableHead className="w-32 text-center text-xs">סוג חיוב (₪ / A)</TableHead>
                )}
                <TableHead className="min-w-[200px] text-xs">
                  ערך להזנה ({selectedTag?.typeMode === 'amperes' ? 'אמפרים' : selectedTag?.typeMode === 'money' ? 'סכום חודשי ₪' : 'סכום או אמפרים'})
                </TableHead>
                <TableHead className="w-28 text-center text-xs">סה"כ לתגית</TableHead>
                <TableHead className="w-28 text-center text-xs">סה"כ ללקוח</TableHead>
                <TableHead className="w-16 text-center text-xs">פעולות</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCustomers.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={10} className="text-center py-12 text-muted-foreground text-sm">
                    לא נמצאו לקוחות מתאימים לסינון
                  </TableCell>
                </TableRow>
              ) : (
                filteredCustomers.map((c, idx) => {
                  const id = c.id!;
                  const row = rowEdits[id] || {
                    customerId: id,
                    hasCharge: false,
                    type: selectedTag?.typeMode === 'amperes' ? 'amperes' : 'money',
                    amount: 0,
                    amperes: 0,
                    isDirty: false,
                  };

                  const isSelected = selectedCustomerIds.has(id);
                  const effectiveType = selectedTag?.typeMode === 'amperes' ? 'amperes' : selectedTag?.typeMode === 'money' ? 'money' : row.type;
                  const chargeAmount = effectiveType === 'amperes' ? row.amperes * pricePerAmpere : row.amount;
                  const currentMonthly = getCustomerMonthlyAmount(c, pricePerAmpere);
                  const grp = groups.find(g => g.id === c.groupId);

                  return (
                    <TableRow
                      key={id}
                      className={`h-11 transition-colors ${isSelected ? 'bg-primary/5' : ''} ${row.isDirty ? 'bg-amber-500/5' : ''}`}
                    >
                      <TableCell className="text-center p-1">
                        <Checkbox
                          checked={isSelected}
                          onCheckedChange={() => toggleSelectOne(id)}
                        />
                      </TableCell>

                      <TableCell className="text-center text-xs text-muted-foreground font-mono p-1">
                        {idx + 1}
                      </TableCell>

                      <TableCell className="p-2">
                        <div className="flex flex-col">
                          <span className="font-semibold text-xs leading-tight">
                            {c.fullName}
                            {c.nickname && (
                              <span className="text-[11px] text-muted-foreground font-normal mr-1">
                                ({c.nickname})
                              </span>
                            )}
                          </span>
                          <span className="text-[10px] text-muted-foreground font-mono" dir="ltr">
                            {c.phone || c.idNumber}
                          </span>
                        </div>
                      </TableCell>

                      <TableCell className="p-2">
                        {grp ? (
                          <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4 truncate max-w-[100px]">
                            {grp.name}
                          </Badge>
                        ) : (
                          <span className="text-muted-foreground text-xs">—</span>
                        )}
                      </TableCell>

                      <TableCell className="p-2">
                        <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground">
                          {c.paymentMethod === 'bank' && <Building2 className="h-3 w-3 text-primary" />}
                          {c.paymentMethod === 'cash' && <Banknote className="h-3 w-3 text-success" />}
                          {c.paymentMethod === 'mixed' && <Shuffle className="h-3 w-3 text-warning" />}
                          {c.paymentMethod === 'bank' ? 'בנק' : c.paymentMethod === 'cash' ? 'מזומן' : 'משולב'}
                        </span>
                      </TableCell>

                      {/* Type Toggle if Flexible */}
                      {selectedTag?.typeMode === 'flexible' && (
                        <TableCell className="p-2 text-center">
                          <div className="inline-flex rounded-md border border-border p-0.5 bg-muted/40">
                            <button
                              type="button"
                              onClick={() => handleUpdateRow(id, { type: 'money' })}
                              className={`px-2 py-0.5 text-[11px] rounded transition-colors ${
                                row.type === 'money' ? 'bg-background shadow-xs font-semibold text-primary' : 'text-muted-foreground hover:text-foreground'
                              }`}
                            >
                              ₪ סכום
                            </button>
                            <button
                              type="button"
                              onClick={() => handleUpdateRow(id, { type: 'amperes' })}
                              className={`px-2 py-0.5 text-[11px] rounded transition-colors ${
                                row.type === 'amperes' ? 'bg-background shadow-xs font-semibold text-amber-500' : 'text-muted-foreground hover:text-foreground'
                              }`}
                            >
                              A אמפר
                            </button>
                          </div>
                        </TableCell>
                      )}

                      {/* Editable Value (Excel input) */}
                      <TableCell className="p-2">
                        <div className="flex items-center gap-2">
                          <div className="relative flex-1 max-w-[170px]">
                            <Input
                              ref={el => { inputRefs.current[id] = el; }}
                              type="number"
                              value={effectiveType === 'amperes' ? (row.amperes || '') : (row.amount || '')}
                              onChange={(e) => {
                                const val = e.target.value === '' ? 0 : Number(e.target.value);
                                if (effectiveType === 'amperes') {
                                  handleUpdateRow(id, { amperes: val, type: 'amperes' });
                                } else {
                                  handleUpdateRow(id, { amount: val, type: 'money' });
                                }
                              }}
                              onKeyDown={(e) => handleKeyDown(e, idx, id)}
                              placeholder="0"
                              dir="ltr"
                              className={`h-8 text-xs font-mono font-medium pl-6 pr-2 ${
                                row.isDirty ? 'border-amber-500 bg-amber-500/10 focus-visible:ring-amber-500' : ''
                              } ${row.hasCharge ? 'border-primary/50 font-bold' : ''}`}
                            />
                            <span className="absolute left-2 top-1/2 -translate-y-1/2 text-[10px] text-muted-foreground font-mono">
                              {effectiveType === 'amperes' ? 'A' : '₪'}
                            </span>
                          </div>

                          {effectiveType === 'amperes' && (
                            <span className="text-[11px] font-mono text-muted-foreground shrink-0">
                              = ₪{((row.amperes || 0) * pricePerAmpere).toLocaleString()}
                            </span>
                          )}

                          {row.hasCharge && (
                            <Button
                              size="icon"
                              variant="ghost"
                              onClick={() => handleClearRow(id)}
                              className="h-6 w-6 text-muted-foreground hover:text-destructive shrink-0"
                              title="אפס חיוב"
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </TableCell>

                      {/* Total for this Tag */}
                      <TableCell className="p-2 text-center font-mono text-xs font-medium">
                        {chargeAmount > 0 ? (
                          <span className="text-foreground">₪{chargeAmount.toLocaleString()}</span>
                        ) : (
                          <span className="text-muted-foreground">—</span>
                        )}
                      </TableCell>

                      {/* Customer total monthly */}
                      <TableCell className="p-2 text-center font-mono text-xs font-bold text-success">
                        ₪{currentMonthly.toLocaleString()}
                      </TableCell>

                      {/* Row actions */}
                      <TableCell className="p-2 text-center">
                        {row.isDirty && (
                          <span className="inline-block w-2 h-2 rounded-full bg-amber-500 animate-pulse" title="שינוי לא שמור" />
                        )}
                        {!row.isDirty && row.hasCharge && (
                          <Check className="h-3.5 w-3.5 text-success inline-block" title="נשמר" />
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>

        {/* Footer info & hotkeys */}
        <div className="pt-3 border-t border-border/40 mt-2 flex items-center justify-between text-xs text-muted-foreground flex-wrap gap-2">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 rounded border bg-muted font-mono text-[10px]">Enter</kbd> / <kbd className="px-1.5 py-0.5 rounded border bg-muted font-mono text-[10px]">↓</kbd>
              <span>מעבר לשורה הבאה</span>
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 rounded border bg-muted font-mono text-[10px]">↑</kbd>
              <span>מעבר לשורה הקודמת</span>
            </span>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
              סגור
            </Button>
            <Button
              size="sm"
              onClick={handleSaveAllChanges}
              disabled={saving || dirtyCount === 0}
              className="gap-1.5"
            >
              <Save className="h-4 w-4" />
              <span>שמור הכל</span>
            </Button>
          </div>
        </div>

        {/* Dialog for Tag Create/Edit */}
        <Dialog open={tagDialogOpen} onOpenChange={setTagDialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{editingTag ? 'עריכת תגית קבועה' : 'יצירת תגית קבועה חדשה'}</DialogTitle>
              <DialogDescription>
                הגדר את שם התגית ואת סוג החיוב המותר (סכום, אמפרים או גמיש)
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-2">
              <div className="space-y-1.5">
                <Label className="text-xs">שם התגית</Label>
                <Input
                  value={tagName}
                  onChange={(e) => setTagName(e.target.value)}
                  placeholder="לדוגמה: אינטרנט סיבים, דמי חניה, מיזוג"
                />
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs">סוג חיוב מוגדר לתגית זו</Label>
                <Select
                  value={tagTypeMode}
                  onValueChange={(v) => setTagTypeMode(v as RecurringTagTypeMode)}
                >
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="money">סכום קבוע (₪ בלבד)</SelectItem>
                    <SelectItem value="amperes">אמפרים (A בלבד - מחושב לפי תעריף)</SelectItem>
                    <SelectItem value="flexible">גמיש (לפעמים סכום ולפעמים אמפרים)</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-[11px] text-muted-foreground">
                  {tagTypeMode === 'money' && 'כל לקוח תחת תגית זו יחויב בסכום שקלים קבוע.'}
                  {tagTypeMode === 'amperes' && 'כל לקוח יחויב לפי מספר אמפרים המוכפל בתעריף לאמפר.'}
                  {tagTypeMode === 'flexible' && 'ניתן להגדיר עבור כל לקוח באופן פרטני האם החיוב הוא בסכום או לפי אמפרים.'}
                </p>
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs">צבע הדגשה</Label>
                <div className="flex items-center gap-2">
                  {Object.keys(TAG_COLOR_MAP).map((cKey) => {
                    const cInfo = TAG_COLOR_MAP[cKey];
                    return (
                      <button
                        key={cKey}
                        type="button"
                        onClick={() => setTagColor(cKey)}
                        className={`w-7 h-7 rounded-full border-2 transition-all ${cInfo.bg} ${
                          tagColor === cKey ? 'border-primary scale-110 shadow-sm' : 'border-transparent opacity-70'
                        }`}
                      />
                    );
                  })}
                </div>
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs">הערות / תיאור (אופציונלי)</Label>
                <Input
                  value={tagDescription}
                  onChange={(e) => setTagDescription(e.target.value)}
                  placeholder="הסבר על מטרת החיוב"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setTagDialogOpen(false)}>ביטול</Button>
              <Button onClick={handleSaveTag}>{editingTag ? 'עדכן תגית' : 'צור תגית'}</Button>
            </div>
          </DialogContent>
        </Dialog>
      </DialogContent>
    </Dialog>
  );
}
