import { useState, useEffect, useMemo } from 'react';
import { ArrowRight, User, CreditCard, Banknote, Calendar, TrendingUp, TrendingDown, AlertCircle, CheckCircle2, Clock, Zap, Building2, Shuffle, FileText, Plus, Trash2, EyeOff, Eye, Pencil, Download, FileSpreadsheet, CalendarClock, Undo2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { getDebtsByCustomer, getSettings, getAllActivities, getAllBatches, addDebt, updateDebt, deleteDebt, addActivity } from '@/lib/db';
import { getCustomerMonthlyAmount, getCustomerBaseMonthlyAmount, getRecurringChargesAmount } from '@/lib/billing';
import { getBankName, getBranchName } from '@/lib/bankData';
import { updateCustomer } from '@/lib/db';
import { getRecurringTags, addRecurringTag, getTagColorClasses, ensureCustomerRecurringCharges, TAG_COLOR_OPTIONS } from '@/lib/recurringTags';
import type { Customer, DebtRecord, Settings, ActivityLog, BillingBatch, RecurringCharge, RecurringTag, RecurringTagTypeMode } from '@/lib/types';
import { toast } from 'sonner';

interface Props {
  customer: Customer;
  onBack: () => void;
}

export default function CustomerDetailView({ customer, onBack }: Props) {
  const [debts, setDebts] = useState<DebtRecord[]>([]);
  const [activities, setActivities] = useState<ActivityLog[]>([]);
  const [batches, setBatches] = useState<BillingBatch[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null);

  const [addChargeDialog, setAddChargeDialog] = useState(false);
  const [chargeType, setChargeType] = useState<'money' | 'amperes'>('money');
  const [chargeAmount, setChargeAmount] = useState(0);
  const [chargeAmperes, setChargeAmperes] = useState(0);
  const [chargeMonth, setChargeMonth] = useState(() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  });
  const [chargeSpreadMonths, setChargeSpreadMonths] = useState(1);
  const [chargeNotes, setChargeNotes] = useState('');

  const [editDialog, setEditDialog] = useState<DebtRecord | null>(null);
  const [editAmount, setEditAmount] = useState(0);
  const [editNotes, setEditNotes] = useState('');

  const [deleteTarget, setDeleteTarget] = useState<DebtRecord | null>(null);

  // Split debt dialog
  const [splitTarget, setSplitTarget] = useState<DebtRecord | null>(null);
  const [splitMonths, setSplitMonths] = useState(2);
  const [splitMode, setSplitMode] = useState<'auto' | 'manual'>('auto');
  const [splitAmounts, setSplitAmounts] = useState<number[]>([]);

  // Recurring (fixed) monthly charges with Tag support
  const [recList, setRecList] = useState<RecurringCharge[]>(() => ensureCustomerRecurringCharges(customer));
  const [recDialog, setRecDialog] = useState(false);
  const [editingCharge, setEditingCharge] = useState<RecurringCharge | null>(null);
  const [recType, setRecType] = useState<'money' | 'amperes'>('money');
  const [recAmount, setRecAmount] = useState(0);
  const [recAmperes, setRecAmperes] = useState(0);
  const [recLabel, setRecLabel] = useState('');
  const [recTagId, setRecTagId] = useState<string>('');

  const [availableTags, setAvailableTags] = useState<RecurringTag[]>([]);
  const [newTagDialogOpen, setNewTagDialogOpen] = useState(false);
  const [newTagName, setNewTagName] = useState('');
  const [newTagTypeMode, setNewTagTypeMode] = useState<RecurringTagTypeMode>('flexible');
  const [newTagColor, setNewTagColor] = useState('blue');

  const refreshTags = () => {
    const tags = getRecurringTags();
    setAvailableTags(tags);
    return tags;
  };

  useEffect(() => {
    refreshTags();
  }, []);

  useEffect(() => {
    const list = ensureCustomerRecurringCharges(customer);
    setRecList(list);
    if ((!customer.recurringCharges || customer.recurringCharges.length === 0) && list.length > 0) {
      customer.recurringCharges = list;
      updateCustomer({ ...customer, recurringCharges: list, updatedAt: new Date().toISOString() });
    }
  }, [customer.id]);

  const loadData = () => {
    Promise.all([
      getDebtsByCustomer(customer.id!),
      getSettings(),
      getAllActivities(),
      getAllBatches(),
    ]).then(([d, s, a, b]) => {
      setDebts(d);
      setSettings(s);
      setActivities(a.filter(act => act.customerId === customer.id));
      setBatches(b);
    });
  };

  useEffect(() => { loadData(); }, [customer.id]);

  const pricePerAmpere = settings?.pricePerAmpere || 0;
  const totalAmperes = recList.filter(rc => rc.type === 'amperes').reduce((s, rc) => s + (rc.amperes || 0), 0);
  const monthlyAmount = recList.reduce((s, rc) => {
    if (rc.type === 'amperes') return s + (rc.amperes || 0) * pricePerAmpere;
    return s + (rc.amount || 0);
  }, 0);
  const bankLabel = customer.bankNumber ? getBankName(customer.bankNumber) : '';
  const branchLabel = customer.bankNumber && customer.branchNumber ? getBranchName(customer.bankNumber, customer.branchNumber) : '';
  const displayName = customer.nickname || customer.fullName;

  const persistRecurring = async (list: RecurringCharge[], logDesc: string, prev: RecurringCharge[]) => {
    setRecList(list);
    customer.recurringCharges = list;
    const newAmperes = list.filter(r => r.type === 'amperes').reduce((s, r) => s + (r.amperes || 0), 0);
    const newMonthly = list.reduce((s, r) => {
      if (r.type === 'amperes') return s + (r.amperes || 0) * pricePerAmpere;
      return s + (r.amount || 0);
    }, 0);
    customer.amperes = newAmperes;
    customer.monthlyAmount = newMonthly;
    await updateCustomer({
      ...customer,
      recurringCharges: list,
      amperes: newAmperes,
      monthlyAmount: newMonthly,
      updatedAt: new Date().toISOString(),
    });
    await addActivity({
      type: 'extra_charge',
      description: logDesc,
      customerId: customer.id,
      customerName: customer.fullName,
      reversible: true,
      reverseData: JSON.stringify({ kind: 'recurring_charges', customerId: customer.id, previous: prev }),
      createdAt: new Date().toISOString(),
    });
  };

  const handleOpenAddRecurring = () => {
    const tags = refreshTags();
    setEditingCharge(null);
    const defaultTag = tags[0];
    const initialTagId = defaultTag ? defaultTag.id : '';
    setRecTagId(initialTagId);
    setRecLabel(defaultTag ? defaultTag.name : '');
    if (defaultTag?.typeMode === 'amperes') {
      setRecType('amperes');
    } else {
      setRecType('money');
    }
    setRecAmount(0);
    setRecAmperes(0);
    setRecDialog(true);
  };

  const handleOpenEditRecurring = (charge: RecurringCharge) => {
    refreshTags();
    setEditingCharge(charge);
    setRecTagId(charge.tagId || '');
    setRecLabel(charge.label || '');
    setRecType(charge.type);
    setRecAmount(charge.amount || 0);
    setRecAmperes(charge.amperes || 0);
    setRecDialog(true);
  };

  const handleSelectTag = (tagId: string) => {
    setRecTagId(tagId);
    const tag = availableTags.find(t => t.id === tagId);
    if (tag) {
      if (!editingCharge || !recLabel) {
        setRecLabel(tag.name);
      }
      if (tag.typeMode === 'amperes') {
        setRecType('amperes');
      } else if (tag.typeMode === 'money') {
        setRecType('money');
      }
    }
  };

  const handleSaveRecurring = async () => {
    if (recType === 'money' && recAmount <= 0) {
      toast.error('הזן סכום חודשי (₪) גדול מ-0');
      return;
    }
    if (recType === 'amperes' && recAmperes <= 0) {
      toast.error('הזן כמות אמפרים גדולה מ-0');
      return;
    }

    const tag = availableTags.find(t => t.id === recTagId);
    const label = recLabel.trim() || tag?.name || (recType === 'money' ? 'חיוב חודשי קבוע' : 'אמפרים קבועים');
    const prev = [...recList];

    if (editingCharge) {
      const updatedList = recList.map(item => {
        if (item.id === editingCharge.id) {
          return {
            ...item,
            label,
            tagId: recTagId,
            type: recType,
            amount: recType === 'money' ? recAmount : 0,
            amperes: recType === 'amperes' ? recAmperes : 0,
            updatedAt: new Date().toISOString(),
          };
        }
        return item;
      });
      await persistRecurring(updatedList, `עודכן חיוב קבוע ל${customer.fullName}: ${label}`, prev);
      toast.success('החיוב הקבוע עודכן בהצלחה');
    } else {
      const newCharge: RecurringCharge = {
        id: `rc_${Date.now()}`,
        label,
        tagId: recTagId,
        type: recType,
        amount: recType === 'money' ? recAmount : 0,
        amperes: recType === 'amperes' ? recAmperes : 0,
        createdAt: new Date().toISOString(),
      };
      await persistRecurring([...recList, newCharge], `נוסף חיוב קבוע ל${customer.fullName}: ${label}`, prev);
      toast.success('החיוב הקבוע נוסף בהצלחה');
    }

    setRecDialog(false);
    setEditingCharge(null);
  };

  const handleDeleteRecurring = async (id: string) => {
    const prev = [...recList];
    const target = recList.find(r => r.id === id);
    await persistRecurring(recList.filter(r => r.id !== id), `הוסר חיוב חודשי קבוע מ${customer.fullName}: ${target?.label || ''}`, prev);
    toast.success('החיוב הקבוע הוסר בהצלחה');
  };

  const handleCreateNewTag = () => {
    if (!newTagName.trim()) {
      toast.error('הזן שם לתגית');
      return;
    }
    const created = addRecurringTag({
      name: newTagName.trim(),
      typeMode: newTagTypeMode,
      color: newTagColor,
    });
    refreshTags();
    setRecTagId(created.id);
    setRecLabel(created.name);
    if (created.typeMode === 'amperes') {
      setRecType('amperes');
    } else if (created.typeMode === 'money') {
      setRecType('money');
    }
    setNewTagDialogOpen(false);
    setNewTagName('');
    toast.success(`תגית "${created.name}" נוצרה בהצלחה`);
  };

  const now = new Date();
  const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

  const currentMonthDebts = useMemo(() => debts.filter(d => d.month === currentMonth), [debts, currentMonth]);
  const activeCurrentDebts = useMemo(() => currentMonthDebts.filter(d => d.status !== 'suspended'), [currentMonthDebts]);
  const currentMonthTotal = activeCurrentDebts.reduce((s, d) => s + d.amount, 0);
  const currentMonthPaid = activeCurrentDebts.reduce((s, d) => s + d.paidAmount, 0);
  const currentMonthBalance = currentMonthTotal - currentMonthPaid;
  const currentMonthPending = activeCurrentDebts.filter(d => d.status === 'pending_collection').reduce((s, d) => s + (d.amount - d.paidAmount), 0);

  const baseDebts = useMemo(() => activeCurrentDebts.filter(d => !d.notes || (!d.notes.includes('אמפרים נוספים') && !d.notes.includes('חיוב נוסף'))), [activeCurrentDebts]);
  const extraDebts = useMemo(() => activeCurrentDebts.filter(d => d.notes && (d.notes.includes('אמפרים נוספים') || d.notes.includes('חיוב נוסף'))), [activeCurrentDebts]);
  const baseTotal = baseDebts.reduce((s, d) => s + d.amount, 0);
  const extrasTotal = extraDebts.reduce((s, d) => s + d.amount, 0);

  const activeDebts = useMemo(() => debts.filter(d => d.status !== 'suspended'), [debts]);
  const totalEverCharged = useMemo(() => activeDebts.reduce((s, d) => s + d.amount, 0), [activeDebts]);
  const totalEverPaid = useMemo(() => activeDebts.reduce((s, d) => s + d.paidAmount, 0), [activeDebts]);
  const openDebtTotal = useMemo(() =>
    activeDebts.filter(d => d.status !== 'paid' && d.status !== 'advance').reduce((s, d) => s + (d.amount - d.paidAmount), 0),
    [activeDebts]
  );
  const suspendedCount = useMemo(() => debts.filter(d => d.status === 'suspended').length, [debts]);

  const customerBatches = useMemo(() => {
    return batches
      .filter(b => b.transactions.some(t => t.customerId === customer.id && t.status === 'included'))
      .map(b => {
        const tx = b.transactions.find(t => t.customerId === customer.id)!;
        return { ...b, customerAmount: tx.amount };
      })
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }, [batches, customer.id]);

  const futureMonthDebts = useMemo(() => debts.filter(d => d.month > currentMonth), [debts, currentMonth]);

  const futureMonthBreakdown = useMemo(() => {
    const map = new Map<string, { debts: DebtRecord[]; total: number }>();
    futureMonthDebts.forEach(d => {
      const existing = map.get(d.month) || { debts: [], total: 0 };
      existing.debts.push(d);
      if (d.status !== 'suspended') existing.total += d.amount;
      map.set(d.month, existing);
    });
    return Array.from(map.entries()).sort(([a], [b]) => a.localeCompare(b)).map(([month, data]) => ({ month, ...data }));
  }, [futureMonthDebts]);

  const monthlyBreakdown = useMemo(() => {
    const map = new Map<string, { debts: DebtRecord[]; total: number; paid: number; pending: number }>();
    debts.forEach(d => {
      const existing = map.get(d.month) || { debts: [], total: 0, paid: 0, pending: 0 };
      existing.debts.push(d);
      if (d.status !== 'suspended') {
        existing.total += d.amount;
        existing.paid += d.paidAmount;
        if (d.status === 'pending_collection') existing.pending += (d.amount - d.paidAmount);
      }
      map.set(d.month, existing);
    });
    return Array.from(map.entries())
      .sort(([a], [b]) => b.localeCompare(a))
      .map(([month, data]) => ({ month, ...data, balance: data.total - data.paid }));
  }, [debts]);

  const sortedActivities = useMemo(() =>
    [...activities].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 50),
    [activities]
  );

  const handleAddCharge = async () => {
    const amount = chargeType === 'amperes' ? chargeAmperes * pricePerAmpere : chargeAmount;
    if (amount <= 0) { toast.error('סכום חייב להיות גדול מ-0'); return; }
    const baseNote = chargeType === 'amperes'
      ? `חיוב נוסף: ${chargeAmperes} אמפרים${chargeNotes ? ' - ' + chargeNotes : ''}`
      : `חיוב נוסף${chargeNotes ? ': ' + chargeNotes : ''}`;
    const spread = Math.max(1, chargeSpreadMonths);
    const [y, mo] = chargeMonth.split('-').map(Number);
    const createdIds: number[] = [];
    for (let i = 0; i < spread; i++) {
      const d = new Date(y, mo - 1 + i);
      const m = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const notes = spread > 1 ? `${baseNote} (${i + 1}/${spread})` : baseNote;
      const id = await addDebt({
        customerId: customer.id!,
        customerName: customer.fullName,
        month: m,
        amount,
        paidAmount: 0,
        status: 'unpaid',
        paidDate: '',
        notes,
        createdAt: new Date().toISOString(),
      });
      createdIds.push(id);
    }
    await addActivity({
      type: 'extra_charge',
      description: `חיוב נוסף ₪${amount.toLocaleString()} עבור ${displayName}${spread > 1 ? ` × ${spread} חודשים` : ''} (החל מ-${chargeMonth}) — ${baseNote}`,
      customerId: customer.id!,
      customerName: customer.fullName,
      amount: amount * spread,
      reversible: true,
      reverseData: JSON.stringify({ debtIds: createdIds }),
      createdAt: new Date().toISOString(),
    });
    toast.success(`חיוב ₪${amount.toLocaleString()}${spread > 1 ? ` ל-${spread} חודשים` : ''} נוסף בהצלחה`);
    setAddChargeDialog(false);
    setChargeAmount(0);
    setChargeAmperes(0);
    setChargeNotes('');
    setChargeSpreadMonths(1);
    loadData();
  };

  const handleMarkPaid = async (debt: DebtRecord) => {
    const prev = { paidAmount: debt.paidAmount, status: debt.status, paidDate: debt.paidDate, notes: debt.notes };
    await updateDebt({
      ...debt,
      paidAmount: debt.amount,
      status: 'paid',
      paidDate: new Date().toISOString().split('T')[0],
      notes: debt.notes ? `${debt.notes} | סומן ידנית כנגבה` : 'סומן ידנית כנגבה',
    });
    await addActivity({
      type: 'payment',
      description: `סומן ידנית כנגבה: ₪${debt.amount.toLocaleString()} עבור ${displayName} (${debt.month})`,
      customerId: customer.id!,
      customerName: customer.fullName,
      amount: debt.amount,
      reversible: true,
      reverseData: JSON.stringify({ debtId: debt.id, prev }),
      createdAt: new Date().toISOString(),
    });
    toast.success('החיוב סומן כנגבה');
    loadData();
  };

  const handleMarkUnpaid = async (debt: DebtRecord) => {
    const prev = { paidAmount: debt.paidAmount, status: debt.status, paidDate: debt.paidDate, notes: debt.notes };
    await updateDebt({
      ...debt,
      paidAmount: 0,
      status: 'unpaid',
      paidDate: '',
      notes: debt.notes ? `${debt.notes} | בוטלה גביה (חזרה)` : 'בוטלה גביה',
    });
    await addActivity({
      type: 'other',
      description: `בוטלה גביה (חזרת אשראי): ₪${debt.amount.toLocaleString()} עבור ${displayName} (${debt.month})`,
      customerId: customer.id!,
      customerName: customer.fullName,
      amount: debt.amount,
      reversible: true,
      reverseData: JSON.stringify({ debtId: debt.id, prev }),
      createdAt: new Date().toISOString(),
    });
    toast.success('הגביה בוטלה — החיוב מסומן כלא נגבה');
    loadData();
  };

  const openSplitDialog = (d: DebtRecord) => {
    setSplitTarget(d);
    setSplitMonths(2);
    setSplitMode('auto');
    setSplitAmounts([]);
  };

  const handleSplit = async () => {
    if (!splitTarget) return;
    const total = splitTarget.amount - splitTarget.paidAmount;
    if (total <= 0) { toast.error('אין יתרה לפריסה'); return; }
    const n = Math.max(2, Math.min(24, splitMonths));
    let installments: number[] = [];
    if (splitMode === 'auto') {
      const base = Math.floor(total / n);
      installments = Array(n).fill(base);
      installments[0] += total - base * n;
    } else {
      installments = splitAmounts.slice(0, n).map(x => Math.max(0, Math.round(x)));
      const sum = installments.reduce((s, x) => s + x, 0);
      if (sum !== total) { toast.error(`סך התשלומים (₪${sum}) חייב להיות שווה ל-₪${total}`); return; }
    }
    const [y, mo] = splitTarget.month.split('-').map(Number);
    const createdIds: number[] = [];
    // delete original
    await deleteDebt(splitTarget.id!);
    for (let i = 0; i < n; i++) {
      const d = new Date(y, mo - 1 + i);
      const m = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const id = await addDebt({
        customerId: splitTarget.customerId,
        customerName: splitTarget.customerName,
        month: m,
        amount: installments[i],
        paidAmount: 0,
        status: 'unpaid',
        paidDate: '',
        notes: `פריסה (${i + 1}/${n}) — ${splitTarget.notes || 'חוב'}`,
        createdAt: new Date().toISOString(),
      });
      createdIds.push(id);
    }
    await addActivity({
      type: 'other',
      description: `פריסת חוב ₪${total.toLocaleString()} ל-${n} תשלומים עבור ${displayName} (${splitTarget.month})`,
      customerId: customer.id!,
      customerName: customer.fullName,
      amount: total,
      reversible: true,
      reverseData: JSON.stringify({ debtIds: createdIds, restored: splitTarget }),
      createdAt: new Date().toISOString(),
    });
    toast.success(`החוב נפרס ל-${n} תשלומים`);
    setSplitTarget(null);
    loadData();
  };

  const handleSuspend = async (debt: DebtRecord) => {
    await updateDebt({ ...debt, status: 'suspended' });
    await addActivity({
      type: 'other',
      description: `חיוב ₪${debt.amount.toLocaleString()} הוסתר (מושהה) עבור ${displayName} (${debt.month})`,
      customerId: customer.id!,
      customerName: customer.fullName,
      amount: debt.amount,
      createdAt: new Date().toISOString(),
    });
    toast.success('החיוב הוסתר');
    loadData();
  };

  const handleUnsuspend = async (debt: DebtRecord) => {
    await updateDebt({ ...debt, status: 'unpaid' });
    await addActivity({
      type: 'other',
      description: `חיוב ₪${debt.amount.toLocaleString()} הוחזר לפעיל עבור ${displayName} (${debt.month})`,
      customerId: customer.id!,
      customerName: customer.fullName,
      amount: debt.amount,
      createdAt: new Date().toISOString(),
    });
    toast.success('החיוב הוחזר');
    loadData();
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    const snapshot = { ...deleteTarget };
    await deleteDebt(deleteTarget.id!);
    await addActivity({
      type: 'debt_deleted',
      description: `חיוב ₪${deleteTarget.amount.toLocaleString()} נמחק עבור ${displayName} (${deleteTarget.month})`,
      customerId: customer.id!,
      customerName: customer.fullName,
      amount: deleteTarget.amount,
      reversible: true,
      reverseData: JSON.stringify({ restoreDebt: snapshot }),
      createdAt: new Date().toISOString(),
    });
    toast.success('החיוב נמחק');
    setDeleteTarget(null);
    loadData();
  };

  const handleEdit = async () => {
    if (!editDialog) return;
    if (editAmount <= 0) { toast.error('סכום חייב להיות גדול מ-0'); return; }
    const oldAmount = editDialog.amount;
    await updateDebt({ ...editDialog, amount: editAmount, notes: editNotes });
    await addActivity({
      type: 'other',
      description: `חיוב עודכן עבור ${displayName} (${editDialog.month}): ₪${oldAmount.toLocaleString()} → ₪${editAmount.toLocaleString()}`,
      customerId: customer.id!,
      customerName: customer.fullName,
      amount: editAmount,
      createdAt: new Date().toISOString(),
    });
    toast.success('החיוב עודכן');
    setEditDialog(null);
    loadData();
  };

  const handleExportCustomerPDF = async () => {
    try {
      const { exportTableToPDF } = await import('@/lib/pdfExport');
      await exportTableToPDF({
        title: `דוח לקוח: ${customer.fullName}${customer.nickname ? ` (${customer.nickname})` : ''}`,
        subtitle: `אמפרים: ${customer.amperes || 0} • סכום חודשי: ₪${monthlyAmount.toLocaleString()} • חוב פתוח: ₪${openDebtTotal.toLocaleString()}`,
        headers: ['חודש', 'חיובים', 'סה"כ', 'שולם', 'ממתין', 'יתרה', 'סטטוס'],
        rows: monthlyBreakdown.map(m => [
          m.month,
          m.debts.length.toString(),
          `₪${m.total.toLocaleString()}`,
          `₪${m.paid.toLocaleString()}`,
          m.pending > 0 ? `₪${m.pending.toLocaleString()}` : '—',
          `₪${m.balance.toLocaleString()}`,
          m.debts.filter(d => d.status !== 'suspended').every(d => d.status === 'paid') ? 'שולם' :
          m.pending > 0 ? 'ממתין' : m.balance > 0 ? 'חוב' : 'לא שולם',
        ]),
        totalsRow: ['סה"כ', debts.length.toString(), `₪${totalEverCharged.toLocaleString()}`, `₪${totalEverPaid.toLocaleString()}`, '', `₪${(totalEverCharged - totalEverPaid).toLocaleString()}`, ''],
        filename: `customer_${customer.id}_report.pdf`,
      });
      toast.success('PDF יוצא בהצלחה');
    } catch (e) {
      console.error('PDF export error:', e);
      toast.error('שגיאה בייצוא PDF');
    }
  };

  const handleExportCustomerExcel = async () => {
    try {
      const XLSX = await import('xlsx');
      const wsData = [
        [`דוח לקוח: ${customer.fullName}`],
        [],
        ['חודש', 'מספר חיובים', 'סה"כ', 'שולם', 'ממתין', 'יתרה', 'סטטוס'],
        ...monthlyBreakdown.map(m => [
          m.month, m.debts.length, m.total, m.paid, m.pending,  m.balance,
          m.debts.every(d => d.status === 'paid') ? 'שולם' : m.pending > 0 ? 'ממתין' : m.balance > 0 ? 'חוב' : 'לא שולם',
        ]),
        [],
        ['סה"כ', debts.length, totalEverCharged, totalEverPaid, '', totalEverCharged - totalEverPaid, ''],
      ];
      const ws = XLSX.utils.aoa_to_sheet(wsData);
      ws['!cols'] = [{ wch: 12 }, { wch: 10 }, { wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 10 }];
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'דוח');
      XLSX.writeFile(wb, `customer_${customer.id}_report.xlsx`);
      toast.success('הקובץ יוצא בהצלחה');
    } catch (e) {
      toast.error('שגיאה בייצוא הקובץ');
    }
  };

  const paymentMethodLabel = {
    bank: { label: 'הוראת קבע (בנק)', icon: Building2, color: 'text-primary' },
    cash: { label: 'מזומן', icon: Banknote, color: 'text-success' },
    mixed: { label: 'משולב', icon: Shuffle, color: 'text-warning' },
  }[customer.paymentMethod || 'bank'];

  const statusLabel = {
    active: { label: 'פעיל', color: 'bg-success/15 text-success border-success/30' },
    paused: { label: 'מושהה', color: 'bg-warning/15 text-warning border-warning/30' },
    cancelled: { label: 'מבוטל', color: 'bg-destructive/15 text-destructive border-destructive/30' },
  }[customer.status];

  const getDebtStatusBadge = (status: string) => {
    switch (status) {
      case 'paid': return <Badge className="bg-success/15 text-success border-success/30 text-xs">שולם</Badge>;
      case 'partial': return <Badge variant="outline" className="text-warning border-warning/30 text-xs">חלקי</Badge>;
      case 'advance': return <Badge className="bg-primary/15 text-primary border-primary/30 text-xs">מראש</Badge>;
      case 'suspended': return <Badge variant="outline" className="text-muted-foreground border-muted-foreground/30 text-xs">מושהה</Badge>;
      case 'pending_collection': return <Badge className="bg-warning/15 text-warning border-warning/30 text-xs">ממתין לגביה</Badge>;
      default: return <Badge variant="destructive" className="text-xs">לא שולם</Badge>;
    }
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'payment': return <Banknote className="h-3.5 w-3.5 text-success" />;
      case 'batch': return <CreditCard className="h-3.5 w-3.5 text-primary" />;
      case 'batch_collected': return <CheckCircle2 className="h-3.5 w-3.5 text-success" />;
      case 'extra_charge': return <Zap className="h-3.5 w-3.5 text-warning" />;
      case 'advance': return <TrendingUp className="h-3.5 w-3.5 text-primary" />;
      case 'cash_override': return <Banknote className="h-3.5 w-3.5 text-success" />;
      case 'debt_deleted': return <AlertCircle className="h-3.5 w-3.5 text-destructive" />;
      default: return <Clock className="h-3.5 w-3.5 text-muted-foreground" />;
    }
  };

  const renderChargeActions = (d: DebtRecord) => {
    return (
      <div className="flex items-center gap-1">
        {d.status === 'paid' ? (
          <Button variant="ghost" size="icon" className="h-7 w-7" title="בטל גביה (סמן כלא נגבה)" onClick={() => handleMarkUnpaid(d)}>
            <Undo2 className="h-3.5 w-3.5 text-warning" />
          </Button>
        ) : (
          <>
            <Button variant="ghost" size="icon" className="h-7 w-7" title="סמן כנגבה" onClick={() => handleMarkPaid(d)}>
              <CheckCircle2 className="h-3.5 w-3.5 text-success" />
            </Button>
            {d.status === 'suspended' ? (
              <Button variant="ghost" size="icon" className="h-7 w-7" title="החזר חיוב" onClick={() => handleUnsuspend(d)}>
                <Eye className="h-3.5 w-3.5 text-success" />
              </Button>
            ) : d.status !== 'pending_collection' ? (
              <Button variant="ghost" size="icon" className="h-7 w-7" title="הסתר חיוב" onClick={() => handleSuspend(d)}>
                <EyeOff className="h-3.5 w-3.5 text-muted-foreground" />
              </Button>
            ) : null}
            <Button variant="ghost" size="icon" className="h-7 w-7" title="פרוס לתשלומים" onClick={() => openSplitDialog(d)}>
              <CalendarClock className="h-3.5 w-3.5 text-primary" />
            </Button>
          </>
        )}
        <Button variant="ghost" size="icon" className="h-7 w-7" title="ערוך" onClick={() => { setEditDialog(d); setEditAmount(d.amount); setEditNotes(d.notes); }}>
          <Pencil className="h-3.5 w-3.5 text-muted-foreground" />
        </Button>
        <Button variant="ghost" size="icon" className="h-7 w-7" title="מחק" onClick={() => setDeleteTarget(d)}>
          <Trash2 className="h-3.5 w-3.5 text-destructive" />
        </Button>
      </div>
    );
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={onBack} className="gap-1">
            <ArrowRight className="h-4 w-4" />
            חזור
          </Button>
          <Separator orientation="vertical" className="h-6" />
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <User className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h2 className="text-xl font-bold">{displayName}</h2>
              {customer.nickname && <p className="text-sm text-muted-foreground" dir="ltr">{customer.fullName}</p>}
            </div>
            <Badge className={statusLabel.color}>{statusLabel.label}</Badge>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={() => setAddChargeDialog(true)} className="gap-2">
            <Plus className="h-4 w-4" />
            הוסף חיוב
          </Button>
          <Button variant="outline" size="sm" onClick={handleExportCustomerPDF} className="gap-1">
            <FileText className="h-3.5 w-3.5" />
            PDF
          </Button>
          <Button variant="outline" size="sm" onClick={handleExportCustomerExcel} className="gap-1">
            <FileSpreadsheet className="h-3.5 w-3.5" />
            ייצוא נתונים
          </Button>
        </div>
      </div>

      {/* Quick Info Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <Card className="glass-card">
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">אמפרים</p>
            <p className="text-xl font-bold mt-1">{customer.amperes || 0}</p>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">סכום חודשי</p>
            <p className="text-xl font-bold text-success mt-1">₪{monthlyAmount.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">חיוב החודש</p>
            <p className={`text-xl font-bold mt-1 ${currentMonthBalance > 0 ? 'text-destructive' : currentMonthTotal > 0 ? 'text-success' : ''}`}>
              {currentMonthTotal > 0 ? `₪${currentMonthTotal.toLocaleString()}` : `₪${monthlyAmount.toLocaleString()}`}
            </p>
            {currentMonthPending > 0 && (
              <p className="text-xs text-warning mt-0.5">ממתין: ₪{currentMonthPending.toLocaleString()}</p>
            )}
            {currentMonthBalance <= 0 && currentMonthPaid > 0 && (
              <p className="text-xs text-success mt-0.5">שולם ✓</p>
            )}
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">חוב פתוח</p>
            <p className={`text-xl font-bold mt-1 ${openDebtTotal > 0 ? 'text-destructive' : 'text-success'}`}>
              ₪{openDebtTotal.toLocaleString()}
            </p>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">סה"כ שולם</p>
            <p className="text-xl font-bold text-success mt-1">₪{totalEverPaid.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">מושהים</p>
            <p className="text-xl font-bold text-muted-foreground mt-1">{suspendedCount}</p>
          </CardContent>
        </Card>
      </div>

      {/* Recurring monthly charges */}
      <Card className="glass-card">
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <CalendarClock className="h-4 w-4 text-primary" />
              חיובים חודשיים קבועים
            </CardTitle>
            <p className="text-xs text-muted-foreground mt-0.5">
              חיובים קבועים הנגבים מדי חודש (כולל חיוב בסיס, אמפרים ותגיות נוספות)
            </p>
          </div>
          <Button size="sm" variant="outline" className="gap-1.5" onClick={handleOpenAddRecurring}>
            <Plus className="h-3.5 w-3.5" />
            הוסף חיוב קבוע
          </Button>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div className="flex flex-wrap items-center gap-4 bg-muted/30 p-2.5 rounded-lg border border-border/40 text-xs">
            {totalAmperes > 0 && (
              <div>
                <span className="text-muted-foreground">סה"כ אמפרים: </span>
                <span className="font-bold text-foreground font-mono">{totalAmperes}A</span>
              </div>
            )}
            <div>
              <span className="text-muted-foreground">תעריף לאמפר: </span>
              <span className="font-semibold text-foreground">₪{pricePerAmpere.toLocaleString()}</span>
            </div>
            <div className="mr-auto">
              <span className="text-muted-foreground">סה"כ חיוב קבוע לחודש: </span>
              <span className="text-sm font-bold text-primary font-mono">₪{monthlyAmount.toLocaleString()}</span>
            </div>
          </div>

          {recList.length === 0 ? (
            <div className="text-center py-6 border border-dashed rounded-lg">
              <p className="text-xs text-muted-foreground">אין חיובים חודשיים קבועים ללקוח זה.</p>
              <Button size="sm" variant="outline" className="mt-2 text-xs gap-1" onClick={handleOpenAddRecurring}>
                <Plus className="h-3.5 w-3.5" />
                הגדר חיוב חודשי קבוע ראשון
              </Button>
            </div>
          ) : (
            <div className="space-y-2">
              {recList.map(rc => {
                const tag = availableTags.find(t => t.id === rc.tagId);
                const tagColor = getTagColorClasses(tag?.color);
                return (
                  <div key={rc.id} className="flex items-center justify-between rounded-lg border border-border/60 bg-card/60 px-3.5 py-2.5 transition-all hover:border-border">
                    <div className="flex items-center gap-3">
                      <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium border ${tagColor.bg} ${tagColor.text} ${tagColor.border}`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${tagColor.dot}`} />
                        {tag?.name || rc.label || 'חיוב קבוע'}
                      </span>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-medium text-sm">{rc.label}</p>
                          <Badge variant="outline" className="text-[10px] py-0 px-1.5 font-normal">
                            {rc.type === 'amperes' ? 'אמפרים' : 'סכום קבוע'}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5 font-mono">
                          {rc.type === 'amperes'
                            ? `${rc.amperes}A × ₪${pricePerAmpere.toLocaleString()} = ₪${((rc.amperes || 0) * pricePerAmpere).toLocaleString()} לחודש`
                            : `₪${(rc.amount || 0).toLocaleString()} לחודש`}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-muted-foreground hover:text-foreground" title="ערוך חיוב" onClick={() => handleOpenEditRecurring(rc)}>
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-destructive/70 hover:text-destructive hover:bg-destructive/10" title="מחק חיוב" onClick={() => handleDeleteRecurring(rc.id)}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add / Edit Recurring Charge Dialog */}
      <Dialog open={recDialog} onOpenChange={setRecDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingCharge ? 'עריכת חיוב חודשי קבוע' : 'הוספת חיוב חודשי קבוע'}
            </DialogTitle>
            <DialogDescription>
              בחר תגית והגדר את החיוב שייגבה מדי חודש מהלקוח.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 pt-1">
            {/* Tag Selection */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label className="text-xs font-semibold">תגית חיוב</Label>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="h-6 text-[11px] text-primary p-0 hover:bg-transparent"
                  onClick={() => setNewTagDialogOpen(true)}
                >
                  + תגית חדשה
                </Button>
              </div>
              <Select value={recTagId} onValueChange={handleSelectTag}>
                <SelectTrigger>
                  <SelectValue placeholder="בחר תגית..." />
                </SelectTrigger>
                <SelectContent>
                  {availableTags.map(tag => {
                    const color = getTagColorClasses(tag.color);
                    return (
                      <SelectItem key={tag.id} value={tag.id}>
                        <div className="flex items-center gap-2">
                          <span className={`w-2 h-2 rounded-full ${color.dot}`} />
                          <span>{tag.name}</span>
                          <span className="text-[10px] text-muted-foreground mr-1">
                            ({tag.typeMode === 'amperes' ? 'אמפרים' : tag.typeMode === 'money' ? 'סכום' : 'גמיש'})
                          </span>
                        </div>
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>

            {/* Type selector if flexible */}
            {(() => {
              const currentTag = availableTags.find(t => t.id === recTagId);
              const isFlexible = !currentTag || currentTag.typeMode === 'flexible';
              if (isFlexible) {
                return (
                  <div className="space-y-1.5">
                    <Label className="text-xs font-semibold">אופן חיוב</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        type="button"
                        variant={recType === 'amperes' ? 'default' : 'outline'}
                        size="sm"
                        className="text-xs"
                        onClick={() => setRecType('amperes')}
                      >
                        לפי כמות אמפרים (A)
                      </Button>
                      <Button
                        type="button"
                        variant={recType === 'money' ? 'default' : 'outline'}
                        size="sm"
                        className="text-xs"
                        onClick={() => setRecType('money')}
                      >
                        סכום קבוע (₪)
                      </Button>
                    </div>
                  </div>
                );
              }
              return (
                <div className="text-xs text-muted-foreground bg-muted/40 p-2 rounded border border-border/40">
                  {currentTag.typeMode === 'amperes' ? 'תגית זו מוגדרת לחיוב באמפרים בלבד' : 'תגית זו מוגדרת לחיוב בסכום כספי בלבד'}
                </div>
              );
            })()}

            {/* Amount / Amperes input */}
            {recType === 'money' ? (
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold">סכום חודשי קבוע (₪)</Label>
                <div className="relative">
                  <Input
                    type="number"
                    min="0"
                    step="any"
                    value={recAmount || ''}
                    onChange={e => setRecAmount(Number(e.target.value))}
                    dir="ltr"
                    placeholder="0"
                    className="font-mono text-base"
                  />
                  <span className="absolute left-3 top-2.5 text-xs text-muted-foreground pointer-events-none">₪</span>
                </div>
              </div>
            ) : (
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold">כמות אמפרים (A)</Label>
                <div className="relative">
                  <Input
                    type="number"
                    min="0"
                    step="any"
                    value={recAmperes || ''}
                    onChange={e => setRecAmperes(Number(e.target.value))}
                    dir="ltr"
                    placeholder="0"
                    className="font-mono text-base"
                  />
                  <span className="absolute left-3 top-2.5 text-xs text-muted-foreground pointer-events-none">A</span>
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground pt-1">
                  <span>חישוב חודשי:</span>
                  <span className="font-semibold text-foreground font-mono">
                    {recAmperes || 0}A × ₪{pricePerAmpere} = ₪{((recAmperes || 0) * pricePerAmpere).toLocaleString()} לחודש
                  </span>
                </div>
              </div>
            )}

            {/* Label / Description */}
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold">תיאור החיוב</Label>
              <Input
                value={recLabel}
                onChange={e => setRecLabel(e.target.value)}
                placeholder="שם החיוב (למשל: בסיס, מזגן סלון...)"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t mt-4">
            <Button variant="outline" onClick={() => setRecDialog(false)}>
              ביטול
            </Button>
            <Button onClick={handleSaveRecurring}>
              {editingCharge ? 'שמור שינויים' : 'הוסף חיוב'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Create New Tag Sub-Dialog */}
      <Dialog open={newTagDialogOpen} onOpenChange={setNewTagDialogOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>יצירת תגית חיוב חדשה</DialogTitle>
            <DialogDescription>
              הגדר תגית חדשה לבחירה מהירה בחיובים קבועים.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3.5 py-1">
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold">שם התגית</Label>
              <Input
                value={newTagName}
                onChange={e => setNewTagName(e.target.value)}
                placeholder="למשל: מחסן, שמירה, בריכה..."
                autoFocus
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs font-semibold">סוג החיוב בתגית</Label>
              <Select
                value={newTagTypeMode}
                onValueChange={v => setNewTagTypeMode(v as RecurringTagTypeMode)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="flexible">גמיש - לפעמים סכום ולפעמים אמפרים</SelectItem>
                  <SelectItem value="amperes">אמפרים בלבד (A)</SelectItem>
                  <SelectItem value="money">סכום קבוע בלבד (₪)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs font-semibold">צבע תגית</Label>
              <div className="flex flex-wrap gap-2 pt-1">
                {TAG_COLOR_OPTIONS.map(opt => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setNewTagColor(opt.value)}
                    className={`flex items-center gap-1.5 px-2 py-1 rounded-md text-xs border transition-all ${
                      newTagColor === opt.value
                        ? 'ring-2 ring-primary border-primary font-semibold'
                        : 'border-border/60 hover:border-border'
                    } ${opt.bg} ${opt.text}`}
                  >
                    <span className={`w-2 h-2 rounded-full ${opt.dot}`} />
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t">
            <Button variant="outline" size="sm" onClick={() => setNewTagDialogOpen(false)}>
              ביטול
            </Button>
            <Button size="sm" onClick={handleCreateNewTag}>
              צור תגית
            </Button>
          </div>
        </DialogContent>
      </Dialog>


      {/* Customer Details + Current Month */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <User className="h-4 w-4 text-primary" />
              פרטי לקוח
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div className="grid grid-cols-2 gap-3">
              {customer.idNumber && (
                <div><p className="text-xs text-muted-foreground">ת.ז</p><p className="font-mono" dir="ltr">{customer.idNumber}</p></div>
              )}
              {customer.phone && (
                <div><p className="text-xs text-muted-foreground">טלפון</p><p className="font-mono" dir="ltr">{customer.phone}</p></div>
              )}
              {customer.phone2 && (
                <div><p className="text-xs text-muted-foreground">טלפון נוסף</p><p className="font-mono" dir="ltr">{customer.phone2}</p></div>
              )}
              {customer.email && (
                <div><p className="text-xs text-muted-foreground">אימייל</p><p dir="ltr">{customer.email}</p></div>
              )}
            </div>
            {(customer.city || customer.street || customer.address) && (
              <>
                <Separator />
                <div>
                  <p className="text-xs text-muted-foreground">כתובת</p>
                  <p>{[customer.city, customer.street, customer.houseNumber].filter(Boolean).join(', ') || customer.address}</p>
                </div>
              </>
            )}
            <Separator />
            <div className="flex items-center gap-2">
              <paymentMethodLabel.icon className={`h-4 w-4 ${paymentMethodLabel.color}`} />
              <span>{paymentMethodLabel.label}</span>
            </div>
            {(customer.paymentMethod === 'bank' || customer.paymentMethod === 'mixed') && customer.bankNumber && (
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <p className="text-xs text-muted-foreground">בנק</p>
                  <p className="font-mono" dir="ltr">{customer.bankNumber}</p>
                  {bankLabel && <p className="text-xs text-muted-foreground">{bankLabel}</p>}
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">סניף</p>
                  <p className="font-mono" dir="ltr">{customer.branchNumber}</p>
                  {branchLabel && <p className="text-xs text-muted-foreground">{branchLabel}</p>}
                </div>
                <div><p className="text-xs text-muted-foreground">חשבון</p><p className="font-mono" dir="ltr">{customer.accountNumber}</p></div>
              </div>
            )}
            {customer.accountHolderName && (
              <div><p className="text-xs text-muted-foreground">שם בעל חשבון</p><p>{customer.accountHolderName}</p></div>
            )}
            {customer.paymentMethod === 'mixed' && (
              <div className="grid grid-cols-2 gap-3">
                <div><p className="text-xs text-muted-foreground">סכום בנק</p><p>₪{(customer.bankAmount || 0).toLocaleString()}</p></div>
                <div><p className="text-xs text-muted-foreground">סכום מזומן</p><p>₪{(customer.cashAmount || 0).toLocaleString()}</p></div>
              </div>
            )}
            {customer.authorizationRef && (
              <>
                <Separator />
                <div className="grid grid-cols-2 gap-3">
                  <div><p className="text-xs text-muted-foreground">אסמכתא</p><p className="font-mono" dir="ltr">{customer.authorizationRef}</p></div>
                  {customer.authorizationDate && (
                    <div><p className="text-xs text-muted-foreground">תאריך אישור</p><p>{new Date(customer.authorizationDate).toLocaleDateString('he-IL')}</p></div>
                  )}
                </div>
              </>
            )}
            <Separator />
            <div className="grid grid-cols-2 gap-3">
              <div>
                <p className="text-xs text-muted-foreground">תאריך התחלה</p>
                <p>{customer.startDate ? new Date(customer.startDate).toLocaleDateString('he-IL') : '—'}</p>
              </div>
              {customer.endDate && (
                <div><p className="text-xs text-muted-foreground">תאריך סיום</p><p>{new Date(customer.endDate).toLocaleDateString('he-IL')}</p></div>
              )}
            </div>
            {customer.notes && (
              <><Separator /><div><p className="text-xs text-muted-foreground">הערות</p><p className="text-muted-foreground">{customer.notes}</p></div></>
            )}
          </CardContent>
        </Card>

        {/* Current Month Status */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-base flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-primary" />
                סטטוס חודש נוכחי ({currentMonth})
              </span>
              <Button variant="outline" size="sm" onClick={() => { setChargeMonth(currentMonth); setAddChargeDialog(true); }} className="gap-1 text-xs">
                <Plus className="h-3 w-3" />הוסף
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {currentMonthDebts.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Clock className="h-8 w-8 mx-auto mb-2 opacity-40" />
                <p>אין חיובים לחודש הנוכחי</p>
                <p className="text-xs mt-1">חיוב צפוי: ₪{monthlyAmount.toLocaleString()} ({customer.amperes} אמפר)</p>
              </div>
            ) : (
              <div className="space-y-3">
                {currentMonthDebts.map(d => (
                  <div key={d.id} className={`flex items-center justify-between p-3 rounded-lg border border-border/50 ${d.status === 'suspended' ? 'bg-muted/10 opacity-60' : d.status === 'pending_collection' ? 'bg-warning/5 border-warning/20' : d.status === 'paid' ? 'bg-success/5 border-success/20' : 'bg-muted/30'}`}>
                    <div className="flex-1">
                      <p className="text-sm font-medium">
                        ₪{d.amount.toLocaleString()}
                        {d.notes && <span className="text-xs text-muted-foreground mr-2">({d.notes?.split(' | ')[0]})</span>}
                      </p>
                      {d.paidAmount > 0 && d.paidAmount < d.amount && (
                        <p className="text-xs text-muted-foreground">שולם: ₪{d.paidAmount.toLocaleString()} • יתרה: ₪{(d.amount - d.paidAmount).toLocaleString()}</p>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      {getDebtStatusBadge(d.status)}
                      {renderChargeActions(d)}
                    </div>
                  </div>
                ))}
                <Separator />
                <div className="flex justify-between text-sm font-medium">
                  <span>סה"כ פעיל</span>
                  <span>₪{currentMonthTotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">שולם</span>
                  <span className="text-success">₪{currentMonthPaid.toLocaleString()}</span>
                </div>
                {currentMonthPending > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-warning">ממתין לגביה</span>
                    <span className="text-warning">₪{currentMonthPending.toLocaleString()}</span>
                  </div>
                )}
                {currentMonthBalance > 0 && (
                  <div className="flex justify-between text-sm font-semibold">
                    <span className="text-destructive">יתרה לתשלום</span>
                    <span className="text-destructive">₪{currentMonthBalance.toLocaleString()}</span>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Future Charges */}
      {futureMonthBreakdown.length > 0 && (
        <Card className="glass-card border-warning/30">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <CalendarClock className="h-4 w-4 text-warning" />
              חיובים עתידיים ({futureMonthDebts.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {futureMonthBreakdown.map(fm => (
                <div key={fm.month} className="rounded-lg border border-border/50 overflow-hidden">
                  <div className="flex items-center justify-between bg-warning/5 px-4 py-2">
                    <span className="font-mono text-sm font-medium" dir="ltr">{fm.month}</span>
                    <span className="text-sm font-medium">₪{fm.total.toLocaleString()}</span>
                  </div>
                  <Table>
                    <TableBody>
                      {fm.debts.map(d => (
                        <TableRow key={d.id} className={`hover:bg-muted/30 ${d.status === 'suspended' ? 'opacity-50' : ''}`}>
                          <TableCell className="text-sm">{d.notes || 'חיוב'}</TableCell>
                          <TableCell className="font-medium">₪{d.amount.toLocaleString()}</TableCell>
                          <TableCell>{getDebtStatusBadge(d.status)}</TableCell>
                          <TableCell className="text-left">{renderChargeActions(d)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Monthly Breakdown */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <TrendingDown className="h-4 w-4 text-primary" />
            היסטוריית חיובים ({debts.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {monthlyBreakdown.length === 0 ? (
            <p className="text-center py-8 text-muted-foreground">אין היסטוריה</p>
          ) : (
            <div className="space-y-4">
              {monthlyBreakdown.map(m => {
                const allPaid = m.debts.filter(d => d.status !== 'suspended').every(d => d.status === 'paid' || d.status === 'advance');
                const hasPending = m.debts.some(d => d.status === 'pending_collection');
                return (
                  <div key={m.month} className="rounded-lg border border-border overflow-hidden">
                    <div className="flex items-center justify-between bg-muted/50 px-4 py-2">
                      <div className="flex items-center gap-3">
                        <span className="font-mono text-sm font-medium" dir="ltr">{m.month}</span>
                        {allPaid && m.total > 0 ? (
                          <Badge className="bg-success/15 text-success border-success/30 text-xs gap-1"><CheckCircle2 className="h-3 w-3" />שולם</Badge>
                        ) : hasPending ? (
                          <Badge className="bg-warning/15 text-warning border-warning/30 text-xs">ממתין לגביה</Badge>
                        ) : m.balance > 0 ? (
                          <Badge variant="destructive" className="text-xs">חוב: ₪{m.balance.toLocaleString()}</Badge>
                        ) : null}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        סה"כ: ₪{m.total.toLocaleString()} | שולם: ₪{m.paid.toLocaleString()}
                        {m.pending > 0 && <span className="text-warning"> | ממתין: ₪{m.pending.toLocaleString()}</span>}
                      </div>
                    </div>
                    <Table>
                      <TableBody>
                        {m.debts.map(d => (
                          <TableRow key={d.id} className={`hover:bg-muted/30 ${d.status === 'suspended' ? 'opacity-50' : ''}`}>
                            <TableCell className="text-sm max-w-[250px]">
                              {d.notes?.split(' | ')[0] || 'חיוב רגיל'}
                            </TableCell>
                            <TableCell className="font-medium">₪{d.amount.toLocaleString()}</TableCell>
                            <TableCell className="text-success">₪{d.paidAmount.toLocaleString()}</TableCell>
                            <TableCell>{getDebtStatusBadge(d.status)}</TableCell>
                            <TableCell className="text-left">{renderChargeActions(d)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Batch History */}
      {customerBatches.length > 0 && (
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <FileText className="h-4 w-4 text-primary" />
              היסטוריית אצוות ({customerBatches.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border border-border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                     <TableHead>אצווה #</TableHead>
                     <TableHead>תאריך</TableHead>
                     <TableHead>תאריך ערך</TableHead>
                     <TableHead>חודש</TableHead>
                     <TableHead>סכום</TableHead>
                     <TableHead>סטטוס</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
              {customerBatches.map(b => {
                    const batchMonth = b.valueDate.substring(0, 7);
                    return (
                    <TableRow key={b.id} className="hover:bg-muted/30">
                      <TableCell className="font-medium">#{b.id}</TableCell>
                      <TableCell>{new Date(b.createdAt).toLocaleDateString('he-IL')}</TableCell>
                      <TableCell>{new Date(b.valueDate).toLocaleDateString('he-IL')}</TableCell>
                      <TableCell className="font-mono text-xs" dir="ltr">{batchMonth}</TableCell>
                      <TableCell className="text-success font-medium">₪{b.customerAmount.toLocaleString()}</TableCell>
                      <TableCell>
                        <Badge variant={b.status === 'collected' ? 'default' : 'secondary'} className={b.status === 'collected' ? 'bg-success text-success-foreground' : ''}>
                          {b.status === 'collected' ? '✓ נגבה' : b.status === 'pending' ? 'ממתין' : b.status === 'exported' ? 'יוצא' : 'נוצר'}
                        </Badge>
                      </TableCell>
                    </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Activity Log */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Clock className="h-4 w-4 text-primary" />
            יומן פעולות ({sortedActivities.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {sortedActivities.length === 0 ? (
            <p className="text-center py-8 text-muted-foreground">אין פעולות</p>
          ) : (
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {sortedActivities.map(a => (
                <div key={a.id} className="flex items-start gap-3 p-2.5 rounded-lg hover:bg-muted/30 transition-colors">
                  <div className="mt-0.5">{getActivityIcon(a.type)}</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm">{a.description}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {new Date(a.createdAt).toLocaleDateString('he-IL')} {new Date(a.createdAt).toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add Charge Dialog */}
      <Dialog open={addChargeDialog} onOpenChange={setAddChargeDialog}>
        <DialogContent onPointerDownOutside={e => e.preventDefault()}>
          <DialogHeader>
            <DialogTitle>הוספת חיוב — {displayName}</DialogTitle>
            <DialogDescription>הוסף חיוב נוסף ללקוח. החיוב ייכלל באצווה הבאה.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label>סוג</Label>
              <Select value={chargeType} onValueChange={(v: 'money' | 'amperes') => setChargeType(v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="money">סכום ב-₪</SelectItem>
                  <SelectItem value="amperes">אמפרים נוספים</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {chargeType === 'money' ? (
              <div className="space-y-1.5">
                <Label>סכום (₪)</Label>
                <Input type="number" value={chargeAmount || ''} onChange={e => setChargeAmount(Number(e.target.value))} dir="ltr" placeholder="0" />
              </div>
            ) : (
              <div className="space-y-1.5">
                <Label>אמפרים</Label>
                <Input type="number" value={chargeAmperes || ''} onChange={e => setChargeAmperes(Number(e.target.value))} dir="ltr" placeholder="0" />
                {chargeAmperes > 0 && pricePerAmpere > 0 && (
                  <p className="text-xs text-muted-foreground">= ₪{(chargeAmperes * pricePerAmpere).toLocaleString()}</p>
                )}
              </div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>חודש</Label>
                <input type="month" value={chargeMonth} onChange={e => setChargeMonth(e.target.value)}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm" dir="ltr" />
              </div>
              <div className="space-y-1.5">
                <Label>פריסה לחודשים</Label>
                <Input type="number" min={1} max={24} value={chargeSpreadMonths} onChange={e => setChargeSpreadMonths(Math.max(1, Math.min(24, Number(e.target.value) || 1)))} dir="ltr" />
                {chargeSpreadMonths > 1 && (
                  <p className="text-xs text-muted-foreground">חיוב חודשי × {chargeSpreadMonths} חודשים</p>
                )}
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>הערות</Label>
              <Textarea value={chargeNotes} onChange={e => setChargeNotes(e.target.value)} rows={2} />
            </div>
          </div>
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setAddChargeDialog(false)}>ביטול</Button>
            <Button onClick={handleAddCharge}>הוסף חיוב</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={!!editDialog} onOpenChange={() => setEditDialog(null)}>
        <DialogContent onPointerDownOutside={e => e.preventDefault()}>
          <DialogHeader>
            <DialogTitle>עריכת חיוב</DialogTitle>
            <DialogDescription>{editDialog?.month}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label>סכום (₪)</Label>
              <Input type="number" value={editAmount || ''} onChange={e => setEditAmount(Number(e.target.value))} dir="ltr" />
            </div>
            <div className="space-y-1.5">
              <Label>הערות</Label>
              <Textarea value={editNotes} onChange={e => setEditNotes(e.target.value)} rows={2} />
            </div>
          </div>
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setEditDialog(null)}>ביטול</Button>
            <Button onClick={handleEdit}>שמור</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete */}
      <AlertDialog open={!!deleteTarget} onOpenChange={() => setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>מחיקת חיוב</AlertDialogTitle>
            <AlertDialogDescription>
              האם למחוק: ₪{deleteTarget?.amount.toLocaleString()} ({deleteTarget?.month})?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>ביטול</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">מחק</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Split Debt Dialog */}
      <Dialog open={!!splitTarget} onOpenChange={() => setSplitTarget(null)}>
        <DialogContent onPointerDownOutside={e => e.preventDefault()}>
          <DialogHeader>
            <DialogTitle>פריסת חוב לתשלומים</DialogTitle>
            <DialogDescription>
              חוב: ₪{splitTarget ? (splitTarget.amount - splitTarget.paidAmount).toLocaleString() : 0} • חודש מקורי: {splitTarget?.month}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-2">
              <button type="button" onClick={() => setSplitMode('auto')}
                className={`p-2 rounded-lg border-2 text-sm font-medium ${splitMode === 'auto' ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'}`}>
                חלוקה אוטומטית
              </button>
              <button type="button" onClick={() => {
                setSplitMode('manual');
                if (splitTarget) {
                  const total = splitTarget.amount - splitTarget.paidAmount;
                  const base = Math.floor(total / splitMonths);
                  const arr = Array(splitMonths).fill(base);
                  arr[0] += total - base * splitMonths;
                  setSplitAmounts(arr);
                }
              }}
                className={`p-2 rounded-lg border-2 text-sm font-medium ${splitMode === 'manual' ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'}`}>
                חלוקה ידנית
              </button>
            </div>
            <div className="space-y-1.5">
              <Label>מספר תשלומים</Label>
              <Input type="number" min={2} max={24} value={splitMonths}
                onChange={e => {
                  const n = Math.max(2, Math.min(24, Number(e.target.value) || 2));
                  setSplitMonths(n);
                  if (splitMode === 'manual' && splitTarget) {
                    const total = splitTarget.amount - splitTarget.paidAmount;
                    const base = Math.floor(total / n);
                    const arr = Array(n).fill(base);
                    arr[0] += total - base * n;
                    setSplitAmounts(arr);
                  }
                }} dir="ltr" />
            </div>
            {splitMode === 'manual' && splitAmounts.length > 0 && (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {splitAmounts.map((amt, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground w-20">תשלום {i + 1}</span>
                    <Input type="number" value={amt || ''} onChange={e => {
                      const arr = [...splitAmounts];
                      arr[i] = Number(e.target.value) || 0;
                      setSplitAmounts(arr);
                    }} dir="ltr" />
                  </div>
                ))}
                <p className="text-xs text-muted-foreground">
                  סך כל התשלומים: ₪{splitAmounts.reduce((s, x) => s + x, 0).toLocaleString()} / נדרש: ₪{splitTarget ? (splitTarget.amount - splitTarget.paidAmount).toLocaleString() : 0}
                </p>
              </div>
            )}
            {splitMode === 'auto' && splitTarget && (
              <p className="text-sm text-muted-foreground">
                {splitMonths} תשלומים של ~₪{Math.floor((splitTarget.amount - splitTarget.paidAmount) / splitMonths).toLocaleString()} כל אחד
              </p>
            )}
          </div>
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setSplitTarget(null)}>ביטול</Button>
            <Button onClick={handleSplit}>פרוס</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
