import { useState, useEffect, useMemo } from 'react';
import { Plus, Trash2, Edit, Users, ChevronDown, Layers } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { getAllGroups, addGroup, updateGroup, deleteGroup, getAllCustomers, getAllPhases, addPhase, updatePhase, deletePhase } from '@/lib/db';
import type { Group, Customer, Phase } from '@/lib/types';
import { toast } from 'sonner';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16'];

export default function GroupsView() {
  const [view, setView] = useState<'groups' | 'phases'>('groups');
  const [groups, setGroups] = useState<Group[]>([]);
  const [phases, setPhases] = useState<Phase[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editGroup, setEditGroup] = useState<Group | null>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [color, setColor] = useState(COLORS[0]);
  const [expanded, setExpanded] = useState<number | null>(null);

  // Phase dialog
  const [phaseDialogOpen, setPhaseDialogOpen] = useState(false);
  const [editPhase, setEditPhase] = useState<Phase | null>(null);
  const [phaseName, setPhaseName] = useState('');
  const [phaseDesc, setPhaseDesc] = useState('');
  const [deletePhaseId, setDeletePhaseId] = useState<number | null>(null);

  const loadData = () => {
    Promise.all([getAllGroups(), getAllCustomers(), getAllPhases()]).then(([g, c, p]) => { setGroups(g); setCustomers(c); setPhases(p); });
  };


  useEffect(() => { loadData(); }, []);

  const customersByGroup = useMemo(() => {
    const map: Record<number, Customer[]> = {};
    for (const c of customers) {
      if (c.groupId) {
        if (!map[c.groupId]) map[c.groupId] = [];
        map[c.groupId].push(c);
      }
    }
    return map;
  }, [customers]);

  const customersByPhase = useMemo(() => {
    const map: Record<number, Customer[]> = {};
    for (const c of customers) {
      if (c.phaseId) {
        if (!map[c.phaseId]) map[c.phaseId] = [];
        map[c.phaseId].push(c);
      }
    }
    return map;
  }, [customers]);

  const openPhaseDialog = (p?: Phase) => {
    if (p) { setEditPhase(p); setPhaseName(p.name); setPhaseDesc(p.description || ''); }
    else { setEditPhase(null); setPhaseName(''); setPhaseDesc(''); }
    setPhaseDialogOpen(true);
  };

  const handleSavePhase = async () => {
    if (!phaseName.trim()) { toast.error('שם הפזה חובה'); return; }
    if (editPhase) {
      await updatePhase({ ...editPhase, name: phaseName, description: phaseDesc });
      toast.success('הפזה עודכנה');
    } else {
      await addPhase({ name: phaseName, description: phaseDesc, createdAt: new Date().toISOString() });
      toast.success('פזה נוספה');
    }
    setPhaseDialogOpen(false);
    loadData();
  };

  const handleDeletePhase = async () => {
    if (deletePhaseId === null) return;
    await deletePhase(deletePhaseId);
    toast.success('הפזה נמחקה');
    setDeletePhaseId(null);
    loadData();
  };



  const openDialog = (g?: Group) => {
    if (g) {
      setEditGroup(g);
      setName(g.name);
      setDescription(g.description);
      setColor(g.color);
    } else {
      setEditGroup(null);
      setName('');
      setDescription('');
      setColor(COLORS[Math.floor(Math.random() * COLORS.length)]);
    }
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!name.trim()) { toast.error('שם הקבוצה חובה'); return; }
    if (editGroup) {
      await updateGroup({ ...editGroup, name, description, color });
      toast.success('הקבוצה עודכנה');
    } else {
      await addGroup({ name, description, color, createdAt: new Date().toISOString() });
      toast.success('קבוצה נוספה');
    }
    setDialogOpen(false);
    loadData();
  };

  const handleDelete = async () => {
    if (deleteId === null) return;
    await deleteGroup(deleteId);
    toast.success('הקבוצה נמחקה');
    setDeleteId(null);
    loadData();
  };

  const groupIncome = (gid: number) => {
    return (customersByGroup[gid] || [])
      .filter(c => c.status === 'active')
      .reduce((s, c) => s + c.monthlyAmount, 0);
  };

  return (
    <div className="space-y-4 animate-fade-in">
      <Tabs value={view} onValueChange={(v) => setView(v as 'groups' | 'phases')}>
        <div className="flex items-center justify-between flex-wrap gap-3">
          <TabsList>
            <TabsTrigger value="groups" className="gap-1"><Users className="h-4 w-4" />קבוצות</TabsTrigger>
            <TabsTrigger value="phases" className="gap-1"><Layers className="h-4 w-4" />פזות</TabsTrigger>
          </TabsList>
          {view === 'groups' ? (
            <Button onClick={() => openDialog()}><Plus className="h-4 w-4 ml-1" />קבוצה חדשה</Button>
          ) : (
            <Button onClick={() => openPhaseDialog()}><Plus className="h-4 w-4 ml-1" />פזה חדשה</Button>
          )}
        </div>

        <TabsContent value="groups" className="mt-4">
          {groups.length === 0 ? (
            <Card className="glass-card">
              <CardContent className="py-12 text-center text-muted-foreground">
                <Users className="h-12 w-12 mx-auto mb-4 opacity-40" />
                <p>אין קבוצות עדיין. צור קבוצה חדשה כדי לארגן לקוחות.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {groups.map(g => {
                const members = customersByGroup[g.id!] || [];
                return (
                  <Collapsible key={g.id} open={expanded === g.id} onOpenChange={() => setExpanded(expanded === g.id ? null : g.id!)}>
                    <Card className="glass-card">
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between">
                          <CollapsibleTrigger className="flex items-center gap-3 hover:opacity-80 transition-opacity">
                            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: g.color }} />
                            <CardTitle className="text-base">{g.name}</CardTitle>
                            <Badge variant="outline">{members.length} לקוחות</Badge>
                            <ChevronDown className={`h-4 w-4 transition-transform ${expanded === g.id ? 'rotate-180' : ''}`} />
                          </CollapsibleTrigger>
                          <div className="flex items-center gap-4">
                            <span className="text-sm text-success font-medium">₪{groupIncome(g.id!).toLocaleString()}/חודש</span>
                            <div className="flex gap-1">
                              <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => openDialog(g)}><Edit className="h-3.5 w-3.5" /></Button>
                              <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" onClick={() => setDeleteId(g.id!)}><Trash2 className="h-3.5 w-3.5" /></Button>
                            </div>
                          </div>
                        </div>
                        {g.description && <p className="text-sm text-muted-foreground mt-1">{g.description}</p>}
                      </CardHeader>
                      <CollapsibleContent>
                        <CardContent className="pt-2">
                          {members.length === 0 ? (
                            <p className="text-sm text-muted-foreground">אין לקוחות בקבוצה</p>
                          ) : (
                            <div className="space-y-1">
                              {members.map(m => (
                                <div key={m.id} className="flex items-center justify-between py-1.5 text-sm border-b border-border/30 last:border-0">
                                  <span>{m.fullName}</span>
                                  <div className="flex items-center gap-3">
                                    <span className="text-muted-foreground">{m.phone}</span>
                                    <span className="text-success">₪{m.monthlyAmount.toLocaleString()}</span>
                                    <Badge variant={m.status === 'active' ? 'default' : 'secondary'} className="text-xs">
                                      {m.status === 'active' ? 'פעיל' : m.status === 'paused' ? 'מושהה' : 'מבוטל'}
                                    </Badge>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </CardContent>
                      </CollapsibleContent>
                    </Card>
                  </Collapsible>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="phases" className="mt-4">
          {phases.length === 0 ? (
            <Card className="glass-card">
              <CardContent className="py-12 text-center text-muted-foreground">
                <Layers className="h-12 w-12 mx-auto mb-4 opacity-40" />
                <p>אין פזות עדיין. צור פזה חדשה כדי לחלק לקוחות לפי אזורים/פזות.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {phases.map(p => {
                const members = customersByPhase[p.id!] || [];
                const income = members.filter(c => c.status === 'active').reduce((s, c) => s + c.monthlyAmount, 0);
                return (
                  <Collapsible key={p.id} open={expanded === -(p.id!)} onOpenChange={() => setExpanded(expanded === -(p.id!) ? null : -(p.id!))}>
                    <Card className="glass-card">
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between">
                          <CollapsibleTrigger className="flex items-center gap-3 hover:opacity-80 transition-opacity">
                            <Layers className="h-4 w-4 text-primary" />
                            <CardTitle className="text-base">{p.name}</CardTitle>
                            <Badge variant="outline">{members.length} לקוחות</Badge>
                            <ChevronDown className={`h-4 w-4 transition-transform ${expanded === -(p.id!) ? 'rotate-180' : ''}`} />
                          </CollapsibleTrigger>
                          <div className="flex items-center gap-4">
                            <span className="text-sm text-success font-medium">₪{income.toLocaleString()}/חודש</span>
                            <div className="flex gap-1">
                              <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => openPhaseDialog(p)}><Edit className="h-3.5 w-3.5" /></Button>
                              <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" onClick={() => setDeletePhaseId(p.id!)}><Trash2 className="h-3.5 w-3.5" /></Button>
                            </div>
                          </div>
                        </div>
                        {p.description && <p className="text-sm text-muted-foreground mt-1">{p.description}</p>}
                      </CardHeader>
                      <CollapsibleContent>
                        <CardContent className="pt-2">
                          {members.length === 0 ? (
                            <p className="text-sm text-muted-foreground">אין לקוחות בפזה</p>
                          ) : (
                            <div className="space-y-1">
                              {[...members].sort((a, b) => (a.nickname || a.fullName).localeCompare(b.nickname || b.fullName, 'he')).map(m => (
                                <div key={m.id} className="flex items-center justify-between py-1.5 text-sm border-b border-border/30 last:border-0">
                                  <span>{m.nickname || m.fullName}</span>
                                  <div className="flex items-center gap-3">
                                    <span className="text-muted-foreground">{m.phone}</span>
                                    <span className="text-success">₪{m.monthlyAmount.toLocaleString()}</span>
                                    <Badge variant={m.status === 'active' ? 'default' : 'secondary'} className="text-xs">
                                      {m.status === 'active' ? 'פעיל' : m.status === 'paused' ? 'מושהה' : 'מבוטל'}
                                    </Badge>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </CardContent>
                      </CollapsibleContent>
                    </Card>
                  </Collapsible>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Phase Dialog */}
      <Dialog open={phaseDialogOpen} onOpenChange={setPhaseDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{editPhase ? 'עריכת פזה' : 'פזה חדשה'}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5"><Label>שם הפזה *</Label><Input value={phaseName} onChange={e => setPhaseName(e.target.value)} placeholder="לדוגמה: פזה א" /></div>
            <div className="space-y-1.5"><Label>תיאור</Label><Input value={phaseDesc} onChange={e => setPhaseDesc(e.target.value)} /></div>
            <div className="flex justify-end gap-3 pt-2">
              <Button variant="secondary" onClick={() => setPhaseDialogOpen(false)}>ביטול</Button>
              <Button onClick={handleSavePhase}>{editPhase ? 'שמור' : 'צור פזה'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={deletePhaseId !== null} onOpenChange={() => setDeletePhaseId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>מחיקת פזה</AlertDialogTitle>
            <AlertDialogDescription>הלקוחות לא יימחקו, רק השיוך לפזה יוסר.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>ביטול</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeletePhase} className="bg-destructive text-destructive-foreground">מחק</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>


      {/* Group Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editGroup ? 'עריכת קבוצה' : 'קבוצה חדשה'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>שם הקבוצה *</Label>
              <Input value={name} onChange={e => setName(e.target.value)} placeholder="לדוגמה: תלמידים" />
            </div>
            <div className="space-y-1.5">
              <Label>תיאור</Label>
              <Input value={description} onChange={e => setDescription(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>צבע</Label>
              <div className="flex gap-2">
                {COLORS.map(c => (
                  <button key={c} onClick={() => setColor(c)}
                    className={`w-7 h-7 rounded-full transition-transform ${color === c ? 'scale-125 ring-2 ring-foreground' : ''}`}
                    style={{ backgroundColor: c }} />
                ))}
              </div>
            </div>
            <div className="flex justify-end gap-3 pt-2">
              <Button variant="secondary" onClick={() => setDialogOpen(false)}>ביטול</Button>
              <Button onClick={handleSave}>{editGroup ? 'שמור' : 'צור קבוצה'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <AlertDialog open={deleteId !== null} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>מחיקת קבוצה</AlertDialogTitle>
            <AlertDialogDescription>הלקוחות לא יימחקו, רק השיוך לקבוצה יוסר.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>ביטול</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">מחק</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
